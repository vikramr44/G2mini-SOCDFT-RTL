// Artifact identity: SVA
// soc_dft_sva: boundary checker of soc_dft, sampled on rising TCK1 (the system
// clock of SOC_DFT; canon D80). Instanced by the bench beside the design; it reads
// only soc_dft ports. Checks:
//   C-01 REQ-01/Section 17: with DFTTM = 0 the block, TOP and CRG test controls hold
//        their M0 values.
//   C-02 REQ-05: TDO1_OE equals the selected target's enable (P_OE_GATED = 1).
//   C-03 REQ-20, REQ-02: with DFTTM = 0 every scan-channel output and DFTSO is 0.
`timescale 1ns/1ps
`default_nettype none
module soc_dft_sva (
  input wire        TCK1,
  input wire        TRSTN1,
  input wire        DFTTM,
  input wire [1:0]  TSEL1,
  input wire        TDO1_OE,
  input wire        arc_tdo1_oe,
  input wire        pcia_tdo1_oe,
  input wire        pcib_tdo1_oe,
  input wire [dft_part_map_pkg::NPIN-1:0] DFTSO,
  input wire        DFTSO_OE,
  input wire        scc_dfttm,
  input wire        scc_scan_shift_en,
  input wire [3:0]  scc_test_mode,
  input wire        top_scan_shift_en,
  input wire        dft_crg_test_clk_sel,
  input wire        dft_crg_rst_byp,
  input wire [2:0]  dft_crg_pll_byp,
  input wire [12:0] dft_crg_blk_clk_en,
  input wire [12:0] dft_crg_comp_clk_en,
  input wire [4:0]  dft_crg_lpddr_clk_en,
  input wire [dft_part_map_pkg::NCH_SCC-1:0] scc_test_si,
  input wire [dft_part_map_pkg::NWRAP-1:0] scc_wrap_si,
  input wire [dft_part_map_pkg::NTOP-1:0] top_test_si,
  output logic [2:0] fail_count
);
  wire c01 = TRSTN1 && !DFTTM &&
             !(scc_dfttm == 1'b0 && scc_scan_shift_en == 1'b0 && scc_test_mode == 4'b0000
               && top_scan_shift_en == 1'b0 && dft_crg_test_clk_sel == 1'b0
               && dft_crg_rst_byp == 1'b0 && dft_crg_pll_byp == 3'b000
               && dft_crg_blk_clk_en == 13'h1FFF && dft_crg_comp_clk_en == 13'h0000
               && dft_crg_lpddr_clk_en == 5'h00 && DFTSO_OE == 1'b0);
  wire c02 = TSEL1 != 2'b11 && TDO1_OE != ((TSEL1 == 2'b00) ? arc_tdo1_oe :
                                           (TSEL1 == 2'b01) ? pcia_tdo1_oe : pcib_tdo1_oe);
  wire c03 = TRSTN1 && !DFTTM && (DFTSO != '0 || scc_test_si != '0 || scc_wrap_si != '0 || top_test_si != '0);
  initial fail_count = 3'd0;
  always @(posedge TCK1) begin
    if (c01) $display("FAIL [C-01] M0 test controls not at their Section 17 values");
    if (c02) $display("FAIL [C-02] TDO1_OE is not the selected target's enable");
    if (c03) $display("FAIL [C-03] a scan-channel output or DFTSO is not 0 with DFTTM = 0");
    fail_count <= fail_count + {2'b00, c01} + {2'b00, c02} + {2'b00, c03};
  end
endmodule
`default_nettype wire
