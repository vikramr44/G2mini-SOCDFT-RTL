// Artifact identity: RTL
// dft_dtr_reg: JTAG configuration data-register engine (spec r0.91 10.6, Appendix C.3.4).
// Shift stage on rising TCK1: Capture-DR loads the shadow (read-back), Shift-DR shifts
// LSB first toward TDO. Shadow stage on falling TCK1 at Update-DR, only while tm = 0:
// clr_i returns it to P_RESET, otherwise a selected register loads the shift stage
// masked by P_WMASK (a 0 mask bit is reserved: write ignored, reads 0). The shadow is
// reset only by rst_ni (rst_dtr_n from PwrOk), never by TRSTN1 or Test-Logic-Reset.
`timescale 1ns/1ps
`default_nettype none
module dft_dtr_reg #(
  parameter int                 P_WIDTH = 32,
  parameter int unsigned P_RESET = 0,
  parameter int unsigned P_WMASK = 32'hFFFF_FFFF
) (
  input  wire               clk_i,
  input  wire               rst_ni,
  input  wire               tdi_i,
  input  wire               sel_i,
  input  wire               capture_i,
  input  wire               shift_i,
  input  wire               update_i,
  input  wire               tm_i,
  input  wire               clr_i,
  output wire [P_WIDTH-1:0] q_o,
  output wire               sr_msb_o,
  output wire               tdo_o
);
  logic [P_WIDTH-1:0] sr_q;
  logic [P_WIDTH-1:0] shadow_q;
  localparam bit [P_WIDTH-1:0] RESET_V = P_RESET[P_WIDTH-1:0];
  localparam bit [P_WIDTH-1:0] WMASK_V = P_WMASK[P_WIDTH-1:0];
  wire update_en = update_i & ~tm_i;                  // 10.6: no load and no CLR while tm = 1

  always_ff @(posedge clk_i) begin
    if (capture_i && sel_i)    sr_q <= shadow_q;
    else if (shift_i && sel_i) sr_q <= {tdi_i, sr_q[P_WIDTH-1:1]};
  end
  always_ff @(negedge clk_i or negedge rst_ni) begin
    if (!rst_ni)                 shadow_q <= RESET_V & WMASK_V;
    else if (update_en && clr_i) shadow_q <= RESET_V & WMASK_V;
    else if (update_en && sel_i) shadow_q <= sr_q & WMASK_V;
  end

  assign q_o      = shadow_q;
  assign sr_msb_o = sr_q[P_WIDTH-1];
  assign tdo_o    = sr_q[0];
endmodule
`default_nettype wire
