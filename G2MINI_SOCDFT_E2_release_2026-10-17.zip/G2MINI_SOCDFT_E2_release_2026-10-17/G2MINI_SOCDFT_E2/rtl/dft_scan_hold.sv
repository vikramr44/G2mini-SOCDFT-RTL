// Artifact identity: RTL
// dft_scan_hold: partial-build boundary of the scan router (spec r0.91 11.3), present in
// soc_dft only when P_PARTITIONED = 0. It has the ports of dft_scan_rtr without the
// selects, drives every output the router would drive at 0 (the partial-build value of
// 11.3) and reads none of the channel returns. The default build instantiates
// dft_scan_rtr in its place.
`timescale 1ns/1ps
`default_nettype none
module dft_scan_hold (
  // verilator lint_off UNUSEDSIGNAL
  input  wire [dft_part_map_pkg::NPIN-1:0] dftsi_i,
  input  wire [dft_part_map_pkg::NCH_SUM-1:0] test_so_all,
  input  wire [dft_part_map_pkg::NWRAP*dft_part_map_pkg::NSBLK-1:0] wrap_so_all,
  input  wire [dft_part_map_pkg::NTOP-1:0] top_test_so,
  // verilator lint_on UNUSEDSIGNAL
  output wire [dft_part_map_pkg::NPIN-1:0] dftso_o,
  output wire [dft_part_map_pkg::NCH_SUM-1:0] test_si_all,
  output wire [dft_part_map_pkg::NWRAP*dft_part_map_pkg::NSBLK-1:0] wrap_si_all,
  output wire [dft_part_map_pkg::NTOP-1:0] top_test_si
);
  localparam bit HELD_VALUE = 1'b0;   // partial-build value of every router output (11.3)
  assign dftso_o     = {dft_part_map_pkg::NPIN{HELD_VALUE}};
  assign test_si_all = {dft_part_map_pkg::NCH_SUM{HELD_VALUE}};
  assign wrap_si_all = {(dft_part_map_pkg::NWRAP*dft_part_map_pkg::NSBLK){HELD_VALUE}};
  assign top_test_si = {dft_part_map_pkg::NTOP{HELD_VALUE}};
endmodule
`default_nettype wire
