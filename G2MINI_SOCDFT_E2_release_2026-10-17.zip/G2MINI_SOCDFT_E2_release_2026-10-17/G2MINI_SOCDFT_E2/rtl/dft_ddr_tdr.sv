// Artifact identity: RTL
// dft_ddr_tdr: LPDDR PHY TDR bridge (spec r0.91 15.4, cycle sequence 15.5).
// TDRCLK = TCK1 through the clock-gate cell enabled by ddr_tdr_en; WRSTN = TRSTN1 &
// ddr_tdr_en, asserted asynchronously and released through a reset synchroniser cell
// on TDRCLK. The twelve capture/shift/update enables are decoded from the TAP state and
// the DDRx instruction, gated with ~tm, and registered on the P_TDR_EN_EDGE edge of
// TCK1 (1 = falling, IEEE 1500 convention; CONF-25). Vector index [1:0] = {phy1, phy0}.
`timescale 1ns/1ps
`default_nettype none
module dft_ddr_tdr #(
  parameter bit P_TDR_EN_EDGE = 1'b1
) (
  input  wire       TCK1,
  input  wire       TRSTN1,
  input  wire       tap_tdi,
  input  wire [3:0] tap_state,
  input  wire [4:0] ir,
  input  wire       tm,
  input  wire       ddr_tdr_en,
  output wire       lpddr_tdrclk,
  output wire       lpddr_wrstn,
  output wire [1:0] lpddr_cmd_tdr_capture_en,
  output wire [1:0] lpddr_cmd_tdr_shift_en,
  output wire [1:0] lpddr_cmd_tdr_update_en,
  output wire [1:0] lpddr_rd_tdr_capture_en,
  output wire [1:0] lpddr_rd_tdr_shift_en,
  output wire [1:0] lpddr_rd_tdr_update_en,
  output wire [1:0] lpddr_wsi,
  input  wire [1:0] lpddr_cmd_tdr_tdo,
  input  wire [1:0] lpddr_rd_tdr_tdo,
  output wire       dr_tdo_ddr
);
  localparam logic [4:0] IR_DDR0_CMD = 5'b00101;
  localparam logic [4:0] IR_DDR0_RD  = 5'b00110;
  localparam logic [4:0] IR_DDR1_CMD = 5'b00111;
  localparam logic [4:0] IR_DDR1_RD  = 5'b01000;
  localparam logic [3:0] ST_CAPTURE_DR  = 4'h6;
  localparam logic [3:0] ST_SHIFT_DR    = 4'h2;
  localparam logic [3:0] ST_UPDATE_DR   = 4'h5;

  // TDRCLK gate and WRSTN release
  dft_icg u_dft_icg_tdrclk_dont_touch (
    .clk_i (TCK1), .en_i (ddr_tdr_en), .gclk_o (lpddr_tdrclk)
  );
  wire wrstn_arst_n = TRSTN1 & ddr_tdr_en;
  dft_rst_sync u_dft_rst_sync_wrstn_dont_touch (
    .clk_i (lpddr_tdrclk), .rst_ni (wrstn_arst_n), .rst_no (lpddr_wrstn)
  );

  // Instruction decode
  wire [1:0] ir_cmd = {ir == IR_DDR1_CMD, ir == IR_DDR0_CMD};
  wire [1:0] ir_rd  = {ir == IR_DDR1_RD,  ir == IR_DDR0_RD};
  wire       st_cap = (tap_state == ST_CAPTURE_DR);
  wire       st_sh  = (tap_state == ST_SHIFT_DR);
  wire       st_up  = (tap_state == ST_UPDATE_DR);

  // {rd_update, rd_shift, rd_capture, cmd_update, cmd_shift, cmd_capture}, two bits each
  wire [11:0] en_d = {ir_rd  & {2{st_up  & ~tm}}, ir_rd  & {2{st_sh & ~tm}}, ir_rd  & {2{st_cap & ~tm}},
                      ir_cmd & {2{st_up  & ~tm}}, ir_cmd & {2{st_sh & ~tm}}, ir_cmd & {2{st_cap & ~tm}}};
  logic [11:0] en_q;
  if (P_TDR_EN_EDGE) begin : g_fall
    always_ff @(negedge TCK1 or negedge TRSTN1) begin
      if (!TRSTN1) en_q <= 12'h000;
      else         en_q <= en_d;
    end
  end else begin : g_rise
    always_ff @(posedge TCK1 or negedge TRSTN1) begin
      if (!TRSTN1) en_q <= 12'h000;
      else         en_q <= en_d;
    end
  end
  assign lpddr_cmd_tdr_capture_en = en_q[1:0];
  assign lpddr_cmd_tdr_shift_en   = en_q[3:2];
  assign lpddr_cmd_tdr_update_en  = en_q[5:4];
  assign lpddr_rd_tdr_capture_en  = en_q[7:6];
  assign lpddr_rd_tdr_shift_en    = en_q[9:8];
  assign lpddr_rd_tdr_update_en   = en_q[11:10];

  assign lpddr_wsi  = {2{tap_tdi}} & (ir_cmd | ir_rd);
  assign dr_tdo_ddr = ir_cmd[0] ? lpddr_cmd_tdr_tdo[0] :
                      ir_rd[0]  ? lpddr_rd_tdr_tdo[0]  :
                      ir_cmd[1] ? lpddr_cmd_tdr_tdo[1] :
                      ir_rd[1]  ? lpddr_rd_tdr_tdo[1]  : 1'b0;
endmodule
`default_nettype wire
