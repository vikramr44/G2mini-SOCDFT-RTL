// Artifact identity: RTL
// dft_tap: IEEE 1149.1 TAP controller (spec r0.91 Section 9).
// 16-state FSM on rising TCK1 (encoding of Table 45), P_IR_LEN-bit IR capturing 1,
// IDCODE, BYPASS, DR multiplexer and a falling-edge TDO retime that holds outside
// the Shift states (9.6). P_DR_CLIENTS = 1 decodes the DTR and DDRx codes of
// Table 46; P_DR_CLIENTS = 0 keeps IDCODE and BYPASS (the first chain device, 14.6).
`timescale 1ns/1ps
`default_nettype none
module dft_tap #(
  parameter int          P_IR_LEN     = 5,
  parameter bit          P_DR_CLIENTS = 1'b1,
  parameter int unsigned P_IDCODE     = 32'h0000_0001
) (
  input  wire                TCK1,
  input  wire                TRSTN1,
  input  wire                tap_tdi,
  input  wire                sms_tms1,
  output wire                sms_tdo1,
  output wire                sms_tdo1_oe,
  output wire [3:0]          tap_state,
  output wire [P_IR_LEN-1:0] ir,
  output wire                capture_dr,
  output wire                shift_dr,
  output wire                update_dr,
  input  wire                dr_tdo_cfg,
  input  wire                dr_tdo_lpddr,
  input  wire                dr_tdo_sts,
  input  wire                dr_tdo_ddr
);
  typedef enum logic [3:0] {
    ST_TEST_LOGIC_RESET  = 4'hF,
    ST_RUN_TEST_IDLE     = 4'hC,
    ST_SELECT_DR_SCAN    = 4'h7,
    ST_CAPTURE_DR        = 4'h6,
    ST_SHIFT_DR          = 4'h2,
    ST_EXIT1_DR          = 4'h1,
    ST_PAUSE_DR          = 4'h3,
    ST_EXIT2_DR          = 4'h0,
    ST_UPDATE_DR         = 4'h5,
    ST_SELECT_IR_SCAN    = 4'h4,
    ST_CAPTURE_IR        = 4'hE,
    ST_SHIFT_IR          = 4'hA,
    ST_EXIT1_IR          = 4'h9,
    ST_PAUSE_IR          = 4'hB,
    ST_EXIT2_IR          = 4'h8,
    ST_UPDATE_IR         = 4'hD
  } tap_state_e;

  localparam logic [P_IR_LEN-1:0] IR_IDCODE    = P_IR_LEN'(1);
  localparam logic [P_IR_LEN-1:0] IR_DTR_CFG   = P_IR_LEN'(2);
  localparam logic [P_IR_LEN-1:0] IR_DTR_LPDDR = P_IR_LEN'(3);
  localparam logic [P_IR_LEN-1:0] IR_DTR_STS   = P_IR_LEN'(4);
  localparam logic [P_IR_LEN-1:0] IR_DDR0_CMD  = P_IR_LEN'(5);
  localparam logic [P_IR_LEN-1:0] IR_DDR1_RD   = P_IR_LEN'(8);

  wire tms = sms_tms1;

  // ---------------------------------------------------------------- FSM
  tap_state_e state_q;
  tap_state_e state_d;
  always_comb begin
    case (state_q)
      ST_TEST_LOGIC_RESET: if (tms) state_d = ST_TEST_LOGIC_RESET; else state_d = ST_RUN_TEST_IDLE;
      ST_RUN_TEST_IDLE: if (tms) state_d = ST_SELECT_DR_SCAN; else state_d = ST_RUN_TEST_IDLE;
      ST_SELECT_DR_SCAN: if (tms) state_d = ST_SELECT_IR_SCAN; else state_d = ST_CAPTURE_DR;
      ST_CAPTURE_DR: if (tms) state_d = ST_EXIT1_DR; else state_d = ST_SHIFT_DR;
      ST_SHIFT_DR: if (tms) state_d = ST_EXIT1_DR; else state_d = ST_SHIFT_DR;
      ST_EXIT1_DR: if (tms) state_d = ST_UPDATE_DR; else state_d = ST_PAUSE_DR;
      ST_PAUSE_DR: if (tms) state_d = ST_EXIT2_DR; else state_d = ST_PAUSE_DR;
      ST_EXIT2_DR: if (tms) state_d = ST_UPDATE_DR; else state_d = ST_SHIFT_DR;
      ST_UPDATE_DR: if (tms) state_d = ST_SELECT_DR_SCAN; else state_d = ST_RUN_TEST_IDLE;
      ST_SELECT_IR_SCAN: if (tms) state_d = ST_TEST_LOGIC_RESET; else state_d = ST_CAPTURE_IR;
      ST_CAPTURE_IR: if (tms) state_d = ST_EXIT1_IR; else state_d = ST_SHIFT_IR;
      ST_SHIFT_IR: if (tms) state_d = ST_EXIT1_IR; else state_d = ST_SHIFT_IR;
      ST_EXIT1_IR: if (tms) state_d = ST_UPDATE_IR; else state_d = ST_PAUSE_IR;
      ST_PAUSE_IR: if (tms) state_d = ST_EXIT2_IR; else state_d = ST_PAUSE_IR;
      ST_EXIT2_IR: if (tms) state_d = ST_UPDATE_IR; else state_d = ST_SHIFT_IR;
      ST_UPDATE_IR: if (tms) state_d = ST_SELECT_DR_SCAN; else state_d = ST_RUN_TEST_IDLE;
      default:          state_d = ST_TEST_LOGIC_RESET;
    endcase
  end
  always_ff @(posedge TCK1 or negedge TRSTN1) begin
    if (!TRSTN1) state_q <= ST_TEST_LOGIC_RESET;
    else         state_q <= state_d;
  end

  // ---------------------------------------------------------------- IR
  logic [P_IR_LEN-1:0] ir_sr_q;
  logic [P_IR_LEN-1:0] ir_q;
  always_ff @(posedge TCK1 or negedge TRSTN1) begin
    if (!TRSTN1)                    ir_sr_q <= IR_IDCODE;
    else if (state_q == ST_CAPTURE_IR) ir_sr_q <= IR_IDCODE;          // LSB pair 01
    else if (state_q == ST_SHIFT_IR)   ir_sr_q <= {tap_tdi, ir_sr_q[P_IR_LEN-1:1]};
  end
  always_ff @(negedge TCK1 or negedge TRSTN1) begin
    if (!TRSTN1)                          ir_q <= IR_IDCODE;
    else if (state_q == ST_TEST_LOGIC_RESET) ir_q <= IR_IDCODE;
    else if (state_q == ST_UPDATE_IR)        ir_q <= ir_sr_q;
  end

  // ---------------------------------------------------------------- decode
  wire sel_idcode = (ir_q == IR_IDCODE);
  wire sel_cfg;
  wire sel_lpddr;
  wire sel_sts;
  wire sel_ddr_any;
  if (P_DR_CLIENTS) begin : g_dr
    if (P_IR_LEN != 5) begin : g_len
      $fatal(1, "dft_tap: P_DR_CLIENTS = 1 requires P_IR_LEN = 5 (spec 9.4, LR-02)");
    end
    assign sel_cfg     = (ir_q == IR_DTR_CFG);
    assign sel_lpddr   = (ir_q == IR_DTR_LPDDR);
    assign sel_sts     = (ir_q == IR_DTR_STS);
    assign sel_ddr_any = (ir_q >= IR_DDR0_CMD) && (ir_q <= IR_DDR1_RD);
  end else begin : g_nodr
    assign sel_cfg     = 1'b0;
    assign sel_lpddr   = 1'b0;
    assign sel_sts     = 1'b0;
    assign sel_ddr_any = 1'b0;
  end

  // ---------------------------------------------------------------- IDCODE, BYPASS
  logic [31:0] idcode_sr_q;
  always_ff @(posedge TCK1) begin
    if (state_q == ST_CAPTURE_DR && sel_idcode)    idcode_sr_q <= P_IDCODE[31:0];
    else if (state_q == ST_SHIFT_DR && sel_idcode) idcode_sr_q <= {tap_tdi, idcode_sr_q[31:1]};
  end
  logic byp_q;
  always_ff @(posedge TCK1 or negedge TRSTN1) begin
    if (!TRSTN1)                    byp_q <= 1'b0;
    else if (state_q == ST_CAPTURE_DR) byp_q <= 1'b0;
    else if (state_q == ST_SHIFT_DR)   byp_q <= tap_tdi;
  end

  // ---------------------------------------------------------------- DR mux, TDO retime
  wire dr_tdo = sel_idcode  ? idcode_sr_q[0] :
                sel_cfg     ? dr_tdo_cfg     :
                sel_lpddr   ? dr_tdo_lpddr   :
                sel_sts     ? dr_tdo_sts     :
                sel_ddr_any ? dr_tdo_ddr     : byp_q;
  logic tdo_q;
  logic tdo_oe_q;
  always_ff @(negedge TCK1 or negedge TRSTN1) begin
    if (!TRSTN1) begin
      tdo_q    <= 1'b0;
      tdo_oe_q <= 1'b0;
    end else begin
      tdo_oe_q <= (state_q == ST_SHIFT_IR) | (state_q == ST_SHIFT_DR);
      if (state_q == ST_SHIFT_IR)      tdo_q <= ir_sr_q[0];
      else if (state_q == ST_SHIFT_DR) tdo_q <= dr_tdo;       // holds in every other state
    end
  end

  assign sms_tdo1    = tdo_q;
  assign sms_tdo1_oe = tdo_oe_q;
  assign tap_state   = state_q;
  assign ir          = ir_q;
  assign capture_dr  = (state_q == ST_CAPTURE_DR);
  assign shift_dr    = (state_q == ST_SHIFT_DR);
  assign update_dr   = (state_q == ST_UPDATE_DR);
endmodule
`default_nettype wire
