// Artifact identity: RTL
// dft_sms_srv: SMS Server shell (spec r0.91 14.6, Table 74), device 1 of the TSEL1 = 11
// chain. The Synopsys SMS builder inserts the SMS TAP and SMS Server into this shell
// (24.12). Until that output (R7) exists the shell carries a dft_tap instance with
// P_IR_LEN = P_SMS_IR_LEN, P_DR_CLIENTS = 0 and P_IDCODE = P_SMS_IDCODE: an IEEE 1149.1
// device with IDCODE and BYPASS only, TDI = TDI1, TDO = sms_tap_tdo; every sms_in is 0.
`timescale 1ns/1ps
`default_nettype none
module dft_sms_srv #(
  parameter int          P_SMS_IR_LEN = 4,              // CONF-40
  parameter int unsigned P_SMS_IDCODE = 32'h0001_0001
) (
  input  wire       TCK1,
  input  wire       TRSTN1,
  input  wire       TDI1,
  input  wire       sms_tms1,
  output wire       sms_tap_tdo,
  output wire       sms_tap_tdo_oe,
  // verilator lint_off UNUSEDSIGNAL
  input  wire       DFTTM,
  input  wire       DFTSE,
  // verilator lint_on UNUSEDSIGNAL
  output wire [4:0] scc_sms_in,
  output wire [4:0] hic_sms_in,
  output wire [4:0] g2muc_sms_in,
  output wire [4:0] l4ga_sms_in,
  output wire [4:0] l4gb_sms_in,
  output wire [4:0] ahb_sms_in,
  output wire [4:0] lpddr_sms_in,
  output wire [9:0] pcia_sms_in,
  output wire [9:0] pcib_sms_in,
  // verilator lint_off UNUSEDSIGNAL
  input  wire       scc_sms_out,
  input  wire       hic_sms_out,
  input  wire       g2muc_sms_out,
  input  wire       l4ga_sms_out,
  input  wire       l4gb_sms_out,
  input  wire       ahb_sms_out,
  input  wire       lpddr_sms_out,
  input  wire [1:0] pcia_sms_out,
  input  wire [1:0] pcib_sms_out
  // verilator lint_on UNUSEDSIGNAL
);
  // verilator lint_off UNUSEDSIGNAL
  wire [3:0]              stub_state;
  wire [P_SMS_IR_LEN-1:0] stub_ir;
  wire                    stub_capture_dr;
  wire                    stub_shift_dr;
  wire                    stub_update_dr;
  // verilator lint_on UNUSEDSIGNAL
  dft_tap #(
    .P_IR_LEN (P_SMS_IR_LEN), .P_DR_CLIENTS (1'b0), .P_IDCODE (P_SMS_IDCODE)
  ) u_stub (
    .TCK1 (TCK1), .TRSTN1 (TRSTN1), .tap_tdi (TDI1), .sms_tms1 (sms_tms1),
    .sms_tdo1 (sms_tap_tdo), .sms_tdo1_oe (sms_tap_tdo_oe),
    .tap_state (stub_state), .ir (stub_ir),
    .capture_dr (stub_capture_dr), .shift_dr (stub_shift_dr), .update_dr (stub_update_dr),
    .dr_tdo_cfg (1'b0), .dr_tdo_lpddr (1'b0), .dr_tdo_sts (1'b0), .dr_tdo_ddr (1'b0)
  );

  assign scc_sms_in   = 5'b00000;
  assign hic_sms_in   = 5'b00000;
  assign g2muc_sms_in = 5'b00000;
  assign l4ga_sms_in  = 5'b00000;
  assign l4gb_sms_in  = 5'b00000;
  assign ahb_sms_in   = 5'b00000;
  assign lpddr_sms_in = 5'b00000;
  assign pcia_sms_in  = 10'h000;
  assign pcib_sms_in  = 10'h000;
endmodule
`default_nettype wire
