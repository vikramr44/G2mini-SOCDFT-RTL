// Artifact identity: RTL
// dft_dtr_sts: DTR_STS, the capture-only status data register (spec r0.91 10.4).
// Capture-DR loads the status word, Shift-DR shifts LSB first toward TDO on rising
// TCK1; Update-DR has no effect, so the register has no shadow stage.
`timescale 1ns/1ps
`default_nettype none
module dft_dtr_sts #(
  parameter int P_WIDTH = 32
) (
  input  wire               clk_i,
  input  wire               tdi_i,
  input  wire               sel_i,
  input  wire               capture_i,
  input  wire               shift_i,
  input  wire [P_WIDTH-1:0] status_i,
  output wire               tdo_o
);
  logic [P_WIDTH-1:0] sr_q;
  always_ff @(posedge clk_i) begin
    if (capture_i && sel_i)    sr_q <= status_i;
    else if (shift_i && sel_i) sr_q <= {tdi_i, sr_q[P_WIDTH-1:1]};
  end
  assign tdo_o = sr_q[0];
endmodule
`default_nettype wire
