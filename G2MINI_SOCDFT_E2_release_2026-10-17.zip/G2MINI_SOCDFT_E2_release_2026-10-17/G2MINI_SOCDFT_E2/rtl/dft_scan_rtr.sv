// Artifact identity: RTL
// dft_scan_rtr: scan router of SOC_DFT (spec r0.91 12.1, 12.3), over dft_part_map_pkg.
// Combinational; no flop on any scan path. Channel buses are flat: routed block b's
// channels sit at OFF[b] (NCH[b] wide), its two wrapper chains at NWRAP*b.
//   scan-in : a fan-out with per-block gating, test_si[OFF[b] + j] = sel[b] & dftsi_i[PIN_BASE[p][b] + j],
//             p the PART of block b's mode
//   EXTEST  : block b's wrapper chains in series on pin b; TOP chain t on pin NSBLK + t
//   lane k  : level 1, the four INTEST modes through three dft_mux2 cells (unmapped inputs 0),
//             gated by intest; level 2, dft_mux2 to the wrapper or TOP lane under extest;
//             a third dft_mux2 returns dftsi_i[k] under loopback (12.3 order).
// With tm = 0, sel, extest, loopback and intest are 0, so every output is 0.
`timescale 1ns/1ps
`default_nettype none
module dft_scan_rtr (
  input  wire        tm,
  input  wire [3:0]  part,
  input  wire [dft_part_map_pkg::NSBLK-1:0] sel,
  input  wire        extest,
  input  wire        loopback,
  input  wire [dft_part_map_pkg::NPIN-1:0] dftsi_i,
  output wire [dft_part_map_pkg::NPIN-1:0] dftso_o,
  output wire [dft_part_map_pkg::NCH_SUM-1:0] test_si_all,
  input  wire [dft_part_map_pkg::NCH_SUM-1:0] test_so_all,
  output wire [dft_part_map_pkg::NWRAP*dft_part_map_pkg::NSBLK-1:0] wrap_si_all,
  input  wire [dft_part_map_pkg::NWRAP*dft_part_map_pkg::NSBLK-1:0] wrap_so_all,
  output wire [dft_part_map_pkg::NTOP-1:0] top_test_si,
  input  wire [dft_part_map_pkg::NTOP-1:0] top_test_so
);
  localparam int NBLK  = dft_part_map_pkg::NBLK;
  localparam int NPIN  = dft_part_map_pkg::NPIN;
  localparam int NSBLK = dft_part_map_pkg::NSBLK;
  localparam int NWRAP = dft_part_map_pkg::NWRAP;
  localparam int NTOP  = dft_part_map_pkg::NTOP;
  localparam int NMODE = dft_part_map_pkg::NMODE;
  localparam int PART_MODE0 = dft_part_map_pkg::PART_MODE0;   // PART of INTEST mode 0

  // LR-01: level 1 is a 4:1 and EXTEST needs a pin per routed block and per TOP chain.
  if (NMODE != 4 || NPIN < NSBLK + NTOP) begin : g_map_refused
    $error("dft_scan_rtr: the package needs NMODE = 4 and NPIN >= NSBLK + NTOP (LR-01)");
  end

  // scan-in fan-out with per-block gating; wrapper chains in series under EXTEST
  for (genvar b = 0; b < NSBLK; b++) begin : g_blk
    for (genvar m = 0; m < NMODE; m++) begin : g_mode
      if (dft_part_map_pkg::PIN_BASE[8*(NBLK*(int'(PART_MODE0) + m) + b) +: 8] != 8'hFF) begin : g_member
        for (genvar j = 0; j < int'(dft_part_map_pkg::NCH[8*b +: 8]); j++) begin : g_ch
          assign test_si_all[int'(dft_part_map_pkg::OFF[8*b +: 8]) + j] =
                 sel[b] & dftsi_i[int'(dft_part_map_pkg::PIN_BASE[8*(NBLK*(int'(PART_MODE0) + m) + b) +: 8]) + j];
        end
      end
    end
    assign wrap_si_all[NWRAP*b]     = extest & dftsi_i[b];
    assign wrap_si_all[NWRAP*b + 1] = extest & wrap_so_all[NWRAP*b];
  end
  for (genvar t = 0; t < NTOP; t++) begin : g_top
    assign top_test_si[t] = extest & dftsi_i[NSBLK + t];
  end

  // the INTEST mode selected by PART (mode m on PART_MODE0 + m)
  wire [1:0] mode_ofs = part[1:0] - PART_MODE0[1:0];    // m, exact modulo NMODE = 4
  wire       intest   = tm & (int'(part) >= PART_MODE0) & (int'(part) < PART_MODE0 + NMODE);

  for (genvar k = 0; k < NPIN; k++) begin : g_lane
    wire [3:0] l1_in;
    for (genvar m = 0; m < 4; m++) begin : g_mode
      if (dft_part_map_pkg::SO_VALID[NPIN*(int'(PART_MODE0) + m) + k]) begin : g_mapped
        // block SO_BLK and channel SO_CH of lane k in this mode, at OFF[SO_BLK] + SO_CH
        assign l1_in[m] = test_so_all[
            int'(dft_part_map_pkg::OFF[8*int'(dft_part_map_pkg::SO_BLK[4*(NPIN*(int'(PART_MODE0) + m) + k) +: 4]) +: 8])
          + int'(dft_part_map_pkg::SO_CH[5*(NPIN*(int'(PART_MODE0) + m) + k) +: 5])];
      end else begin : g_unmapped
        assign l1_in[m] = 1'b0;                     // unmapped lane drives 0 (12.3)
      end
    end
    wire l1_lo, l1_hi, l1, l1_gated, l2, ext_lane;
    dft_mux2 u_dft_mux2_l1lo_dont_touch (.a_i(l1_in[0]), .b_i(l1_in[1]), .s_i(mode_ofs[0]), .y_o(l1_lo));
    dft_mux2 u_dft_mux2_l1hi_dont_touch (.a_i(l1_in[2]), .b_i(l1_in[3]), .s_i(mode_ofs[0]), .y_o(l1_hi));
    dft_mux2 u_dft_mux2_l1_dont_touch   (.a_i(l1_lo),    .b_i(l1_hi),    .s_i(mode_ofs[1]), .y_o(l1));
    assign l1_gated = l1 & intest;
    if (k < NSBLK) begin : g_wrap_lane
      assign ext_lane = wrap_so_all[NWRAP*k + NWRAP - 1];
    end else if (k < NSBLK + NTOP) begin : g_top_lane
      assign ext_lane = top_test_so[k - NSBLK];
    end else begin : g_no_lane
      assign ext_lane = 1'b0;                       // no EXTEST chain on this pin
    end
    dft_mux2 u_dft_mux2_l2_dont_touch (.a_i(l1_gated), .b_i(ext_lane),   .s_i(extest),   .y_o(l2));
    dft_mux2 u_dft_mux2_lb_dont_touch (.a_i(l2),       .b_i(dftsi_i[k]), .s_i(loopback), .y_o(dftso_o[k]));
  end
endmodule
`default_nettype wire
