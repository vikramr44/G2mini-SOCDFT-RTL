// Artifact identity: RTL
// dft_crg_ctl: test clock and reset control (spec r0.91 13.2).
// Drives the selects and enables of the CRG test structure (Table 69); the muxes and
// clock gates themselves are CRG cells. Rst_n_test and lpddr_scan_rstn are chosen
// through reset mux cells (24.11).
`timescale 1ns/1ps
`default_nettype none
module dft_crg_ctl (
  input  wire        tm,
  input  wire        dftmax_i,
  input  wire        Rstn,
  // verilator lint_off UNUSEDSIGNAL
  input  wire [31:0] dtr_cfg,
  // verilator lint_on UNUSEDSIGNAL
  input  wire [dft_part_map_pkg::NBLK-1:0] sel,
  input  wire [dft_part_map_pkg::NBLK-1:0] active,
  output wire        dft_crg_test_clk_sel,
  output wire [2:0]  dft_crg_pll_byp,
  output wire [12:0] dft_crg_blk_clk_en,
  output wire [12:0] dft_crg_comp_clk_en,
  output wire [4:0]  dft_crg_lpddr_clk_en,
  output wire        dft_crg_rst_byp,
  output wire        dft_crg_rst_n_test,
  output wire        lpddr_scan_rstn
);
  // DTR_CFG field positions (spec Table 50)
  localparam int CFG_PLL_BYP    = 5;
  localparam int CFG_RST_OVR    = 6;
  localparam int CFG_RST_VAL    = 7;
  localparam int CFG_BLK_CLK_EN = 8;   // 13 bits, 20:8
  wire        pll_byp    = dtr_cfg[CFG_PLL_BYP];
  wire        rst_ovr    = dtr_cfg[CFG_RST_OVR];
  wire        rst_val    = dtr_cfg[CFG_RST_VAL];
  wire [12:0] blk_clk_en = dtr_cfg[CFG_BLK_CLK_EN +: 13];

  assign dft_crg_test_clk_sel = tm;
  assign dft_crg_pll_byp      = (tm & pll_byp) ? 3'b111 : 3'b000;   // {PLLDK, PLLGK, PLLUK}
  // The three outputs below are enables of CRG clock gates, not clocks; they are
  // formed on enable nets first (FE-03 in reports/FRAMEWORK-EVALUATION.md).
  wire [12:0] blk_en   = {13{~tm}} | (blk_clk_en & active);
  wire [12:0] comp_en  = {13{tm & dftmax_i}} & sel & blk_clk_en;
  wire [4:0]  lpddr_en = {5{tm & active[11] & blk_clk_en[11]}};
  assign dft_crg_blk_clk_en   = blk_en;
  assign dft_crg_comp_clk_en  = comp_en;
  assign dft_crg_lpddr_clk_en = lpddr_en;
  assign dft_crg_rst_byp      = tm;

  wire rst_n_test;
  dft_mux2 u_dft_mux2_rst_dont_touch (       // Rst_n_test = RST_OVR ? RST_VAL : Rstn
    .a_i (Rstn), .b_i (rst_val), .s_i (rst_ovr), .y_o (rst_n_test)
  );
  dft_mux2 u_dft_mux2_scan_rstn_dont_touch (  // lpddr_scan_rstn = tm ? Rst_n_test : 1
    .a_i (1'b1), .b_i (rst_n_test), .s_i (tm), .y_o (lpddr_scan_rstn)
  );
  assign dft_crg_rst_n_test = rst_n_test;
endmodule
`default_nettype wire
