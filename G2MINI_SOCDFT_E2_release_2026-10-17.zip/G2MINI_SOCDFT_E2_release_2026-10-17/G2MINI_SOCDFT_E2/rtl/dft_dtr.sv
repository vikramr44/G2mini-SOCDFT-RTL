// Artifact identity: RTL
// dft_dtr: DFT test registers (spec r0.91 Section 10).
// DTR_CFG (IR 5'b00010) and DTR_LPDDR (IR 5'b00011) on the engine dft_dtr_reg, and
// DTR_STS (IR 5'b00100, capture only) on dft_dtr_sts. CLR (DTR_CFG bit 31) at Update-DR returns DTR_CFG
// and DTR_LPDDR to their reset values, only while tm = 0 (10.6). The eight DTR_STS
// inputs from pads and the CRG pass a two-flop synchroniser cell on TCK1 (10.4).
`timescale 1ns/1ps
`default_nettype none
module dft_dtr
#(
  parameter int unsigned P_CFG_RST   = 32'h003F_FFA5,  // CONF-06
  parameter int unsigned P_LPDDR_RST = 32'h0000_0000,  // CONF-26
  parameter int unsigned P_RTL_REV   = 32'h05
) (
  input  wire        TCK1,
  input  wire        tap_tdi,
  input  wire        rst_dtr_n,
  input  wire [4:0]  ir,
  input  wire        capture_dr,
  input  wire        shift_dr,
  input  wire        update_dr,
  input  wire        tm,
  input  wire        dftmax_i,
  input  wire [1:0]  TSEL1,
  input  wire [2:0]  crg_pll_ready,
  input  wire        PwrOk,
  input  wire [3:0]  part,
  output wire        dr_tdo_cfg,
  output wire        dr_tdo_lpddr,
  output wire        dr_tdo_sts,
  output wire [31:0] dtr_cfg,
  output wire [31:0] dtr_lpddr,
  output wire        ddr_tdr_en,
  output wire [2:0]  lpddr_sms_dm,
  output wire [6:0]  lpddr_ring_bypass,
  output wire        lpddr_sfp_dft_mode
);
  localparam logic [4:0]  IR_DTR_CFG   = 5'b00010;
  localparam logic [4:0]  IR_DTR_LPDDR = 5'b00011;
  localparam logic [4:0]  IR_DTR_STS   = 5'b00100;
  localparam int unsigned CFG_WMASK   = 32'h007F_FFFF;  // 30:23 reserved, 31 CLR not stored
  localparam int unsigned LPDDR_WMASK = 32'h0003_FFFF;  // 31:18 reserved

  wire sel_cfg   = (ir == IR_DTR_CFG);
  wire sel_lpddr = (ir == IR_DTR_LPDDR);
  wire sel_sts   = (ir == IR_DTR_STS);

  // DTR_STS inputs, synchronised on TCK1 (no reset): {PwrOk, PLL_RDY, TSEL1, DFTMAX_COMP, DFTTM}
  wire [7:0] sts_async = {PwrOk, crg_pll_ready, TSEL1, dftmax_i, tm};
  wire [7:0] sts_sync;
  dft_sync2 #(.P_WIDTH(8)) u_dft_sync2_sts_dont_touch (
    .clk_i (TCK1),
    .d_i   (sts_async),
    .q_o   (sts_sync)
  );
  wire [31:0] sts_value = {8'h00, P_RTL_REV[7:0], dft_part_map_pkg::NPART, part, sts_sync};

  wire cfg_sr_msb;
  // verilator lint_off UNUSEDSIGNAL
  wire lpddr_sr_msb;
  // verilator lint_on UNUSEDSIGNAL
  wire clr = sel_cfg & cfg_sr_msb;      // load_rst = update_dr & sel_cfg & cfg_sr[31] & ~tm

  dft_dtr_reg #(.P_WIDTH(32), .P_RESET(P_CFG_RST), .P_WMASK(CFG_WMASK)) u_cfg (
    .clk_i (TCK1), .rst_ni (rst_dtr_n), .tdi_i (tap_tdi), .sel_i (sel_cfg),
    .capture_i (capture_dr), .shift_i (shift_dr), .update_i (update_dr), .tm_i (tm),
    .clr_i (clr), .q_o (dtr_cfg), .sr_msb_o (cfg_sr_msb), .tdo_o (dr_tdo_cfg)
  );
  dft_dtr_reg #(.P_WIDTH(32), .P_RESET(P_LPDDR_RST), .P_WMASK(LPDDR_WMASK)) u_lpddr (
    .clk_i (TCK1), .rst_ni (rst_dtr_n), .tdi_i (tap_tdi), .sel_i (sel_lpddr),
    .capture_i (capture_dr), .shift_i (shift_dr), .update_i (update_dr), .tm_i (tm),
    .clr_i (clr), .q_o (dtr_lpddr), .sr_msb_o (lpddr_sr_msb), .tdo_o (dr_tdo_lpddr)
  );
  dft_dtr_sts #(.P_WIDTH(32)) u_sts (
    .clk_i (TCK1), .tdi_i (tap_tdi), .sel_i (sel_sts), .capture_i (capture_dr),
    .shift_i (shift_dr), .status_i (sts_value), .tdo_o (dr_tdo_sts)
  );

  assign ddr_tdr_en         = dtr_cfg[22];
  assign lpddr_sfp_dft_mode = dtr_lpddr[6];
  assign lpddr_ring_bypass  = dtr_lpddr[13:7];
  assign lpddr_sms_dm       = dtr_lpddr[16:14];
endmodule
`default_nettype wire
