// Artifact identity: RTL
// dft_jtag1_rtr: JTAG1 router (spec r0.91 Section 8, equations 8.4, Table 41).
// TSEL1 one-hot select; unselected TAPs see TMS = 1; the SOC_DFT TAP is parked
// whenever tm = 1; TDO1 is the AND-OR of the four targets' TDO.
`timescale 1ns/1ps
`default_nettype none
module dft_jtag1_rtr #(
  parameter bit P_OE_GATED = 1'b1,  // CONF-07
  parameter bit P_TM_OPEN  = 1'b1   // 8.4
) (
  input  wire [1:0] TSEL1,
  input  wire       TMS1,
  input  wire       tm,
  output wire       arc_tms1,
  output wire       pcia_tms1,
  output wire       pcib_tms1,
  output wire       sms_tms1,
  input  wire       arc_tdo1,
  input  wire       arc_tdo1_oe,
  input  wire       pcia_tdo1,
  input  wire       pcia_tdo1_oe,
  input  wire       pcib_tdo1,
  input  wire       pcib_tdo1_oe,
  input  wire       sms_tdo1,
  input  wire       sms_tdo1_oe,
  output wire       TDO1,
  output wire       TDO1_OE
);
  wire arc_sel  = ~TSEL1[1] & ~TSEL1[0];
  wire pcia_sel = ~TSEL1[1] &  TSEL1[0];
  wire pcib_sel =  TSEL1[1] & ~TSEL1[0];
  wire sms_sel  =  TSEL1[1] &  TSEL1[0];
  wire tm_o     = tm & P_TM_OPEN;

  assign arc_tms1  = TMS1 | ~(arc_sel  | tm_o);
  assign pcia_tms1 = TMS1 | ~(pcia_sel | tm_o);
  assign pcib_tms1 = TMS1 | ~(pcib_sel | tm_o);
  assign sms_tms1  = TMS1 | ~sms_sel | tm;          // parked for any P_TM_OPEN

  assign TDO1 = (arc_tdo1 & arc_sel) | (pcia_tdo1 & pcia_sel)
              | (pcib_tdo1 & pcib_sel) | (sms_tdo1 & sms_sel);

  wire oe_gated   = (arc_tdo1_oe & arc_sel) | (pcia_tdo1_oe & pcia_sel)
                  | (pcib_tdo1_oe & pcib_sel) | (sms_tdo1_oe & sms_sel);
  wire oe_ungated = arc_tdo1_oe | pcia_tdo1_oe | pcib_tdo1_oe | sms_tdo1_oe;
  assign TDO1_OE  = P_OE_GATED ? oe_gated : oe_ungated;  // D-29
endmodule
`default_nettype wire
