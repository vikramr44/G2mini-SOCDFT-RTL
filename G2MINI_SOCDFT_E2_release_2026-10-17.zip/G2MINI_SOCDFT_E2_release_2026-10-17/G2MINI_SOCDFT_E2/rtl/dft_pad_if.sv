// Artifact identity: RTL
// dft_pad_if: pad interface of SOC_DFT (spec r0.91 Section 7).
// Buffers the static and scan pins, forms dftmax_i, drives the one DFTSO_OE net and
// creates rst_dtr_n from PwrOk through a reset synchroniser cell on TCK1.
`timescale 1ns/1ps
`default_nettype none
module dft_pad_if #(
  parameter bit P_DFTSO_HIZ_M0 = 1'b1,  // CONF-03
  parameter bit P_DFTMAX_COMP  = 1'b1   // CONF-39
) (
  input  wire        DFTTM,
  input  wire        DFTMAX,
  input  wire        DFTSE,
  input  wire [dft_part_map_pkg::NPIN-1:0] DFTSI,
  output wire [dft_part_map_pkg::NPIN-1:0] DFTSO,
  output wire        DFTSO_OE,
  input  wire        PwrOk,
  input  wire        TCK1,
  output wire        tm,
  output wire        dftmax_i,
  output wire        dftse_i,
  output wire [dft_part_map_pkg::NPIN-1:0] dftsi_i,
  input  wire [dft_part_map_pkg::NPIN-1:0] dftso_o,
  output wire        rst_dtr_n
);
  assign tm       = DFTTM;
  assign dftse_i  = DFTSE;
  assign dftmax_i = (DFTMAX == P_DFTMAX_COMP);       // 1 = compressed (7.3)
  assign dftsi_i  = DFTSI;                            // no synchroniser (7.3)
  assign DFTSO    = dftso_o;
  assign DFTSO_OE = P_DFTSO_HIZ_M0 ? tm : 1'b1;       // one OE net (6.5.1)

  // PwrOk reset for the DTR shadows: asynchronous assert, release on the
  // second rising TCK1 after PwrOk = 1 (REQ-03).
  dft_rst_sync u_dft_rst_sync_dtr_dont_touch (
    .clk_i  (TCK1),
    .rst_ni (PwrOk),
    .rst_no (rst_dtr_n)
  );
endmodule
`default_nettype wire
