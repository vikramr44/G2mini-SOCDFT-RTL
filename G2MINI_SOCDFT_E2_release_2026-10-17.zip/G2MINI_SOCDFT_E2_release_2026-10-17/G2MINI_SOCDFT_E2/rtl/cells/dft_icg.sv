// Artifact identity: RTL
// dft_icg: integrated clock gate cell for TDRCLK (spec r0.91 18.1).
// The body is the AND of 18.1; synthesis binds the instance to the library
// latch-based ICG with dont_touch (IN-26) and LEC maps the cell to this body.
// en_i is a falling-TCK1 shadow, so it changes only while clk_i is low.
`timescale 1ns/1ps
`default_nettype none
module dft_icg (
  input  wire clk_i,
  input  wire en_i,
  output wire gclk_o
);
  localparam bit EN_OPEN = 1'b1;  // en_i value that passes the clock
  assign gclk_o = clk_i & (en_i == EN_OPEN);
endmodule
`default_nettype wire
