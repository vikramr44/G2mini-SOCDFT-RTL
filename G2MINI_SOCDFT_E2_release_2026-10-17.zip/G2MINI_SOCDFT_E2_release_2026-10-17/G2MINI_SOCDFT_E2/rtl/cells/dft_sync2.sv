// Artifact identity: RTL
// dft_sync2: P_WIDTH-bit two-flop level synchroniser cell, no reset (spec r0.91 10.4, 18.4).
`timescale 1ns/1ps
`default_nettype none
module dft_sync2 #(
  parameter int P_WIDTH = 1
) (
  input  wire               clk_i,
  input  wire [P_WIDTH-1:0] d_i,
  output wire [P_WIDTH-1:0] q_o
);
  logic [P_WIDTH-1:0] meta_q;
  logic [P_WIDTH-1:0] sync_q;
  always_ff @(posedge clk_i) begin
    meta_q <= d_i;
    sync_q <= meta_q;
  end
  assign q_o = sync_q;
endmodule
`default_nettype wire
