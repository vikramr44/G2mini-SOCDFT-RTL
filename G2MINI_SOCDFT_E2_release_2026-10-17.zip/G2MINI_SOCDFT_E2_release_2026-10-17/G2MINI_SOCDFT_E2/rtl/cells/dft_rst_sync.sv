// Artifact identity: RTL
// dft_rst_sync: asynchronous-assert, synchronous-de-assert reset synchroniser cell.
// rst_no falls with rst_ni and rises on the second rising clk_i after rst_ni rises.
// Spec r0.9 7.3 (rst_dtr_n) and 15.4 (WRSTN); technology cell per D89, bound to the
// library reset synchroniser at synthesis (IN-26).
`timescale 1ns/1ps
`default_nettype none
module dft_rst_sync (
  input  wire clk_i,
  input  wire rst_ni,
  output wire rst_no
);
  // verilator lint_off SYNCASYNCNET
  logic [1:0] sync_q;
  // verilator lint_on SYNCASYNCNET
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) sync_q <= 2'b00;
    else         sync_q <= {sync_q[0], 1'b1};
  end
  assign rst_no = sync_q[1];
endmodule
`default_nettype wire
