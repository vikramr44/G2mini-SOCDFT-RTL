// Artifact identity: RTL
// dft_mux2: 2:1 test-control mux cell (spec r0.91 18.1, 24.11): every router selection
// and the CRG reset muxes. y_o = s_i ? b_i : a_i; bound to a library mux cell with
// dont_touch, so ATPG and LEC see the RTL structure (12.3).
`timescale 1ns/1ps
`default_nettype none
module dft_mux2 (
  input  wire a_i,
  input  wire b_i,
  input  wire s_i,
  output wire y_o
);
  localparam bit SEL_B = 1'b1;   // s_i value that selects b_i
  assign y_o = (s_i == SEL_B) ? b_i : a_i;
endmodule
`default_nettype wire
