// Artifact identity: RTL
// soc_dft: SOC_DFT chip-top DFT controller, top level (spec r0.91 Section 6, Appendix B).
// Full build by default (P_PARTITIONED = 1): the partition decode of 11.3 and the scan
// router dft_scan_rtr over the generated dft_part_map_pkg; P_PARTITIONED = 0, the partial
// build, is withdrawn (CONF-38 closed) and refused by dft_mode_dec at elaboration. SMS shell with its
// TAP stand-in. Port names, directions and widths are Appendix B; the pin count and
// every channel width come from dft_part_map_pkg.
`timescale 1ns/1ps
`default_nettype none
module soc_dft
#(
  parameter int unsigned P_IDCODE       = 32'h0000_0001,  // CONF-10: set by the chip top
  parameter bit          P_OE_GATED     = 1'b1,           // CONF-07
  parameter bit          P_TM_OPEN      = 1'b1,           // 8.4
  parameter bit          P_DFTSO_HIZ_M0 = 1'b1,           // CONF-03
  parameter int unsigned P_CFG_RST      = 32'h003F_FFA5,  // CONF-06 (10.2)
  parameter int unsigned P_LPDDR_RST    = 32'h0000_0000,  // CONF-26 (10.3)
  parameter int unsigned P_RTL_REV      = 32'h05,          // Table 82 default
  parameter bit          P_TDR_EN_EDGE  = 1'b1,           // CONF-25
  parameter bit          P_DFTMAX_COMP  = 1'b1,           // CONF-39
  parameter int          P_SMS_IR_LEN   = 4,              // CONF-40
  parameter int unsigned P_SMS_IDCODE   = 32'h0001_0001,
  parameter bit          P_PARTITIONED  = 1'b1            // 11.3: 1 full build; 0 refused (partial build withdrawn)
) (
  // pad side (6.5.1)
  input  wire        DFTTM,
  input  wire        DFTMAX,
  input  wire        DFTSE,
  input  wire [dft_part_map_pkg::NPIN-1:0] DFTSI,
  output wire [dft_part_map_pkg::NPIN-1:0] DFTSO,
  output wire        DFTSO_OE,
  input  wire [1:0]  TSEL1,
  input  wire        TCK1,
  input  wire        TMS1,
  input  wire        TDI1,
  input  wire        TRSTN1,
  output wire        TDO1,
  output wire        TDO1_OE,
  // verilator lint_off SYNCASYNCNET
  input  wire        PwrOk,
  // verilator lint_on SYNCASYNCNET
  input  wire        Rstn,
  // JTAG targets (6.5.2)
  output wire        arc_tms1,
  output wire        pcia_tms1,
  output wire        pcib_tms1,
  input  wire        arc_tdo1,
  input  wire        arc_tdo1_oe,
  input  wire        pcia_tdo1,
  input  wire        pcia_tdo1_oe,
  input  wire        pcib_tdo1,
  input  wire        pcib_tdo1_oe,
  // blocks 0..10 (6.5.5)
  output wire        scc_dfttm,
  output wire        scc_scan_shift_en,
  output wire        scc_wrap_shift_en,
  output wire        scc_test_mode_tp,
  output wire [3:0]  scc_test_mode,
  output wire [dft_part_map_pkg::NCH_SCC-1:0] scc_test_si,
  input  wire [dft_part_map_pkg::NCH_SCC-1:0] scc_test_so,
  output wire [dft_part_map_pkg::NWRAP-1:0] scc_wrap_si,
  input  wire [dft_part_map_pkg::NWRAP-1:0] scc_wrap_so,
  output wire        hic_dfttm,
  output wire        hic_scan_shift_en,
  output wire        hic_wrap_shift_en,
  output wire        hic_test_mode_tp,
  output wire [3:0]  hic_test_mode,
  output wire [dft_part_map_pkg::NCH_HIC-1:0] hic_test_si,
  input  wire [dft_part_map_pkg::NCH_HIC-1:0] hic_test_so,
  output wire [dft_part_map_pkg::NWRAP-1:0] hic_wrap_si,
  input  wire [dft_part_map_pkg::NWRAP-1:0] hic_wrap_so,
  output wire        g2muc_dfttm,
  output wire        g2muc_scan_shift_en,
  output wire        g2muc_wrap_shift_en,
  output wire        g2muc_test_mode_tp,
  output wire [3:0]  g2muc_test_mode,
  output wire [dft_part_map_pkg::NCH_G2MUC-1:0] g2muc_test_si,
  input  wire [dft_part_map_pkg::NCH_G2MUC-1:0] g2muc_test_so,
  output wire [dft_part_map_pkg::NWRAP-1:0] g2muc_wrap_si,
  input  wire [dft_part_map_pkg::NWRAP-1:0] g2muc_wrap_so,
  output wire        l4ga_dfttm,
  output wire        l4ga_scan_shift_en,
  output wire        l4ga_wrap_shift_en,
  output wire        l4ga_test_mode_tp,
  output wire [3:0]  l4ga_test_mode,
  output wire [dft_part_map_pkg::NCH_L4GA-1:0] l4ga_test_si,
  input  wire [dft_part_map_pkg::NCH_L4GA-1:0] l4ga_test_so,
  output wire [dft_part_map_pkg::NWRAP-1:0] l4ga_wrap_si,
  input  wire [dft_part_map_pkg::NWRAP-1:0] l4ga_wrap_so,
  output wire        l4gb_dfttm,
  output wire        l4gb_scan_shift_en,
  output wire        l4gb_wrap_shift_en,
  output wire        l4gb_test_mode_tp,
  output wire [3:0]  l4gb_test_mode,
  output wire [dft_part_map_pkg::NCH_L4GB-1:0] l4gb_test_si,
  input  wire [dft_part_map_pkg::NCH_L4GB-1:0] l4gb_test_so,
  output wire [dft_part_map_pkg::NWRAP-1:0] l4gb_wrap_si,
  input  wire [dft_part_map_pkg::NWRAP-1:0] l4gb_wrap_so,
  output wire        pcia_dfttm,
  output wire        pcia_scan_shift_en,
  output wire        pcia_wrap_shift_en,
  output wire        pcia_test_mode_tp,
  output wire [3:0]  pcia_test_mode,
  output wire [dft_part_map_pkg::NCH_PCIA-1:0] pcia_test_si,
  input  wire [dft_part_map_pkg::NCH_PCIA-1:0] pcia_test_so,
  output wire [dft_part_map_pkg::NWRAP-1:0] pcia_wrap_si,
  input  wire [dft_part_map_pkg::NWRAP-1:0] pcia_wrap_so,
  output wire        pcib_dfttm,
  output wire        pcib_scan_shift_en,
  output wire        pcib_wrap_shift_en,
  output wire        pcib_test_mode_tp,
  output wire [3:0]  pcib_test_mode,
  output wire [dft_part_map_pkg::NCH_PCIB-1:0] pcib_test_si,
  input  wire [dft_part_map_pkg::NCH_PCIB-1:0] pcib_test_so,
  output wire [dft_part_map_pkg::NWRAP-1:0] pcib_wrap_si,
  input  wire [dft_part_map_pkg::NWRAP-1:0] pcib_wrap_so,
  output wire        ahb_dfttm,
  output wire        ahb_scan_shift_en,
  output wire        ahb_wrap_shift_en,
  output wire        ahb_test_mode_tp,
  output wire [3:0]  ahb_test_mode,
  output wire [dft_part_map_pkg::NCH_AHB-1:0] ahb_test_si,
  input  wire [dft_part_map_pkg::NCH_AHB-1:0] ahb_test_so,
  output wire [dft_part_map_pkg::NWRAP-1:0] ahb_wrap_si,
  input  wire [dft_part_map_pkg::NWRAP-1:0] ahb_wrap_so,
  output wire        apb_dfttm,
  output wire        apb_scan_shift_en,
  output wire        apb_wrap_shift_en,
  output wire        apb_test_mode_tp,
  output wire [3:0]  apb_test_mode,
  output wire [dft_part_map_pkg::NCH_APB-1:0] apb_test_si,
  input  wire [dft_part_map_pkg::NCH_APB-1:0] apb_test_so,
  output wire [dft_part_map_pkg::NWRAP-1:0] apb_wrap_si,
  input  wire [dft_part_map_pkg::NWRAP-1:0] apb_wrap_so,
  output wire        axis_dfttm,
  output wire        axis_scan_shift_en,
  output wire        axis_wrap_shift_en,
  output wire        axis_test_mode_tp,
  output wire [3:0]  axis_test_mode,
  output wire [dft_part_map_pkg::NCH_AXIS-1:0] axis_test_si,
  input  wire [dft_part_map_pkg::NCH_AXIS-1:0] axis_test_so,
  output wire [dft_part_map_pkg::NWRAP-1:0] axis_wrap_si,
  input  wire [dft_part_map_pkg::NWRAP-1:0] axis_wrap_so,
  output wire        axim_dfttm,
  output wire        axim_scan_shift_en,
  output wire        axim_wrap_shift_en,
  output wire        axim_test_mode_tp,
  output wire [3:0]  axim_test_mode,
  output wire [dft_part_map_pkg::NCH_AXIM-1:0] axim_test_si,
  input  wire [dft_part_map_pkg::NCH_AXIM-1:0] axim_test_so,
  output wire [dft_part_map_pkg::NWRAP-1:0] axim_wrap_si,
  input  wire [dft_part_map_pkg::NWRAP-1:0] axim_wrap_so,
  // TOP glue chains (12.9)
  output wire        top_scan_shift_en,
  output wire [dft_part_map_pkg::NTOP-1:0] top_test_si,
  input  wire [dft_part_map_pkg::NTOP-1:0] top_test_so,
  // SMS (6.5.3, 14.2)
  output wire [4:0]  scc_sms_in,
  output wire [4:0]  hic_sms_in,
  output wire [4:0]  g2muc_sms_in,
  output wire [4:0]  l4ga_sms_in,
  output wire [4:0]  l4gb_sms_in,
  output wire [4:0]  ahb_sms_in,
  output wire [4:0]  lpddr_sms_in,
  output wire [9:0]  pcia_sms_in,
  output wire [9:0]  pcib_sms_in,
  input  wire        scc_sms_out,
  input  wire        hic_sms_out,
  input  wire        g2muc_sms_out,
  input  wire        l4ga_sms_out,
  input  wire        l4gb_sms_out,
  input  wire        ahb_sms_out,
  input  wire        lpddr_sms_out,
  input  wire [1:0]  pcia_sms_out,
  input  wire [1:0]  pcib_sms_out,
  // LPDDR (6.5.4)
  output wire        lpddr_atpg_mode,
  output wire        lpddr_compression_mode,
  output wire        lpddr_phy0_burnin,
  output wire        lpddr_phy1_burnin,
  output wire [15:0] lpddr_atpg_se,
  output wire [1:0]  lpddr_scan_ctl,
  output wire        lpddr_scan_shift_cg,
  output wire        lpddr_scan_rstn,
  output wire [2:0]  lpddr_sms_dm,
  output wire [6:0]  lpddr_ring_bypass,
  output wire        lpddr_sfp_dft_mode,
  output wire        lpddr_tdrclk,
  output wire        lpddr_wrstn,
  output wire [1:0]  lpddr_cmd_tdr_capture_en,
  output wire [1:0]  lpddr_cmd_tdr_shift_en,
  output wire [1:0]  lpddr_cmd_tdr_update_en,
  output wire [1:0]  lpddr_rd_tdr_capture_en,
  output wire [1:0]  lpddr_rd_tdr_shift_en,
  output wire [1:0]  lpddr_rd_tdr_update_en,
  output wire [1:0]  lpddr_wsi,
  input  wire [1:0]  lpddr_cmd_tdr_tdo,
  input  wire [1:0]  lpddr_rd_tdr_tdo,
  // CRG (6.5.6)
  output wire        dft_crg_test_clk_sel,
  output wire        dft_crg_rst_byp,
  output wire        dft_crg_rst_n_test,
  output wire [2:0]  dft_crg_pll_byp,
  output wire [12:0] dft_crg_blk_clk_en,
  output wire [12:0] dft_crg_comp_clk_en,
  output wire [4:0]  dft_crg_lpddr_clk_en,
  input  wire [2:0]  crg_pll_ready
);
  // internal nets (6.6)
  wire tm;
  wire dftmax_i;
  wire dftse_i;
  wire [dft_part_map_pkg::NPIN-1:0] dftsi_i;
  wire [dft_part_map_pkg::NPIN-1:0] dftso_o;
  wire rst_dtr_n;
  wire sms_tms1;
  wire sms_tdo1;
  wire sms_tdo1_oe;
  wire tap_tdi;
  wire [3:0] tap_state;
  wire [4:0] ir;
  wire capture_dr;
  wire shift_dr;
  wire update_dr;
  wire dr_tdo_cfg;
  wire dr_tdo_lpddr;
  wire dr_tdo_sts;
  wire dr_tdo_ddr;
  wire [31:0] dtr_cfg;
  wire [31:0] dtr_lpddr;
  wire ddr_tdr_en;
  wire [3:0] part;
  wire [dft_part_map_pkg::NBLK-1:0] sel;
  wire [dft_part_map_pkg::NBLK-1:0] active;
  wire [dft_part_map_pkg::NSBLK-1:0] blk_dfttm;
  wire [dft_part_map_pkg::NSBLK-1:0] blk_scan_shift_en;
  wire [dft_part_map_pkg::NSBLK-1:0] blk_wrap_shift_en;
  wire [dft_part_map_pkg::TMW*dft_part_map_pkg::NSBLK-1:0] blk_test_mode;
  wire [dft_part_map_pkg::NSBLK-1:0] blk_test_mode_tp;
  wire extest;
  wire loopback;
  wire [dft_part_map_pkg::NCH_SUM-1:0] test_si_all;
  wire [dft_part_map_pkg::NCH_SUM-1:0] test_so_all;
  wire [dft_part_map_pkg::NWRAP*dft_part_map_pkg::NSBLK-1:0] wrap_si_all;
  wire [dft_part_map_pkg::NWRAP*dft_part_map_pkg::NSBLK-1:0] wrap_so_all;
  // verilator lint_off UNUSEDSIGNAL
  wire sms_tap_tdo_oe;
  // verilator lint_on UNUSEDSIGNAL

  dft_pad_if #(.P_DFTSO_HIZ_M0(P_DFTSO_HIZ_M0), .P_DFTMAX_COMP(P_DFTMAX_COMP)) u_pad_if (
    .DFTTM(DFTTM), .DFTMAX(DFTMAX), .DFTSE(DFTSE), .DFTSI(DFTSI), .DFTSO(DFTSO), .DFTSO_OE(DFTSO_OE),
    .PwrOk(PwrOk), .TCK1(TCK1), .tm(tm), .dftmax_i(dftmax_i), .dftse_i(dftse_i), .dftsi_i(dftsi_i),
    .dftso_o(dftso_o), .rst_dtr_n(rst_dtr_n));

  dft_jtag1_rtr #(.P_OE_GATED(P_OE_GATED), .P_TM_OPEN(P_TM_OPEN)) u_jtag1_rtr (
    .TSEL1(TSEL1), .TMS1(TMS1), .tm(tm), .arc_tms1(arc_tms1), .pcia_tms1(pcia_tms1), .pcib_tms1(pcib_tms1),
    .sms_tms1(sms_tms1), .arc_tdo1(arc_tdo1), .arc_tdo1_oe(arc_tdo1_oe), .pcia_tdo1(pcia_tdo1),
    .pcia_tdo1_oe(pcia_tdo1_oe), .pcib_tdo1(pcib_tdo1), .pcib_tdo1_oe(pcib_tdo1_oe),
    .sms_tdo1(sms_tdo1), .sms_tdo1_oe(sms_tdo1_oe), .TDO1(TDO1), .TDO1_OE(TDO1_OE));

  dft_tap #(.P_IR_LEN(5), .P_DR_CLIENTS(1'b1), .P_IDCODE(P_IDCODE)) u_tap (
    .TCK1(TCK1), .TRSTN1(TRSTN1), .tap_tdi(tap_tdi), .sms_tms1(sms_tms1), .sms_tdo1(sms_tdo1),
    .sms_tdo1_oe(sms_tdo1_oe), .tap_state(tap_state), .ir(ir), .capture_dr(capture_dr), .shift_dr(shift_dr),
    .update_dr(update_dr), .dr_tdo_cfg(dr_tdo_cfg), .dr_tdo_lpddr(dr_tdo_lpddr), .dr_tdo_sts(dr_tdo_sts),
    .dr_tdo_ddr(dr_tdo_ddr));

  dft_dtr #(.P_CFG_RST(P_CFG_RST), .P_LPDDR_RST(P_LPDDR_RST), .P_RTL_REV(P_RTL_REV)) u_dtr (
    .TCK1(TCK1), .tap_tdi(tap_tdi), .rst_dtr_n(rst_dtr_n), .ir(ir), .capture_dr(capture_dr), .shift_dr(shift_dr),
    .update_dr(update_dr), .tm(tm), .dftmax_i(dftmax_i), .TSEL1(TSEL1), .crg_pll_ready(crg_pll_ready), .PwrOk(PwrOk),
    .part(part), .dr_tdo_cfg(dr_tdo_cfg), .dr_tdo_lpddr(dr_tdo_lpddr), .dr_tdo_sts(dr_tdo_sts), .dtr_cfg(dtr_cfg),
    .dtr_lpddr(dtr_lpddr), .ddr_tdr_en(ddr_tdr_en), .lpddr_sms_dm(lpddr_sms_dm), .lpddr_ring_bypass(lpddr_ring_bypass),
    .lpddr_sfp_dft_mode(lpddr_sfp_dft_mode));

  dft_mode_dec #(.P_PARTITIONED(P_PARTITIONED)) u_mode_dec (
    .tm(tm), .dftmax_i(dftmax_i), .dftse_i(dftse_i), .dtr_cfg(dtr_cfg), .dtr_lpddr(dtr_lpddr), .part(part),
    .sel(sel), .active(active), .extest(extest), .loopback(loopback), .blk_dfttm(blk_dfttm),
    .blk_scan_shift_en(blk_scan_shift_en), .blk_wrap_shift_en(blk_wrap_shift_en), .blk_test_mode(blk_test_mode),
    .blk_test_mode_tp(blk_test_mode_tp), .top_scan_shift_en(top_scan_shift_en), .lpddr_atpg_mode(lpddr_atpg_mode),
    .lpddr_compression_mode(lpddr_compression_mode), .lpddr_phy0_burnin(lpddr_phy0_burnin),
    .lpddr_phy1_burnin(lpddr_phy1_burnin), .lpddr_atpg_se(lpddr_atpg_se), .lpddr_scan_ctl(lpddr_scan_ctl),
    .lpddr_scan_shift_cg(lpddr_scan_shift_cg));

  dft_crg_ctl u_crg_ctl (
    .tm(tm), .dftmax_i(dftmax_i), .Rstn(Rstn), .dtr_cfg(dtr_cfg), .sel(sel), .active(active),
    .dft_crg_test_clk_sel(dft_crg_test_clk_sel), .dft_crg_pll_byp(dft_crg_pll_byp),
    .dft_crg_blk_clk_en(dft_crg_blk_clk_en), .dft_crg_comp_clk_en(dft_crg_comp_clk_en),
    .dft_crg_lpddr_clk_en(dft_crg_lpddr_clk_en), .dft_crg_rst_byp(dft_crg_rst_byp),
    .dft_crg_rst_n_test(dft_crg_rst_n_test), .lpddr_scan_rstn(lpddr_scan_rstn));

  dft_ddr_tdr #(.P_TDR_EN_EDGE(P_TDR_EN_EDGE)) u_ddr_tdr (
    .TCK1(TCK1), .TRSTN1(TRSTN1), .tap_tdi(tap_tdi), .tap_state(tap_state), .ir(ir), .tm(tm),
    .ddr_tdr_en(ddr_tdr_en), .lpddr_tdrclk(lpddr_tdrclk), .lpddr_wrstn(lpddr_wrstn),
    .lpddr_cmd_tdr_capture_en(lpddr_cmd_tdr_capture_en), .lpddr_cmd_tdr_shift_en(lpddr_cmd_tdr_shift_en), .lpddr_cmd_tdr_update_en(lpddr_cmd_tdr_update_en),
    .lpddr_rd_tdr_capture_en(lpddr_rd_tdr_capture_en), .lpddr_rd_tdr_shift_en(lpddr_rd_tdr_shift_en), .lpddr_rd_tdr_update_en(lpddr_rd_tdr_update_en),
    .lpddr_wsi(lpddr_wsi), .lpddr_cmd_tdr_tdo(lpddr_cmd_tdr_tdo), .lpddr_rd_tdr_tdo(lpddr_rd_tdr_tdo),
    .dr_tdo_ddr(dr_tdo_ddr));

  dft_sms_srv #(.P_SMS_IR_LEN(P_SMS_IR_LEN), .P_SMS_IDCODE(P_SMS_IDCODE)) u_sms_srv (
    .TCK1(TCK1), .TRSTN1(TRSTN1), .TDI1(TDI1), .sms_tms1(sms_tms1), .sms_tap_tdo(tap_tdi),
    .sms_tap_tdo_oe(sms_tap_tdo_oe), .DFTTM(tm), .DFTSE(dftse_i),
    .scc_sms_in(scc_sms_in), .hic_sms_in(hic_sms_in), .g2muc_sms_in(g2muc_sms_in), .l4ga_sms_in(l4ga_sms_in), .l4gb_sms_in(l4gb_sms_in), .ahb_sms_in(ahb_sms_in), .lpddr_sms_in(lpddr_sms_in), .pcia_sms_in(pcia_sms_in), .pcib_sms_in(pcib_sms_in),
    .scc_sms_out(scc_sms_out), .hic_sms_out(hic_sms_out), .g2muc_sms_out(g2muc_sms_out), .l4ga_sms_out(l4ga_sms_out), .l4gb_sms_out(l4gb_sms_out), .ahb_sms_out(ahb_sms_out), .lpddr_sms_out(lpddr_sms_out), .pcia_sms_out(pcia_sms_out), .pcib_sms_out(pcib_sms_out));

  // Scan channel routing (12.3): the router in the full build, its boundary in the partial build.
  if (P_PARTITIONED) begin : g_scan_rtr
    dft_scan_rtr u_scan_rtr (
      .tm(tm), .part(part), .sel(sel[dft_part_map_pkg::NSBLK-1:0]), .extest(extest), .loopback(loopback),
      .dftsi_i(dftsi_i), .dftso_o(dftso_o), .test_si_all(test_si_all), .test_so_all(test_so_all),
      .wrap_si_all(wrap_si_all), .wrap_so_all(wrap_so_all), .top_test_si(top_test_si), .top_test_so(top_test_so));
  end else begin : g_scan_hold
    dft_scan_hold u_scan_hold (
      .dftsi_i(dftsi_i), .dftso_o(dftso_o), .test_si_all(test_si_all), .test_so_all(test_so_all),
      .wrap_si_all(wrap_si_all), .wrap_so_all(wrap_so_all), .top_test_si(top_test_si), .top_test_so(top_test_so));
  end

  // per-block slices of the router's flat channel buses (offsets from dft_part_map_pkg)
  assign scc_test_si = test_si_all[dft_part_map_pkg::OFF_SCC +: dft_part_map_pkg::NCH_SCC];
  assign test_so_all[dft_part_map_pkg::OFF_SCC +: dft_part_map_pkg::NCH_SCC] = scc_test_so;
  assign scc_wrap_si = wrap_si_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_SCC +: dft_part_map_pkg::NWRAP];
  assign wrap_so_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_SCC +: dft_part_map_pkg::NWRAP] = scc_wrap_so;
  assign hic_test_si = test_si_all[dft_part_map_pkg::OFF_HIC +: dft_part_map_pkg::NCH_HIC];
  assign test_so_all[dft_part_map_pkg::OFF_HIC +: dft_part_map_pkg::NCH_HIC] = hic_test_so;
  assign hic_wrap_si = wrap_si_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_HIC +: dft_part_map_pkg::NWRAP];
  assign wrap_so_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_HIC +: dft_part_map_pkg::NWRAP] = hic_wrap_so;
  assign g2muc_test_si = test_si_all[dft_part_map_pkg::OFF_G2MUC +: dft_part_map_pkg::NCH_G2MUC];
  assign test_so_all[dft_part_map_pkg::OFF_G2MUC +: dft_part_map_pkg::NCH_G2MUC] = g2muc_test_so;
  assign g2muc_wrap_si = wrap_si_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_G2MUC +: dft_part_map_pkg::NWRAP];
  assign wrap_so_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_G2MUC +: dft_part_map_pkg::NWRAP] = g2muc_wrap_so;
  assign l4ga_test_si = test_si_all[dft_part_map_pkg::OFF_L4GA +: dft_part_map_pkg::NCH_L4GA];
  assign test_so_all[dft_part_map_pkg::OFF_L4GA +: dft_part_map_pkg::NCH_L4GA] = l4ga_test_so;
  assign l4ga_wrap_si = wrap_si_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_L4GA +: dft_part_map_pkg::NWRAP];
  assign wrap_so_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_L4GA +: dft_part_map_pkg::NWRAP] = l4ga_wrap_so;
  assign l4gb_test_si = test_si_all[dft_part_map_pkg::OFF_L4GB +: dft_part_map_pkg::NCH_L4GB];
  assign test_so_all[dft_part_map_pkg::OFF_L4GB +: dft_part_map_pkg::NCH_L4GB] = l4gb_test_so;
  assign l4gb_wrap_si = wrap_si_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_L4GB +: dft_part_map_pkg::NWRAP];
  assign wrap_so_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_L4GB +: dft_part_map_pkg::NWRAP] = l4gb_wrap_so;
  assign pcia_test_si = test_si_all[dft_part_map_pkg::OFF_PCIA +: dft_part_map_pkg::NCH_PCIA];
  assign test_so_all[dft_part_map_pkg::OFF_PCIA +: dft_part_map_pkg::NCH_PCIA] = pcia_test_so;
  assign pcia_wrap_si = wrap_si_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_PCIA +: dft_part_map_pkg::NWRAP];
  assign wrap_so_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_PCIA +: dft_part_map_pkg::NWRAP] = pcia_wrap_so;
  assign pcib_test_si = test_si_all[dft_part_map_pkg::OFF_PCIB +: dft_part_map_pkg::NCH_PCIB];
  assign test_so_all[dft_part_map_pkg::OFF_PCIB +: dft_part_map_pkg::NCH_PCIB] = pcib_test_so;
  assign pcib_wrap_si = wrap_si_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_PCIB +: dft_part_map_pkg::NWRAP];
  assign wrap_so_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_PCIB +: dft_part_map_pkg::NWRAP] = pcib_wrap_so;
  assign ahb_test_si = test_si_all[dft_part_map_pkg::OFF_AHB +: dft_part_map_pkg::NCH_AHB];
  assign test_so_all[dft_part_map_pkg::OFF_AHB +: dft_part_map_pkg::NCH_AHB] = ahb_test_so;
  assign ahb_wrap_si = wrap_si_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_AHB +: dft_part_map_pkg::NWRAP];
  assign wrap_so_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_AHB +: dft_part_map_pkg::NWRAP] = ahb_wrap_so;
  assign apb_test_si = test_si_all[dft_part_map_pkg::OFF_APB +: dft_part_map_pkg::NCH_APB];
  assign test_so_all[dft_part_map_pkg::OFF_APB +: dft_part_map_pkg::NCH_APB] = apb_test_so;
  assign apb_wrap_si = wrap_si_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_APB +: dft_part_map_pkg::NWRAP];
  assign wrap_so_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_APB +: dft_part_map_pkg::NWRAP] = apb_wrap_so;
  assign axis_test_si = test_si_all[dft_part_map_pkg::OFF_AXIS +: dft_part_map_pkg::NCH_AXIS];
  assign test_so_all[dft_part_map_pkg::OFF_AXIS +: dft_part_map_pkg::NCH_AXIS] = axis_test_so;
  assign axis_wrap_si = wrap_si_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_AXIS +: dft_part_map_pkg::NWRAP];
  assign wrap_so_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_AXIS +: dft_part_map_pkg::NWRAP] = axis_wrap_so;
  assign axim_test_si = test_si_all[dft_part_map_pkg::OFF_AXIM +: dft_part_map_pkg::NCH_AXIM];
  assign test_so_all[dft_part_map_pkg::OFF_AXIM +: dft_part_map_pkg::NCH_AXIM] = axim_test_so;
  assign axim_wrap_si = wrap_si_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_AXIM +: dft_part_map_pkg::NWRAP];
  assign wrap_so_all[dft_part_map_pkg::NWRAP*dft_part_map_pkg::B_AXIM +: dft_part_map_pkg::NWRAP] = axim_wrap_so;

  // per-block controls from dft_mode_dec (block b at bit b, code at [TMW*b +: TMW])
  assign scc_dfttm = blk_dfttm[0];  assign scc_scan_shift_en = blk_scan_shift_en[0];
  assign scc_wrap_shift_en = blk_wrap_shift_en[0];  assign scc_test_mode_tp = blk_test_mode_tp[0];
  assign scc_test_mode = blk_test_mode[0 +: 4];
  assign hic_dfttm = blk_dfttm[1];  assign hic_scan_shift_en = blk_scan_shift_en[1];
  assign hic_wrap_shift_en = blk_wrap_shift_en[1];  assign hic_test_mode_tp = blk_test_mode_tp[1];
  assign hic_test_mode = blk_test_mode[4 +: 4];
  assign g2muc_dfttm = blk_dfttm[2];  assign g2muc_scan_shift_en = blk_scan_shift_en[2];
  assign g2muc_wrap_shift_en = blk_wrap_shift_en[2];  assign g2muc_test_mode_tp = blk_test_mode_tp[2];
  assign g2muc_test_mode = blk_test_mode[8 +: 4];
  assign l4ga_dfttm = blk_dfttm[3];  assign l4ga_scan_shift_en = blk_scan_shift_en[3];
  assign l4ga_wrap_shift_en = blk_wrap_shift_en[3];  assign l4ga_test_mode_tp = blk_test_mode_tp[3];
  assign l4ga_test_mode = blk_test_mode[12 +: 4];
  assign l4gb_dfttm = blk_dfttm[4];  assign l4gb_scan_shift_en = blk_scan_shift_en[4];
  assign l4gb_wrap_shift_en = blk_wrap_shift_en[4];  assign l4gb_test_mode_tp = blk_test_mode_tp[4];
  assign l4gb_test_mode = blk_test_mode[16 +: 4];
  assign pcia_dfttm = blk_dfttm[5];  assign pcia_scan_shift_en = blk_scan_shift_en[5];
  assign pcia_wrap_shift_en = blk_wrap_shift_en[5];  assign pcia_test_mode_tp = blk_test_mode_tp[5];
  assign pcia_test_mode = blk_test_mode[20 +: 4];
  assign pcib_dfttm = blk_dfttm[6];  assign pcib_scan_shift_en = blk_scan_shift_en[6];
  assign pcib_wrap_shift_en = blk_wrap_shift_en[6];  assign pcib_test_mode_tp = blk_test_mode_tp[6];
  assign pcib_test_mode = blk_test_mode[24 +: 4];
  assign ahb_dfttm = blk_dfttm[7];  assign ahb_scan_shift_en = blk_scan_shift_en[7];
  assign ahb_wrap_shift_en = blk_wrap_shift_en[7];  assign ahb_test_mode_tp = blk_test_mode_tp[7];
  assign ahb_test_mode = blk_test_mode[28 +: 4];
  assign apb_dfttm = blk_dfttm[8];  assign apb_scan_shift_en = blk_scan_shift_en[8];
  assign apb_wrap_shift_en = blk_wrap_shift_en[8];  assign apb_test_mode_tp = blk_test_mode_tp[8];
  assign apb_test_mode = blk_test_mode[32 +: 4];
  assign axis_dfttm = blk_dfttm[9];  assign axis_scan_shift_en = blk_scan_shift_en[9];
  assign axis_wrap_shift_en = blk_wrap_shift_en[9];  assign axis_test_mode_tp = blk_test_mode_tp[9];
  assign axis_test_mode = blk_test_mode[36 +: 4];
  assign axim_dfttm = blk_dfttm[10];  assign axim_scan_shift_en = blk_scan_shift_en[10];
  assign axim_wrap_shift_en = blk_wrap_shift_en[10];  assign axim_test_mode_tp = blk_test_mode_tp[10];
  assign axim_test_mode = blk_test_mode[40 +: 4];
endmodule
`default_nettype wire
