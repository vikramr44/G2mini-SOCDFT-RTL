// Artifact identity: RTL
// dft_mode_dec: test-mode decoder of SOC_DFT (spec r0.91 Section 11.3, Table 55).
// P_PARTITIONED = 1 (the default and the only legal value) decodes the partitions of 11.3
// over dft_part_map_pkg; P_PARTITIONED = 0, the partial build, is withdrawn (CONF-38 closed)
// and refused at elaboration. Outside the decode: per-block dfttm and test_mode_tp = tm, the
// LPDDR burn-in terms and scan_ctl = 2'b00 (CONF-19).
// Block vectors carry block b at bit b (b = 0..NSBLK-1) and its code at [TMW*b +: TMW].
`timescale 1ns/1ps
`default_nettype none
module dft_mode_dec #(
  parameter bit P_PARTITIONED = 1'b1     // 1: the partition decode of 11.3; 0 is refused (partial build withdrawn)
) (
  input  wire        tm,
  input  wire        dftmax_i,
  input  wire        dftse_i,
  // verilator lint_off UNUSEDSIGNAL
  input  wire [31:0] dtr_cfg,
  input  wire [31:0] dtr_lpddr,
  // verilator lint_on UNUSEDSIGNAL
  output wire [3:0]  part,
  output wire [dft_part_map_pkg::NBLK-1:0] sel,
  output wire [dft_part_map_pkg::NBLK-1:0] active,
  output wire        extest,
  output wire        loopback,
  output wire [dft_part_map_pkg::NSBLK-1:0] blk_dfttm,
  output wire [dft_part_map_pkg::NSBLK-1:0] blk_scan_shift_en,
  output wire [dft_part_map_pkg::NSBLK-1:0] blk_wrap_shift_en,
  output wire [dft_part_map_pkg::TMW*dft_part_map_pkg::NSBLK-1:0] blk_test_mode,
  output wire [dft_part_map_pkg::NSBLK-1:0] blk_test_mode_tp,
  output wire        top_scan_shift_en,
  output wire        lpddr_atpg_mode,
  output wire        lpddr_compression_mode,
  output wire        lpddr_phy0_burnin,
  output wire        lpddr_phy1_burnin,
  output wire [15:0] lpddr_atpg_se,
  output wire [1:0]  lpddr_scan_ctl,
  output wire        lpddr_scan_shift_cg
);
  localparam int NBLK  = dft_part_map_pkg::NBLK;
  localparam int NSBLK = dft_part_map_pkg::NSBLK;
  localparam int TMW   = dft_part_map_pkg::TMW;
  localparam int B_LPDDR = dft_part_map_pkg::B_LPDDR;
  // DTR_CFG and DTR_LPDDR field positions (spec Tables 50, 51)
  localparam int CFG_BURNIN       = 4;
  localparam int CFG_SE_GATE      = 21;
  localparam int LP_ATPG_MODE_OVR = 0;
  localparam int LP_ATPG_MODE_VAL = 1;
  localparam int LP_COMP_OVR      = 2;
  localparam int LP_COMP_VAL      = 3;
  localparam int LP_PHY0_BURNIN   = 4;
  localparam int LP_PHY1_BURNIN   = 5;
  localparam int LP_SCAN_SHIFT_CG = 17;

  // Architecture-independent outputs (11.3)
  assign part              = dtr_cfg[3:0];
  assign blk_dfttm         = {NSBLK{tm}};
  assign blk_test_mode_tp  = {NSBLK{tm}};
  assign lpddr_phy0_burnin = tm & dtr_cfg[CFG_BURNIN] & dtr_lpddr[LP_PHY0_BURNIN];
  assign lpddr_phy1_burnin = tm & dtr_cfg[CFG_BURNIN] & dtr_lpddr[LP_PHY1_BURNIN];
  assign lpddr_scan_ctl    = 2'b00;

  if (P_PARTITIONED) begin : g_decode
    // partition decode of 11.3
    wire in_range = (part >= 4'd1) & (part <= 4'd14);
    wire se_gate  = dtr_cfg[CFG_SE_GATE];
    assign sel      = {NBLK{tm & in_range}} & dft_part_map_pkg::PART_MAP_SEL[NBLK*part +: NBLK];
    assign extest   = tm & (part == dft_part_map_pkg::PART_EXTEST);
    assign loopback = tm & (part == dft_part_map_pkg::PART_LOOPBACK);
    assign active   = sel | ({NBLK{extest}} & dft_part_map_pkg::P0_MEMBER);
    for (genvar b = 0; b < NSBLK; b++) begin : g_blk
      assign blk_scan_shift_en[b] = tm & dftse_i & (active[b] | ~se_gate);
      assign blk_wrap_shift_en[b] = tm & dftse_i & (active[b] | ~se_gate);
      assign blk_test_mode[TMW*b +: TMW] =
          ~tm      ? dft_part_map_pkg::ENC_FUNC[TMW*b +: TMW]   :
          extest   ? dft_part_map_pkg::ENC_WRP_OF[TMW*b +: TMW] :
          ~sel[b]  ? dft_part_map_pkg::ENC_WRP_IF[TMW*b +: TMW] :
          dftmax_i ? dft_part_map_pkg::ENC_COMP[TMW*b +: TMW]   :
                     dft_part_map_pkg::ENC_SCAN[TMW*b +: TMW];
    end
    assign top_scan_shift_en      = tm & dftse_i & extest;
    assign lpddr_atpg_mode        = dtr_lpddr[LP_ATPG_MODE_OVR] ? dtr_lpddr[LP_ATPG_MODE_VAL] : (tm & active[B_LPDDR]);
    assign lpddr_compression_mode = dtr_lpddr[LP_COMP_OVR] ? dtr_lpddr[LP_COMP_VAL] : (tm & dftmax_i & sel[B_LPDDR]);
    assign lpddr_atpg_se          = {16{tm & dftse_i & active[B_LPDDR]}};
    assign lpddr_scan_shift_cg    = dtr_lpddr[LP_SCAN_SHIFT_CG] | (tm & dftse_i & active[B_LPDDR]);
  end else begin : g_refused
    // Elaboration stops here on Icarus and Yosys; Verilator 5.051 does not run an
    // elaboration-time $fatal in a generate block, so the same refusal also fires at time 0.
    $fatal(1, "dft_mode_dec: P_PARTITIONED = 0 is not a legal configuration; the partial build is withdrawn (CONF-38 closed)");
    initial $fatal(1, "dft_mode_dec: P_PARTITIONED = 0 is not a legal configuration; the partial build is withdrawn (CONF-38 closed)");
  end
endmodule
`default_nettype wire
