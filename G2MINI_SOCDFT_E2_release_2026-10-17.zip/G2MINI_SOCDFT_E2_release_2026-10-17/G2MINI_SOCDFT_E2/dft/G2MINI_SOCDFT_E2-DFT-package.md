# G2MINI_SOCDFT_E2 DFT package

Artifact identity: DFT package

**Owner:** semi_dft_engineer. **Phase:** DFT. **Design:** soc_dft built to source revision r0.92: the full build (P_PARTITIONED = 1) with the scan router and the 11.3 partition decode over the generated partition map, and the SMS shell carrying a dft_tap stand-in [src: declarations/mkm.json] [src: docs/arch/G2MINI_SOCDFT_E2-scan-routing-release.md]. **Inputs consumed:** the internal engineering microarchitecture revision 0.3, the MKM and the AKM, each with its digest [src: reports/consumption-records.md]. This package supersedes the r0.9 package, whose scan routing was held.

## DFT Package

Stage: Architecture
Gate decision: BLOCKED

The DFT architecture record is complete and its checks are clean [src: declarations/dft-declared.json] [src: tools/run_dft_checks.py]. The structural measurement runs on a tool present on this host and is calibrated [src: reports/dft-structural.json]. The scan path through SOC_DFT now exists and is verified at smoke depth in both simulators [src: reports/dual-sim.json]. Every ATPG and fault-coverage claim is still BLOCKED by name: no ATPG or fault-simulation tool is installed and no chip netlist with block CTL models exists [src: reports/dft-tool-probe.json]. Nothing in this package says scan-inserted or ATPG-run [canon: E4].

DFT strategy:
- Scan: SOC_DFT holds no scan flops; its 288 sequential cells are custom non-scan logic (`set_scan_element false`, CONF-34), and the router adds none [spec: 18.1] [src: reports/dft-structural.json]. SOC_DFT routes the block scan channels between DFTSI/DFTSO[19:0] and the 11 routed blocks: a gated scan-in fan-out, then per lane a 4:1 over the four INTEST modes, a 2:1 to the wrapper or TOP chain under EXTEST and a 2:1 for loopback, every selection a dont_touch dft_mux2 [spec: 12.3] [src: rtl/dft_scan_rtr.sv].
- Compression: owned by the DFT blocks (DFTMAX, CONF-21), not by SOC_DFT. SOC_DFT forwards dftmax_i and selects COMP or SCAN per block [spec: 11.3].
- MBIST: the SMS TAP and Server are generated IP (R7, IN-10) not inserted; the shell dft_sms_srv carries a dft_tap stand-in with IDCODE and BYPASS only, recorded EXTERNAL_DEPENDENCY. The SMS TAP and Server are excluded from scan (deviation D-1) [src: rtl/dft_sms_srv.sv] [src: declarations/adm.json].
- LBIST: none. The source's test strategy (Table 14) lists no logic BIST [spec: 3.3].
- IJTAG/TAP/boundary scan: one JTAG1 port routed to four TAP targets by TSEL1; the SOC_DFT TAP owns three DTRs and the DDRx TDR; exercised in both simulators by the smoke set [src: rtl/dft_jtag1_rtr.sv] [src: rtl/dft_tap.sv] [src: reports/dual-sim.json].
- OCC/at-speed: none in this revision (CONF-18); the record's `occ` section is a declared empty list [src: declarations/dft-declared.json].
- Test access topology: four INTEST modes on PART 1 to 4 (mode m on PART 1 + m, an assumption, ADM-23), EXTEST on PART 0, loopback on PART 15; mode 0 pcia, mode 1 pcib, mode 2 scc, g2muc, ahb, axis, mode 3 hic, l4ga, l4gb, apb, axim (pin 19 unmapped); EXTEST wrapper chains on pins 0 to 10 and TOP chains on 11 to 13 [spec: 12.7] [src: reports/part-map.json].

Traceability:

| DFT item | Source/MKM/RTL ID | Rationale | Status |
|---|---|---|---|
| Zero latches in SOC_DFT | REQ-27, rtl/ | Yosys `synth -flatten`: 0 latches; the known-bad probe shows 94 | measured 0 latches; the requirement reads PARTIAL, because its feature carries cells/dft_icg as MODEL_ONLY [src: reports/dft-structural.json] [src: declarations/dispositions.json] |
| No flop on any scan path | spec 12.3, REQ-21 | sequential count 288 with the router present, equal to Table 81; DFTSI-to-block and block-to-DFTSO paths combinational | measured [src: reports/dft-structural.json] [src: reports/io-paths.json] |
| Scan channels per INTEST mode | REQ-14, REQ-17, REQ-20 | every lane of the four modes checked in both directions, unmapped pins 0 | PASS at smoke depth [src: reports/dual-sim.json] |
| EXTEST wrapper and TOP chains | REQ-18 | block wrapper chains in series on pin b, TOP chains on 11 to 13 | PASS at smoke depth [src: reports/dual-sim.json] |
| Loopback | REQ-19 | DFTSO = DFTSI on all 20 pins | PASS at smoke depth [src: reports/dual-sim.json] |
| TAP forced to Test-Logic-Reset while DFTTM = 1 | REQ-35, REQ-04 | no TDR enable and DTR_CFG kept across a DFTTM rise in Shift-DR | PASS at smoke depth [src: dv/tb_soc_dft.sv] [src: reports/dual-sim.json] |
| Every crossing through a technology cell | D89-D91, rtl/cells/ | check_cells clean, 100 router cells named u_dft_mux2_*_dont_touch | PASS [src: .sdip/evidence_ledger.jsonl] |
| SMS MBIST | spec 14, R7 | generated IP not inserted | BLOCKED [src: rtl/dft_sms_srv.sv] |
| LPDDR PHY TDR path | spec 15, R8 | PHY model absent; SOC_DFT side smoke-tested only | BLOCKED [src: reports/dual-sim.json] |

Coverage and patterns:
- Fault models: stuck-at (target: at least 99.0 % per block, at least 98 % for the top glue in P0) and transition, per spec Section 19 [spec: 19].
- Coverage target/current: no current value. Stuck-at and transition are BLOCKED: no ATPG tool on this host (12 tools probed, none found), and no chip netlist with CTL models [src: reports/dft-tool-probe.json]. Transition is also out of scope with no OCC (CONF-18).
- Pattern count: none. No pattern was generated.
- Untestable/blocked/aborted faults: not measured. The SOC_DFT custom flops are excluded from ATPG by the source (CONF-34) and covered functionally by 10 smoke tests with 579 checks; no fault grade is claimed [src: reports/dual-sim.json].
- ATE formats: none produced (STIL/WGL BLOCKED with ATPG).

Physical and timing impact:
- Area: the generic synthesis count is in the structural report; 288 sequential cells, unchanged by the router. This is a technology-independent count, not an area [src: reports/dft-structural.json].
- Timing: TCK1 at 50 ns (100 ns in TDR mode) and TDRCLK generated at the ICG output; the router paths are combinational DFTSI-to-block and block-to-DFTSO paths timed in the SHIFT_Pn modes at 10 MHz (Table 83), whose mode SDC is a DFT team deliverable [src: constraints/soc_dft.sdc] [spec: 18.3].
- Pins: the 50 bonded DFT and JTAG1 pins of r0.91 (43 scan pins, 7 JTAG1) [spec: A.1].
- Congestion: not measured (no floorplan); the router is 100 dont_touch mux cells near the pad cluster (18.2).
- IR-drop: not measured. Shift power belongs to the DFT blocks; SOC_DFT shifts only the JTAG registers at 20 MHz.

Open risks:
- **Release-blocking:** ATPG cannot run on this host and no chip netlist exists. Every coverage number is BLOCKED (DFB-01) [src: reports/dft-tool-probe.json].
- **Release-blocking:** SMS MBIST is not inserted (R7, DFB-03).
- The PART code of each INTEST mode is an assumption awaiting the DFT team (ADM-23); a different assignment changes every tester program and is one regeneration of the package [src: declarations/adm.json].
- The PART reset value 5 selects no mode, so the pin-only production flow shifts no block until CONF-06 is answered (ADM-09).
- The map is a transcription of 12.2 and 12.7, not the signed-off spreadsheet (ADM-29).
- LPDDR PHY TDR path: verified on the SOC_DFT side only, not against the PHY (R8, DFB-04).
- Gate-level simulation (V-18) and the chip-level DFT tests (V-20 to V-23) have no netlist (DFB-05).
- Verification is at smoke depth: no formal, mutation or coverage [src: reports/dual-sim.json].

Handoff:
- To RTL: regenerate dft_part_map_pkg with scripts/gen_part_map.py when the DFT team assigns the PART codes or the spreadsheet arrives; this package is superseded by any RTL or test-mode change.
- To DV: full-depth DV (formal V-04, V-05; X-propagation V-12, V-16 with the block model) and the oracle model for the five source-named intermediates (spec_checks:dv NOT_RUN).
- To physical signoff: keep every `*_dont_touch` instance, the router cells included, and the single SDC [src: constraints/soc_dft.sdc]. The TDRCLK gate binds to the library ICG (IN-26).
- To tapeout package: no patterns, no coverage report. The DFT gate is BLOCKED on DFB-01, DFB-03, DFB-04, DFB-05 and DFB-06, each recorded in the ledger as `dft:*` BLOCKED; DFB-02 (scan routing) is cleared at r0.91.

## Blockers

| ID | Ledger domain | Blocker | Clears when |
|---|---|---|---|
| DFB-01 | dft:atpg_coverage | no ATPG or fault-simulation tool on this host; no chip netlist with CTL models | an ATPG tool is installed and the chip netlist exists |
| DFB-02 | dft:scan_routing | cleared at r0.91: router, map and decode built and smoke-verified | - |
| DFB-03 | dft:sms_mbist | the generated SMS TAP and Server are not inserted (R7) | the IP is delivered with its configuration report |
| DFB-04 | dft:lpddr_tdr_phy | no LPDDR PHY model for the TDR path (R8) | a PHY model or netlist is delivered |
| DFB-05 | dft:gate_level | no gate netlist for V-18, and no chip for V-20 to V-23 | synthesis on the target library and chip assembly |
| DFB-06 | dft:transition | no OCC in this revision (CONF-18) | an OCC is specified |
