#!/usr/bin/env python3
"""DFT structural measurement of soc_dft with Yosys (a tool present on this host).

    python -X utf8 dft/dft_structural.py [--probe good|bad|both]

Synthesises soc_dft (generic `synth -flatten`) and counts, from Yosys `stat -json`:
every sequential cell by type, grouped by clock edge and by asynchronous reset, and
every latch. The measurement answers the structural rules of the DFT record: SOC_DFT
holds no latch (REQ-27), every flop is clocked by TCK1 or the TCK1-derived TDRCLK on
one of its edges (REQ-28), and the flop inventory compared with Table 81.

The wrapper is calibrated (L22): the known-good probe is rtl/ as delivered; the
known-bad probe is a copy of rtl/ in tmp/ with the dft_mux2 cell's mux rewritten as
a level-sensitive latch, removed after the measurement. The wrapper is trusted only if the two
probes give different latch counts. Launches go through sdip_tools.proc_tree
(bounded, no stdin, killed as a tree).

Writes reports/dft-structural.json. Exit 0 when the calibration separates and the
delivered RTL has zero latches; 1 otherwise.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import sys
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PKG.parents[1] / ".github" / "agents"))
from sdip_tools import proc_tree as PT  # noqa: E402

OSS = Path(os.environ.get("SDIP_OSS_CAD", "D:/tools/oss-cad-suite"))
TIMEOUT = 600


def rtl_files(root: Path) -> list[str]:
    lines = (root / "rtl" / "soc_dft.f").read_text().splitlines()
    return [str(root / l.strip()) for l in lines if l.strip()]


def synth(root: Path, tag: str) -> dict:
    out = PKG / "tmp" / ("yosys-stat-%s.json" % tag)
    log = PKG / "tmp" / ("yosys-%s.log" % tag)
    files = " ".join(f.replace("\\", "/") for f in rtl_files(root))
    script = "read_verilog -sv %s; synth -top soc_dft -flatten; tee -q -o %s stat -json" % (
        files, str(out).replace("\\", "/"))
    env = dict(os.environ)
    env["PATH"] = os.pathsep.join([str(OSS / "bin"), str(OSS / "lib"), env.get("PATH", "")])
    r = PT.run(["yosys", "-q", "-l", str(log), "-p", script], env=env, cwd=str(root), timeout=TIMEOUT)
    if r.returncode != 0 or not out.is_file():
        return {"tag": tag, "ok": False, "rc": r.returncode, "log": str(log)}
    stat = json.loads(out.read_text(encoding="utf-8"))
    cells = stat.get("design", {}).get("num_cells_by_type") or {}
    if not cells:
        mods = stat.get("modules", {})
        cells = next(iter(mods.values()), {}).get("num_cells_by_type", {})
    seq = {k: v for k, v in cells.items() if re.match(r"^\$_(S?DFF|DFFE|SDFFE|SDFFCE|ALDFF|DFFSR|DFFSRE|DLATCH)", k)}
    latch = sum(v for k, v in seq.items() if k.startswith("$_DLATCH"))
    flops = sum(v for k, v in seq.items() if not k.startswith("$_DLATCH"))
    pos = sum(v for k, v in seq.items() if not k.startswith("$_DLATCH") and re.match(r"^\$_[A-Z]+_P", k))
    neg = sum(v for k, v in seq.items() if not k.startswith("$_DLATCH") and re.match(r"^\$_[A-Z]+_N", k))
    arst = sum(v for k, v in seq.items() if re.match(r"^\$_(DFF|DFFE)_[PN][PN][01]", k))
    return {"tag": tag, "ok": True, "cells_total": sum(cells.values()), "sequential_by_type": seq,
            "flops": flops, "latches": latch, "flops_rising": pos, "flops_falling": neg,
            "flops_async_reset": arst, "flops_no_reset": flops - arst, "log": str(log.relative_to(PKG))}


def bad_copy() -> Path:
    dst = PKG / "tmp" / "dft-bad-probe"
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(PKG / "rtl", dst / "rtl")
    cell = dst / "rtl" / "cells" / "dft_mux2.sv"
    t = cell.read_text()
    t = t.replace("  assign y_o = (s_i == SEL_B) ? b_i : a_i;",
                  "  logic y_q;\n  always_latch if (s_i == SEL_B) y_q = b_i;\n  assign y_o = y_q | a_i;")
    cell.write_text(t, newline="")
    return dst


def main() -> int:
    good = synth(PKG, "good")
    bad = synth(bad_copy(), "bad")
    # the probe copy declares RTL identities; it must not outlive the measurement (FE-11)
    shutil.rmtree(PKG / "tmp" / "dft-bad-probe", ignore_errors=True)
    separates = bool(good.get("ok") and bad.get("ok") and good["latches"] != bad["latches"])
    rec = {"tool": "Yosys (oss-cad-suite, %s)" % (OSS / "bin" / "yosys.exe"),
           "command": "read_verilog -sv <rtl/soc_dft.f>; synth -top soc_dft -flatten; stat -json",
           "known_good": {"probe": "rtl/ as delivered", **good},
           "known_bad": {"probe": "tmp/dft-bad-probe: dft_mux2 rewritten with a latch", **bad},
           "separates": separates,
           "verdict": "PASS" if separates and good.get("latches") == 0 else "FAIL"}
    out = PKG / "reports" / "dft-structural.json"
    out.write_text(json.dumps(rec, indent=2) + "\n", encoding="utf-8", newline="")
    print(json.dumps({k: rec[k] for k in ("separates", "verdict")}))
    print("good: flops %s latches %s rising %s falling %s async-reset %s" % (
        good.get("flops"), good.get("latches"), good.get("flops_rising"), good.get("flops_falling"), good.get("flops_async_reset")))
    print("bad : latches %s" % bad.get("latches"))
    return 0 if rec["verdict"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
