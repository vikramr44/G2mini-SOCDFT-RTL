<!-- Fill every slot; keep every heading and every table header as written. Cite with [src: path], [src: path:line], [src: path#anchor], [canon: D<number>] or [spec: <clause>]. A src path is relative to the package root. -->

# Stage-boundary audit

<!-- SLOT: identity cite=none -->
Stage audit of the DFT stage of G2MINI_SOCDFT_E2 after the r0.91 rework (SOC_DFT full build: scan router, generated partition map, partition decode), by semi_quality_critic, at the end of the DFT stage, before any advance out of DFT. The run was asked to run to DFT, so this audit closes the incremental run. It supersedes the r0.9 DFT audit.
<!-- END SLOT: identity -->

## 1. Audit record

<!-- SLOT: record cite=any -->
| Field | Value |
|---|---|
| Package | Src/G2MINI_SOCDFT_E2 |
| Stage audited | DFT (owner semi_dft_engineer), r0.91 rework |
| Source | G2mini SOC_DFT Block Specification r0.91, the one file read [src: docs/conversion-manifest.json] |
| Auditor | semi_quality_critic, in the same session that produced every stage; independence is limited and recorded as finding F-08 |
| Date | 2026-10-16 |
| Design revision | internal edition revision 0.3 reissued for r0.91 [src: reports/consumption-records.md] |
| DV depth | smoke [src: reports/dual-sim.json] |
| Ledger | .sdip/evidence_ledger.jsonl; this audit is recorded there as `stage_audit:dft` [src: .sdip/evidence_ledger.jsonl] |
<!-- END SLOT: record -->

## 2. Scope

### 2.1 Read in full

<!-- SLOT: read cite=each -->
- The DFT architecture record [src: declarations/dft-declared.json]
- The DFT package [src: dft/G2MINI_SOCDFT_E2-DFT-package.md]
- The structural measurement wrapper and its report [src: dft/dft_structural.py] [src: reports/dft-structural.json]
- The host tool probe [src: reports/dft-tool-probe.json]
- The negative controls of the DFT checker [src: reports/dft-negative-controls.json]
- The generated partition map and its report [src: rtl/dft_part_map_pkg.sv] [src: reports/part-map.json]
- The scan router and the mode decoder [src: rtl/dft_scan_rtr.sv] [src: rtl/dft_mode_dec.sv]
- The disposition record [src: declarations/dispositions.json]
- The smoke run record [src: reports/dual-sim.json]
- The constraint file [src: constraints/soc_dft.sdc]
- The DFT stage brief [src: reports/stage-brief-DFT.md]
<!-- END SLOT: read -->

### 2.2 Not covered

<!-- SLOT: not-covered cite=any -->
- Of the internal edition, chapters 1, 2, 5, 6, 11 and 12 were re-read across the rework; chapters 7 to 10 and 13 to 14 were not re-read at this boundary [src: publication/G2MINI_SOCDFT_E2-uarch-internal.md].
- The bench was read through its generator and its run record, not line by line [src: dv/tb_soc_dft.sv].
- Nothing at gate level: no netlist exists.
<!-- END SLOT: not-covered -->

## 3. Stage-boundary checks

<!-- SLOT: checks cite=each -->
| # | Check | Mode | Denominator | Result | Evidence |
|---|---|---|---|---|---|
| 1 | DFT architecture record complete (run_dft_checks, v14) | tool | 7 sections, 7 coverage rows | 0 findings | [src: declarations/dft-declared.json] |
| 2 | The DFT checker can fail (negative controls) | tool | 4 seeded defects | 4 refused, including a coverage credited to an absent tool | [src: reports/dft-negative-controls.json] |
| 3 | Structural wrapper calibrated | tool | 2 probes | separates: 0 latches against 94 | [src: reports/dft-structural.json] |
| 4 | Flop inventory against the source, router present | compare | 1 total | 288 measured = 288 in Table 81; the router adds none | [spec: Table 81] [src: reports/dft-structural.json] |
| 5 | ATPG tooling present on the host | tool | 12 tools probed | 0 present; every coverage row BLOCKED by name | [src: reports/dft-tool-probe.json] |
| 6 | Map regenerates to the checked-in package and equals the MKM (C-2) | tool | the package and every derived scalar | 0 findings | [src: reports/part-map.json] |
| 7 | Scan path verified per mode | tool | 4 INTEST modes, EXTEST, loopback, 10 tests | 579 checks PASS on both simulators, agreed | [src: reports/dual-sim.json] |
| 8 | Requirement verdicts from dispositions | tool | 14 mandatory features | 0 NOT MET; 3 PARTIAL (LPDDR TDR bridge, SMS shell, technology cells) | [src: declarations/dispositions.json] |
| 9 | Every DFT blocker in the ledger | compare | 6 blockers DFB-01 to DFB-06 | DFB-02 cleared (PASS), 5 recorded BLOCKED | [src: .sdip/evidence_ledger.jsonl] |
| 10 | Gate preflight into PHYSICAL (dry, not recorded) | tool | 1 gate | 1 finding: `sim` PARTIAL (smoke by construction) | [src: tools/gate_preflight.py] |
| 11 | Run documents against their skeletons | tool | every skeleton | the DV plan is still not written (F-06) | [src: reports/document-check.json] |
<!-- END SLOT: checks -->

## 4. Cross-document consistency

<!-- SLOT: consistency cite=each -->
| Dimension | Documents compared | Result | Evidence |
|---|---|---|---|
| Flop count | Yosys report, DFT record, source Table 81 | agree: 288 | [src: reports/dft-structural.json] [src: declarations/dft-declared.json] |
| Mode plan and PART codes | map report, MKM package rows, DFT package, bench | agree: modes on PART 1 to 4, pin 19 unmapped in mode 3, EXTEST pins 0 to 13 | [src: reports/part-map.json] [src: declarations/mkm.json] |
| Router cells | check_cells, MKM instances, DFT record | agree: five dft_mux2 per lane, dont_touch | [src: declarations/mkm.json] |
| SMS scan status | DFT record, ADM-28, source D-1 | agree: not scanned | [src: declarations/adm.json] |
| Requirement status | DFT package traceability, disposition verdicts | agree: REQ-27 PARTIAL through dft_icg MODEL_ONLY; scan routing IMPLEMENTED | [src: dft/G2MINI_SOCDFT_E2-DFT-package.md] |
<!-- END SLOT: consistency -->

## 5. Semantic emptiness

### 5.1 A field answered by restating its own heading

<!-- SLOT: empty-restated cite=each -->
| Searched in | Result |
|---|---|
| every field of the DFT record | one hit: `capture_period` "not applicable" on the case-analysis row; accepted, a static pin has no capture [src: declarations/dft-declared.json] |
<!-- END SLOT: empty-restated -->

### 5.2 A rule that forbids nothing

<!-- SLOT: empty-rule cite=each -->
| Searched in | Result |
|---|---|
| the seven structural rules of the DFT record | none: each forbids something (a latch, a scan element, a flop on a scan path, an uncelled router mux, a third clock, an uncontrollable reset, a scanned SMS TAP) [src: declarations/dft-declared.json] |
<!-- END SLOT: empty-rule -->

### 5.3 A check that cannot fail

<!-- SLOT: empty-check cite=each -->
| Searched in | Result |
|---|---|
| run_dft_checks | it fails on all four seeded defects; the absent-tool hole of r0.9 (FE-09) is closed by v14 [src: reports/dft-negative-controls.json] |
| dft_structural.py | it can fail: the known-bad probe gives 94 latches [src: reports/dft-structural.json] |
<!-- END SLOT: empty-check -->

### 5.4 A justification that recounts what was done

<!-- SLOT: empty-justification cite=each -->
| Searched in | Result |
|---|---|
| coverage rows of the DFT record | two bounded hits: the BLOCKED rows credit `python` because the v14 rule has no form for a BLOCKED row (FE-15, F-07); the custom-flop row cites the smoke run and claims no fault grade [src: declarations/dft-declared.json] |
<!-- END SLOT: empty-justification -->

### 5.5 A status reporting activity where a gate outcome belongs

<!-- SLOT: empty-status cite=each -->
| Searched in | Result |
|---|---|
| Status column of the DFT package traceability table | none: each row states a measured value or a verdict at a named depth [src: dft/G2MINI_SOCDFT_E2-DFT-package.md] |
<!-- END SLOT: empty-status -->

### 5.6 A placeholder that has acquired the document's formatting

<!-- SLOT: empty-placeholder cite=each -->
| Searched in | Result |
|---|---|
| DFT package and DFT record, for pending, TBD, TODO, xxx | none [src: dft/G2MINI_SOCDFT_E2-DFT-package.md] |
| dispositions | one PLACEHOLDER, dft_scan_hold, carrying no feature: the partial-build boundary used only with P_PARTITIONED = 0 [src: declarations/dispositions.json] |
<!-- END SLOT: empty-placeholder -->

## 6. Handoff conditions

<!-- SLOT: handoff cite=each -->
| Condition | State | Evidence |
|---|---|---|
| DFT package exists and declares its identity | met | [src: dft/G2MINI_SOCDFT_E2-DFT-package.md] |
| DFT engineer's consumption records current | met: 8 of 8 | [src: reports/consumption-records.md] |
| DFT record checks clean | met | [src: declarations/dft-declared.json] |
| Every coverage number names a tool on this host or is BLOCKED by name | met, and now enforced by the checker | [src: reports/dft-negative-controls.json] |
| Every DFT blocker in the ledger | met: dft:atpg_coverage, dft:sms_mbist, dft:lpddr_tdr_phy, dft:gate_level, dft:transition BLOCKED; dft:scan_routing PASS | [src: .sdip/evidence_ledger.jsonl] |
| Gate into PHYSICAL | not met: `sim` is PARTIAL; not asked, since the run stops at DFT | [src: reports/dual-sim.json] |
<!-- END SLOT: handoff -->

## 7. Findings

<!-- SLOT: findings cite=each -->
| ID | Severity | Category | Title | Location | What was found | Why it matters | Confidence | Blocks gate | Recommended fix | Prevention |
|---|---|---|---|---|---|---|---|---|---|---|
| F-01 | Critical | DFT gap | No ATPG coverage, no patterns | DFB-01, DFB-06 | no ATPG tool and no chip netlist; transition out of scope (CONF-18) | the part cannot be signed off for manufacturing test | 100% | yes, DFT signoff | install an ATPG tool; produce the chip netlist with CTL models | recorded as dft:atpg_coverage, dft:transition [src: reports/dft-tool-probe.json] |
| F-02 | Critical | DFT gap | SMS MBIST not inserted | DFB-03 | the generated SMS TAP and Server are absent; the shell carries a stand-in | memories cannot be tested | 100% | yes, DFT signoff | deliver R7 and insert the IP | recorded as dft:sms_mbist [src: rtl/dft_sms_srv.sv] |
| F-03 | Important | Assumption | PART codes assumed | ADM-23 | modes on PART 1 to 4 on the operator's direction; the source has not assigned them | every tester program writes these codes | 100% | no | DFT team confirms or assigns; regenerate the package | the codes are one map-declaration field [src: declarations/adm.json] |
| F-04 | Important | Default value | PART reset selects no mode | ADM-09 | P_CFG_RST keeps PART = 5; the pin-only flow shifts no block | production without JTAG tests nothing until CONF-06 | 100% | no | answer CONF-06, set P_CFG_RST[3:0] | check reset values against the code assignment [src: declarations/adm.json] |
| F-05 | Important | Gate gap | The PHYSICAL gate reads no dft domain | phase_policy entry to PHYSICAL | the dry preflight names only `sim`; five BLOCKED dft domains do not register | physical design could start on a blocked DFT once `sim` passes | 90% | no (run ends at DFT) | add the dft domains to PHYSICAL entry | FE-08 [src: reports/FRAMEWORK-EVALUATION.md] |
| F-06 | Important | Missing document | The DV plan was never written | skeleton_dv_plan.md | check_documents reports it not written; carried from the r0.9 audit | the smoke set's derivation lives only in the bench generator and manifest | 100% | no | write it at the full-depth DV re-run | the gate out of DV should ask for its documents [src: reports/document-check.json] |
| F-07 | Suggestion | Check gap | BLOCKED coverage rows must credit a tool | dft_architecture coverage rule | the rule accepts only a wrapper or a toolchain name, so the BLOCKED rows credit python | a reader may take python for a measuring tool | 90% | no | accept BLOCKED with the probe as basis | FE-15 [src: reports/FRAMEWORK-EVALUATION.md] |
| F-08 | Suggestion | Independence | Audit made in the producing session | this report | auditor and producer share one context | a shared blind spot is not caught | 80% | no | re-audit from a fresh session | none [src: reports/stage-audit-dft.md] |
| F-09 | Suggestion | Traceability | Revision labels reused by the rework | publication record | the r0.91 issue is again revision 0.1 to 0.3, with no new history row | readers cannot tell the r0.9 and r0.91 issues apart by label | 90% | no | a rework revision scheme | FE-13 [src: reports/FRAMEWORK-EVALUATION.md] |
<!-- END SLOT: findings -->

## 8. Defects caught at this boundary

<!-- SLOT: defects cite=each -->
| ID | Class | Produced in | Caught by | Repair | Re-checked by |
|---|---|---|---|---|---|
| D-01 | coverage attribution | DFT record, first r0.91 draft (BLOCKED rows credited to the probe report) | run_dft_checks COVERAGE_UNEARNED (v14) | rows credit python and name the probe report and the absent tools in their value | run_dft_checks, 0 findings [src: declarations/dft-declared.json] |
| D-02 | stale probe target | dft/dft_structural.py (known-bad probe named dft_rst_mux2, renamed dft_mux2 at r0.91) | reading the wrapper against the cell list | probe rewrites dft_mux2; the copy is removed after use | the probe separates, 0 against 94 [src: reports/dft-structural.json] |
<!-- END SLOT: defects -->

## 9. Risks carried forward

<!-- SLOT: risks cite=each -->
| Risk | Owner | Re-check point | Evidence |
|---|---|---|---|
| No ATPG coverage or patterns | semi_dft_engineer | when an ATPG tool and the chip netlist exist | [src: reports/dft-tool-probe.json] |
| PART codes and PART reset value | DFT team | the code assignment and CONF-06 | [src: declarations/adm.json] |
| Map from a transcription, not the signed-off spreadsheet | DFT team | spreadsheet delivery | [src: declarations/part-map-declared.json] |
| SMS MBIST not inserted (R7) | integrator | delivery of the generated SMS IP | [src: rtl/dft_sms_srv.sv] |
| LPDDR PHY TDR path unverified against the PHY (R8) | semi_dv_engineer | PHY model delivery | [src: reports/dual-sim.json] |
| DV at smoke depth; spec_checks:dv NOT_RUN | semi_dv_engineer | full-depth DV re-run | [src: .sdip/evidence_ledger.jsonl] |
| rtl_checks FAIL on FE-04 (waiver readers disagree) | framework owner | next SDIP increment | [src: reports/FRAMEWORK-EVALUATION.md] |
<!-- END SLOT: risks -->

## 10. The three verdicts

<!-- SLOT: verdicts cite=each -->
| Question | Answer | Basis |
|---|---|---|
| Does any Critical or High finding exist? | yes: F-01 and F-02 are Critical | [src: reports/stage-audit-dft.md] |
| Is the completeness claim justified? | yes: the DFT package claims BLOCKED, not complete; scan routing is built and smoke-verified, and every coverage row is BLOCKED by name or measured by a calibrated tool on this host | [src: dft/G2MINI_SOCDFT_E2-DFT-package.md] [src: reports/dft-structural.json] |
| Is freeze defensible? | no: there are no patterns, MBIST is absent and the PART codes are assumed | [src: declarations/adm.json] |
<!-- END SLOT: verdicts -->

## 11. Gate verdict

<!-- SLOT: gate cite=any -->
BLOCKED. The r0.91 rework produced what the DFT stage owes: the DFT record (checks clean, the checker now refusing unearned coverage), a calibrated structural measurement showing no flop on the new scan path, the DFT package and its consumption records. Scan routing (DFB-02) is cleared. DFT signoff stays BLOCKED on DFB-01 and DFB-03 to DFB-06, each recorded in the ledger; no coverage number is claimed [src: .sdip/evidence_ledger.jsonl]. The run stops at DFT as the kickoff asked; no advance to PHYSICAL is requested.
<!-- END SLOT: gate -->
