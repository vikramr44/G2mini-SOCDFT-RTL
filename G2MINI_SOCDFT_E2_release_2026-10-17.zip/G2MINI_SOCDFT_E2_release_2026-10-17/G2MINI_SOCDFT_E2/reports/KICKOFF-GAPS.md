# Kickoff gaps

Package: Src/G2MINI_SOCDFT_E2. Run to: DFT, DV depth smoke [src: .sdip/pass0_kickoff.json].

## KG-01 The gate preflight can never record a clean result

**Status: RESOLVED** (2026-10-15, operator answered yes to the question below)

**Unresolved against:** canon D63 and D81; architect lesson L37 (`gate_preflight.check_preflight_before_gate`); framework rule "framework files change only through the SDIP increment process" (CLAUDE.md, task-observer section).

**What happened.** `tools/phase.py advance ARCH` runs `sdip_tools.gate_preflight.preflight`, records it, and refuses on any finding. `preflight` calls `check_records`, which calls `phase_policy.check_phase_entry`, which ends with `phase_policy._preflight_violations`: that returns `PREFLIGHT_ABSENT_BEFORE_GATE` when no preflight is recorded for the target, and `PREFLIGHT_UNCLEAN_AT_GATE` when the last recorded one had findings. So the first preflight records itself unclean (ABSENT), and every later one finds the previous record unclean (UNCLEAN). Measured on this package, 2026-10-15: three consecutive records, each unclean, the only finding each time being the record check itself; every package-side finding was zero.

**Why the run cannot answer it.** The defect is in framework code (`sdip_tools/gate_preflight.py`, `sdip_tools/phase_policy.py`); the package tools are digest-bound to the template (D75, `PASS0_TOOLS_DIGEST`), and framework files change only through an increment. Writing a clean record by hand would be a record the preflight did not produce (L26, D66).

**What stops until it is answered.** Every phase gate from SPEC -> ARCH onward. Nothing of ARCH may be produced before the ARCH gate grants, or it is an out-of-phase artefact.

**Question (yes / no).** May the run apply the minimal framework repair: in `sdip_tools/gate_preflight.check_records`, drop violations whose kind is one of `RECORD_KINDS` (the preflight log's own questions, which the gate still asks itself in `phase.py advance` through `phase_policy`), with a regression test, recorded as a framework increment?

**Resolution.** The operator authorised the minimal repair. `sdip_tools/gate_preflight.check_records` now skips the violations whose kind is in `RECORD_KINDS`; `phase_policy._preflight_violations` still refuses at the gate in `phase.py advance`. Regression test `tests/test_gate_preflight.py::Records::test_the_first_preflight_of_a_package_with_the_tool_can_be_clean`: passes with the repair, fails without it (negative control run 2026-10-15); `tests.test_gate_preflight` and `tests.test_phase_policy` 98 tests OK. Recorded in `reports/FRAMEWORK-EVALUATION.md` as FE-01.

## KG-02: operator directions for the r0.91 rework (2026-10-16)

Recorded as decision record EDR-R091-01. Asked in the run session because r0.91 leaves them open or contradicts itself; each answer is the operator's.

| Question | Direction | Register |
|---|---|---|
| Backward move DFT -> SPEC is impossible in the framework (FE-10) | Minimal framework fix, uncommitted | FE-10 |
| PART codes of the four INTEST modes (r0.91: 'the code assignment is not yet made') | Mode m on PART m + 1 | ADM-23 (ASSUMPTION) |
| Table 59 PIN_BASE values against the 12.4 generator rule | The 12.4 rule | ADM-24 |
| P_PARTITIONED default (Appendix B and Table 82 say 0; Section 11 and IN-01 say 1) | Default 1, 0 still legal | ADM-02 |
