# Artifact identity: CONSTRAINTS
# soc_dft essentials (spec r0.91 24.7, STA modes of 18.3). One mode per STA run; the full
# mode SDC is a DFT team deliverable (spec Table 92). Instance paths are the cell
# instances of soc_dft: u_ddr_tdr/u_dft_icg_tdrclk_dont_touch is the source's
# u_tdrclk_icg; u_crg_ctl/u_dft_mux2_rst_dont_touch and
# u_dft_mux2_scan_rstn_dont_touch are its u_rst_mux and u_scan_rstn_mux.
# Paths are written from the soc_dft top; prefix u_soc_dft/ at the chip top.

# TCK1: 50 ns in the JTAG, SMS_BIST and scan modes; 100 ns in TDR mode (10 MHz PHY limit).
if {![info exists SOC_DFT_MODE]} { set SOC_DFT_MODE JTAG }
if {$SOC_DFT_MODE eq "TDR"} {
  create_clock -name TCK1 -period 100 [get_ports TCK1]
} else {
  create_clock -name TCK1 -period 50 [get_ports TCK1]
}
create_generated_clock -name TDRCLK -source [get_ports TCK1] -divide_by 1 \
  [get_pins u_ddr_tdr/u_dft_icg_tdrclk_dont_touch/gclk_o]

# Static controls per mode (18.3).
if {$SOC_DFT_MODE eq "FUNC" || $SOC_DFT_MODE eq "JTAG" || $SOC_DFT_MODE eq "TDR" || $SOC_DFT_MODE eq "SMS_BIST"} {
  set_case_analysis 0 [get_ports DFTTM]
}
if {$SOC_DFT_MODE eq "TDR" || $SOC_DFT_MODE eq "SMS_BIST"} {
  set_case_analysis 1 [get_ports {TSEL1[1] TSEL1[0]}]
}

# DTR statics: false path only where they leave soc_dft, never from the shadow cells,
# so the half-cycle paths inside soc_dft stay timed (10.6).
set_false_path -through [get_ports {dft_crg_* lpddr_sms_dm* lpddr_ring_bypass* lpddr_sfp_dft_mode}]

# Clock gating check on the TDRCLK gate enable.
set_clock_gating_check -setup 0 -hold 0 [get_cells u_ddr_tdr/u_dft_icg_tdrclk_dont_touch]

# Pad I/O: 40 % of the period on the DFT and JTAG1 pads until pad timing (IN-25) arrives.
set_input_delay  20 -clock TCK1 [get_ports {TMS1 TDI1}]
set_output_delay 20 -clock TCK1 -clock_fall [get_ports {TDO1 TDO1_OE}]

# dont_touch on every technology cell instance (24.11).
set_dont_touch [get_cells -hierarchical *_dont_touch]
