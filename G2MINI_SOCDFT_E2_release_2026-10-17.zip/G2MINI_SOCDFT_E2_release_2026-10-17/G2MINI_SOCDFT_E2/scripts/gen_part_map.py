#!/usr/bin/env python3
"""gen_part_map.py: generate dft_part_map_pkg from the partition map (spec r0.91 12.4).

    python scripts/gen_part_map.py            write rtl/dft_part_map_pkg.sv and reports/part-map.json
    python scripts/gen_part_map.py --check    regenerate in memory; exit 1 unless the checked-in
                                          package equals the fresh one and the derived map
                                          equals the MKM rows (review condition C-2)

The input is declarations/part-map-declared.json: per-block channel counts and the
membership of each INTEST mode, the PART codes and the EXTEST pin rule. Every other
value is derived here and nowhere else:

  * PIN_BASE by the 12.4 rule: within a mode, member blocks take pins in ascending block
    index, contiguously from pin 0, NCH pins each;
  * PART_MAP_SEL, P0_MEMBER, NPART, the flat-bus offsets OFF and BASE_OF;
  * SO_VALID, SO_BLK, SO_CH and SO_IDX, the inverse of PIN_BASE, per PART.

The 12.5 budget rules are checked first and a map that breaks one is refused (LR-03):
at most NPIN channels per mode, NCH at least 2 for a routed block and 0 for a hard IP,
every routed block in exactly one mode, identical instances with identical NCH.
The package is written in packed-vector form (12.4 representation rule): element [i]
of every array is field i of the vector, written most-significant element first.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
MAP = PKG / "declarations" / "part-map-declared.json"
OUT = PKG / "rtl" / "dft_part_map_pkg.sv"
REPORT = PKG / "reports" / "part-map.json"
MKM = PKG / "declarations" / "mkm.json"
NPARTS = 16           # PART is DTR_CFG[3:0]
NONE = 0xFF           # 12.4: 8'hFF marks "not a member"
TWINS = (("pcia", "pcib"), ("l4ga", "l4gb"))   # identical instances (12.5)


class MapRefused(Exception):
    pass


def derive(decl: dict) -> dict:
    blocks = sorted(decl["blocks"], key=lambda b: b["b"])
    if [b["b"] for b in blocks] != list(range(len(blocks))):
        raise MapRefused("block indices are not 0..%d" % (len(blocks) - 1))
    name = {b["b"]: b["name"] for b in blocks}
    idx = {b["name"]: b["b"] for b in blocks}
    nch = {b["name"]: b["nch"] for b in blocks}
    routed = [b["name"] for b in blocks if b["scanned"]]
    npin = decl["pins"]
    for b in blocks:
        if b["scanned"] and b["nch"] < 2:
            raise MapRefused("%s is routed with NCH %d < 2 (12.5)" % (b["name"], b["nch"]))
        if not b["scanned"] and b["name"] != "top" and b["nch"] != 0:
            raise MapRefused("%s is a hard IP with NCH %d != 0 (12.5)" % (b["name"], b["nch"]))
    for a, c in TWINS:
        if a in nch and c in nch and nch[a] != nch[c]:
            raise MapRefused("identical instances %s and %s differ in NCH (12.5)" % (a, c))
    seen = {}
    for md in decl["modes"]:
        for n in md["members"]:
            if n not in routed:
                raise MapRefused("mode %d names %s, which is not routed" % (md["mode"], n))
            if n in seen:
                raise MapRefused("%s is in modes %d and %d (12.5)" % (n, seen[n], md["mode"]))
            seen[n] = md["mode"]
    missing = [n for n in routed if n not in seen]
    if missing:
        raise MapRefused("routed blocks in no mode: %s" % ", ".join(missing))
    codes = decl["part_codes"]
    first = codes["first_intest"]
    nmode = len(decl["modes"])
    mode_part = {md["mode"]: first + md["mode"] for md in decl["modes"]}
    used = set(mode_part.values()) | {codes["extest"], codes["loopback"]}
    if len(used) != nmode + 2 or not all(1 <= p <= 14 for p in mode_part.values()):
        raise MapRefused("PART codes collide or leave 1..14 (11.3): %s" % sorted(used))
    ext = decl["extest"]
    nsblk = len(routed)
    if ext["top_first_pin"] != nsblk or nsblk + ext["ntop"] > npin:
        raise MapRefused("EXTEST pins: %d wrapper pins and %d TOP pins on %d (12.5)"
                         % (nsblk, ext["ntop"], npin))

    off, o = {}, 0
    for n in routed:
        off[n] = o
        o += nch[n]
    pin_base = [[NONE] * len(blocks) for _ in range(NPARTS)]
    map_sel = [0] * NPARTS
    so_valid = [[0] * npin for _ in range(NPARTS)]
    so_blk = [[0] * npin for _ in range(NPARTS)]
    so_ch = [[0] * npin for _ in range(NPARTS)]
    so_idx = [[0] * npin for _ in range(NPARTS)]
    base_of = {}
    plan = []
    for md in decl["modes"]:
        p = mode_part[md["mode"]]
        pin = 0
        lanes = []
        for n in sorted(md["members"], key=lambda x: idx[x]):
            if pin + nch[n] > npin:
                raise MapRefused("mode %d needs more than %d pins (12.5)" % (md["mode"], npin))
            pin_base[p][idx[n]] = pin
            base_of[n] = pin
            map_sel[p] |= 1 << idx[n]
            for j in range(nch[n]):
                k = pin + j
                so_valid[p][k], so_blk[p][k], so_ch[p][k] = 1, idx[n], j
                so_idx[p][k] = off[n] + j
            lanes.append({"block": n, "first_pin": pin, "last_pin": pin + nch[n] - 1})
            pin += nch[n]
        plan.append({"mode": md["mode"], "part": p, "lanes": lanes, "pins_used": pin,
                     "pins_unmapped": list(range(pin, npin))})
    p0_member = 0
    for n in routed:
        p0_member |= 1 << idx[n]
    p0_member |= 1 << idx["top"]
    return {"blocks": [{"b": b["b"], "name": b["name"], "nch": b["nch"], "routed": b["scanned"],
                        "off": off.get(b["name"]), "base_of": base_of.get(b["name"])} for b in blocks],
            "name": name, "nblk": len(blocks), "nsblk": nsblk, "npin": npin, "nmode": nmode,
            "npart": nmode + 2, "nwrap": ext["nwrap"], "ntop": ext["ntop"], "tmw": decl["tmw"],
            "nch_sum": o, "off": off, "nch": nch, "routed": routed, "idx": idx,
            "part_extest": codes["extest"], "part_loopback": codes["loopback"], "part_mode0": first,
            "map_sel": map_sel, "p0_member": p0_member, "pin_base": pin_base, "base_of": base_of,
            "so_valid": so_valid, "so_blk": so_blk, "so_ch": so_ch, "so_idx": so_idx,
            "enc": decl["encodings"], "plan": plan}


def _vec(elems, width):
    """{elem[n-1], ..., elem[0]} as sized literals: element [i] is field i."""
    return "{" + ", ".join("%d'h%X" % (width, e) for e in reversed(elems)) + "}"


def render(m: dict, digest: str) -> str:
    N = m["nblk"]
    L = []
    A = L.append
    A("// Artifact identity: RTL")
    A("// dft_part_map_pkg: partition map of SOC_DFT (spec r0.91 12.4), GENERATED by")
    A("// scripts/gen_part_map.py from declarations/part-map-declared.json (sha256 %s)." % digest[:16])
    A("// Do not edit: change the map declaration and regenerate. Flat packed-vector form")
    A("// (12.4 representation rule; one dimension, for every simulator): p is a PART code,")
    A("// b a block index (1.5), k a DFTSI/DFTSO pin. Fields:")
    A("//   PART_MAP_SEL[NBLK*p +: NBLK]   NCH[8*b +: 8]   OFF[8*b +: 8]")
    A("//   PIN_BASE[8*(NBLK*p + b) +: 8]  SO_VALID[NPIN*p + k]")
    A("//   SO_BLK[4*(NPIN*p + k) +: 4]    SO_CH[5*(NPIN*p + k) +: 5]")
    A("// 8'hFF in PIN_BASE and OFF marks no membership.")
    A("`timescale 1ns/1ps")
    A("package dft_part_map_pkg;")
    A("  localparam int NBLK  = %d;   // block index positions: routed blocks, lpddr, top" % N)
    A("  localparam int NSBLK = %d;   // blocks routed through dft_scan_rtr (b = 0..%d)" % (m["nsblk"], m["nsblk"] - 1))
    A("  localparam int NPIN  = %d;   // DFTSI/DFTSO pin pairs (CONF-28)" % m["npin"])
    A("  localparam int NMODE = %d;    // INTEST modes" % m["nmode"])
    A("  localparam logic [3:0] NPART = 4'd%d;   // INTEST modes, EXTEST and loopback; DTR_STS[15:12]" % m["npart"])
    A("  localparam int NWRAP = %d;    // wrapper chains per block, in series in EXTEST" % m["nwrap"])
    A("  localparam int NTOP  = %d;    // TOP glue chains" % m["ntop"])
    A("  localparam int TMW   = %d;    // snps_test_mode width (11.4)" % m["tmw"])
    A("")
    A("  // block indices (1.5) of the routed blocks and of lpddr; NCH below holds every block")
    for b in m["blocks"]:
        if b["routed"] or b["name"] == "lpddr":
            A("  localparam int B_%s = %d;" % (b["name"].upper(), b["b"]))
    A("  // channels per routed block (12.2)")
    for b in m["blocks"]:
        if b["routed"]:
            A("  localparam int NCH_%s = %d;" % (b["name"].upper(), b["nch"]))
    A("  // offset of each routed block in the router's flat channel buses")
    for n in m["routed"]:
        A("  localparam int OFF_%s = %d;" % (n.upper(), m["off"][n]))
    A("  localparam int NCH_SUM = %d;" % m["nch_sum"])
    A("")
    A("  // PART codes (11.3; INTEST mode m on PART_MODE0 + m)")
    A("  localparam logic [3:0] PART_EXTEST   = 4'd%d;" % m["part_extest"])
    A("  localparam logic [3:0] PART_LOOPBACK = 4'd%d;" % m["part_loopback"])
    A("  localparam int         PART_MODE0    = %d;" % m["part_mode0"])
    A("")
    A("  localparam logic [16*NBLK-1:0] PART_MAP_SEL = %s;" % _vec(m["map_sel"], N))
    A("  localparam logic [NBLK-1:0] P0_MEMBER = %d'h%X;" % (N, m["p0_member"]))
    A("  localparam logic [8*NBLK-1:0] NCH = %s;" % _vec([b["nch"] for b in m["blocks"]], 8))
    A("  localparam logic [8*NBLK-1:0] OFF = %s;" % _vec(
        [m["off"].get(m["name"][i], 0xFF) for i in range(N)], 8))
    A("  localparam logic [8*NBLK*16-1:0] PIN_BASE = {")
    for p in reversed(range(NPARTS)):
        A("    %s%s   // PART %d" % (_vec(m["pin_base"][p], 8), "," if p else "", p))
    A("  };")
    for nm, w, src in (("SO_VALID", 1, "so_valid"), ("SO_BLK", 4, "so_blk"),
                       ("SO_CH", 5, "so_ch")):
        dims = "[%s16*NPIN-1:0]" % ("" if w == 1 else "%d*" % w)
        A("  localparam logic %s %s = {" % (dims, nm))
        for p in reversed(range(NPARTS)):
            A("    %s%s   // PART %d" % (_vec(m[src][p], w), "," if p else "", p))
        A("  };")
    A("")
    A("  // test-mode codes per routed block, TMW bits each, block b at [TMW*b +: TMW] (11.4)")
    for code in ("FUNC", "SCAN", "COMP", "WRP_IF", "WRP_OF"):
        A("  localparam logic [TMW*NSBLK-1:0] ENC_%s = {NSBLK{%d'b%s}};" % (code, m["tmw"], m["enc"][code]))
    A("endpackage")
    return "\n".join(L) + "\n"


def report(m: dict, digest: str) -> dict:
    return {"generated_by": "scripts/gen_part_map.py", "input": "declarations/part-map-declared.json",
            "input_sha256": digest, "nch_sum": m["nch_sum"], "npart": m["npart"],
            "part_codes": {"extest": m["part_extest"], "loopback": m["part_loopback"],
                           "mode0": m["part_mode0"]},
            "blocks": m["blocks"], "plan": m["plan"], "p0_member": "%d'h%X" % (m["nblk"], m["p0_member"])}


def mkm_mismatches(m: dict) -> list[str]:
    """The derived scalars against the MKM's package rows (C-2)."""
    rows = {r["name"]: str(r["default"]) for r in json.loads(MKM.read_text(encoding="utf-8"))["parameters"]
            if r["module"] == "dft_part_map_pkg"}
    want = {"NBLK": str(m["nblk"]), "NSBLK": str(m["nsblk"]), "NPIN": str(m["npin"]),
            "NMODE": str(m["nmode"]), "NPART": "4'd%d" % m["npart"], "NWRAP": str(m["nwrap"]),
            "NTOP": str(m["ntop"]), "TMW": str(m["tmw"]), "NCH_SUM": str(m["nch_sum"]),
            "PART_EXTEST": "4'd%d" % m["part_extest"], "PART_LOOPBACK": "4'd%d" % m["part_loopback"],
            "PART_MODE0": str(m["part_mode0"]), "P0_MEMBER": "%d'h%X" % (m["nblk"], m["p0_member"])}
    for b in m["blocks"]:
        if b["routed"]:
            want["NCH_%s" % b["name"].upper()] = str(b["nch"])
        if b["routed"] or b["name"] == "lpddr":
            want["B_%s" % b["name"].upper()] = str(b["b"])
    for n in m["routed"]:
        want["OFF_%s" % n.upper()] = str(m["off"][n])
    return ["%s: MKM %s, generator %s" % (k, rows.get(k), v) for k, v in want.items() if rows.get(k) != v]


def main(argv: list[str]) -> int:
    check = "--check" in argv
    raw = MAP.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    try:
        m = derive(json.loads(raw.decode("utf-8")))
    except MapRefused as exc:
        print("REFUSED MAP: %s" % exc)
        return 2
    text = render(m, digest)
    rep = report(m, digest)
    if check:
        bad = []
        if not OUT.is_file() or OUT.read_text(encoding="utf-8") != text:
            bad.append("rtl/dft_part_map_pkg.sv differs from a fresh generation")
        bad += mkm_mismatches(m)
        for b in bad:
            print("FAILED PART_MAP: %s" % b)
        print("gen_part_map --check: %d finding(s); %d channels, %d PARTs" % (len(bad), m["nch_sum"], m["npart"]))
        return 1 if bad else 0
    OUT.write_text(text, encoding="utf-8", newline="")
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(rep, indent=2) + "\n", encoding="utf-8", newline="")
    for pl in m["plan"]:
        print("mode %d (PART %d): %s; unmapped %s" % (pl["mode"], pl["part"], ", ".join(
            "%s %d-%d" % (l["block"], l["first_pin"], l["last_pin"]) for l in pl["lanes"]),
            pl["pins_unmapped"] or "none"))
    print("wrote %s (%d channels, NPART %d)" % (OUT.relative_to(PKG), m["nch_sum"], m["npart"]))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
