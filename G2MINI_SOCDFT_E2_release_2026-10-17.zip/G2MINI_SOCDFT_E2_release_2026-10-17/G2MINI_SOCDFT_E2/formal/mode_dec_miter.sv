// Artifact identity: Verification plan and results
// mode_dec_miter: the partition decode and a mutant copy of it on shared free inputs, every
// output compared on every step. dft_mode_dec is combinational, so the claim needs no helper
// invariant. Read by tools/run_equiv.py (declarations/equiv-declared.json); the mutant copy is
// renamed dft_mode_dec_mut by the tool.
`default_nettype none
module mode_dec_miter;
  localparam int NBLK  = dft_part_map_pkg::NBLK;
  localparam int NSBLK = dft_part_map_pkg::NSBLK;
  localparam int TMW   = dft_part_map_pkg::TMW;
  localparam int W = 4 + 2*NBLK + 2 + 4*NSBLK + TMW*NSBLK + 1 + 4 + 16 + 2 + 1;

  (* anyseq *) wire        tm;
  (* anyseq *) wire        dftmax_i;
  (* anyseq *) wire        dftse_i;
  (* anyseq *) wire [31:0] dtr_cfg;
  (* anyseq *) wire [31:0] dtr_lpddr;

  wire [W-1:0] o_ref, o_mut;

  dft_mode_dec u_ref (
    .tm(tm), .dftmax_i(dftmax_i), .dftse_i(dftse_i), .dtr_cfg(dtr_cfg), .dtr_lpddr(dtr_lpddr),
    .part(o_ref[3:0]), .sel(o_ref[4 +: NBLK]), .active(o_ref[4+NBLK +: NBLK]),
    .extest(o_ref[4+2*NBLK]), .loopback(o_ref[5+2*NBLK]),
    .blk_dfttm(o_ref[6+2*NBLK +: NSBLK]), .blk_scan_shift_en(o_ref[6+2*NBLK+NSBLK +: NSBLK]),
    .blk_wrap_shift_en(o_ref[6+2*NBLK+2*NSBLK +: NSBLK]),
    .blk_test_mode_tp(o_ref[6+2*NBLK+3*NSBLK +: NSBLK]),
    .blk_test_mode(o_ref[6+2*NBLK+4*NSBLK +: TMW*NSBLK]),
    .top_scan_shift_en(o_ref[6+2*NBLK+(4+TMW)*NSBLK]),
    .lpddr_atpg_mode(o_ref[7+2*NBLK+(4+TMW)*NSBLK]),
    .lpddr_compression_mode(o_ref[8+2*NBLK+(4+TMW)*NSBLK]),
    .lpddr_phy0_burnin(o_ref[9+2*NBLK+(4+TMW)*NSBLK]),
    .lpddr_phy1_burnin(o_ref[10+2*NBLK+(4+TMW)*NSBLK]),
    .lpddr_atpg_se(o_ref[11+2*NBLK+(4+TMW)*NSBLK +: 16]),
    .lpddr_scan_ctl(o_ref[27+2*NBLK+(4+TMW)*NSBLK +: 2]),
    .lpddr_scan_shift_cg(o_ref[29+2*NBLK+(4+TMW)*NSBLK]));

  dft_mode_dec_mut u_mut (
    .tm(tm), .dftmax_i(dftmax_i), .dftse_i(dftse_i), .dtr_cfg(dtr_cfg), .dtr_lpddr(dtr_lpddr),
    .part(o_mut[3:0]), .sel(o_mut[4 +: NBLK]), .active(o_mut[4+NBLK +: NBLK]),
    .extest(o_mut[4+2*NBLK]), .loopback(o_mut[5+2*NBLK]),
    .blk_dfttm(o_mut[6+2*NBLK +: NSBLK]), .blk_scan_shift_en(o_mut[6+2*NBLK+NSBLK +: NSBLK]),
    .blk_wrap_shift_en(o_mut[6+2*NBLK+2*NSBLK +: NSBLK]),
    .blk_test_mode_tp(o_mut[6+2*NBLK+3*NSBLK +: NSBLK]),
    .blk_test_mode(o_mut[6+2*NBLK+4*NSBLK +: TMW*NSBLK]),
    .top_scan_shift_en(o_mut[6+2*NBLK+(4+TMW)*NSBLK]),
    .lpddr_atpg_mode(o_mut[7+2*NBLK+(4+TMW)*NSBLK]),
    .lpddr_compression_mode(o_mut[8+2*NBLK+(4+TMW)*NSBLK]),
    .lpddr_phy0_burnin(o_mut[9+2*NBLK+(4+TMW)*NSBLK]),
    .lpddr_phy1_burnin(o_mut[10+2*NBLK+(4+TMW)*NSBLK]),
    .lpddr_atpg_se(o_mut[11+2*NBLK+(4+TMW)*NSBLK +: 16]),
    .lpddr_scan_ctl(o_mut[27+2*NBLK+(4+TMW)*NSBLK +: 2]),
    .lpddr_scan_shift_cg(o_mut[29+2*NBLK+(4+TMW)*NSBLK]));

  always @* begin
    eq_ports: assert (o_ref == o_mut);
  end
endmodule
`default_nettype wire
