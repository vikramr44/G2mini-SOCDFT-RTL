// Artifact identity: FORMAL
// soc_dft_fv: formal harness of soc_dft, the one top the proof elaborates.
//
// What is in the proof. tools/run_formal.py generates a SymbiYosys script with
// no `multiclock on`, so SymbiYosys maps every flop onto one implicit global
// clock (formalff -clk2ff) and refuses a module that clocks on both edges of
// one signal. dft_tap and dft_dtr_reg do (rising-TCK1 shift stages, falling-
// TCK1 update / retime stages), so they, dft_dtr, dft_sms_srv and soc_dft
// itself cannot be elaborated by this proof. The harness therefore instantiates
// every soc_dft sub-module that clocks on one edge only, standalone, with every
// input free on every step (an input of this top):
//   u_jtag_fv  dft_jtag1_rtr (P_OE_GATED 1, P_TM_OPEN 1)          JTAG1 router, 8.4
//   u_pad_fv   dft_pad_if (P_DFTSO_HIZ_M0 1, P_DFTMAX_COMP 1)      pad interface, rst_dtr_n
//   u_dec_fv   dft_mode_dec (P_PARTITIONED 1) -> u_scan_fv dft_scan_rtr   11.3, 12.3
//   u_crg_fv   dft_crg_ctl, fed by u_dec_fv's sel / active          13.2
//   u_ddr_fv   dft_ddr_tdr (P_TDR_EN_EDGE 1)                       15.4
//   u_sync_fv  dft_sync2 (8 bits, the DTR_STS synchroniser)        10.4
// The DTR words, the TAP state and the IR reaching these modules are free, so
// each property holds for every value those registers can take.
//
// Time. One solver step is one TCK1 cycle: every flop advances once per step,
// whatever its edge, and an asynchronous reset shows its reset value in the
// step in which it is low. SymbiYosys also assumes every clock net holds the
// value it has before its active edge (formalff -assume), so a net clocked on
// both edges anywhere in the proof makes the assumptions unsatisfiable. The
// rising-edge flops (dft_rst_sync, dft_sync2, the history below) take TCK1;
// dft_ddr_tdr's falling-edge enable flops take TCK1_F, the same design net seen
// from its falling edge. The same rule ties that instance's TDRCLK (TCK1_F gated
// by ddr_tdr_en, the clock of its WRSTN synchroniser) low, which forces
// t_ddr_en = 0 on that instance: no property here is stated over TDRCLK, WRSTN
// or anything else that depends on ddr_tdr_en.
`timescale 1ns/1ps
`default_nettype none
module soc_dft_fv (
  input  wire                                            TCK1,
  input  wire                                            TCK1_F,
  input  wire                                            TRSTN1,
  input  wire                                            PwrOk,
  input  wire                                            Rstn,
  // JTAG1 router
  input  wire [1:0]                                      TSEL1,
  input  wire                                            TMS1,
  input  wire                                            arc_tdo1,
  input  wire                                            arc_tdo1_oe,
  input  wire                                            pcia_tdo1,
  input  wire                                            pcia_tdo1_oe,
  input  wire                                            pcib_tdo1,
  input  wire                                            pcib_tdo1_oe,
  input  wire                                            sms_tdo1,
  input  wire                                            sms_tdo1_oe,
  // pad side
  input  wire                                            DFTTM,
  input  wire                                            DFTMAX,
  input  wire                                            DFTSE,
  input  wire [dft_part_map_pkg::NPIN-1:0]               DFTSI,
  input  wire [dft_part_map_pkg::NPIN-1:0]               pad_dftso_o,
  // mode decode / router / CRG (DTR words free)
  input  wire                                            s_tm,
  input  wire                                            s_dftmax,
  input  wire                                            s_dftse,
  input  wire [31:0]                                     s_cfg,
  input  wire [31:0]                                     s_lpddr,
  input  wire [dft_part_map_pkg::NPIN-1:0]               s_dftsi,
  input  wire [dft_part_map_pkg::NCH_SUM-1:0]            s_test_so,
  input  wire [dft_part_map_pkg::NWRAP*dft_part_map_pkg::NSBLK-1:0] s_wrap_so,
  input  wire [dft_part_map_pkg::NTOP-1:0]               s_top_so,
  // DDR TDR bridge (TAP state, IR and ddr_tdr_en free)
  input  wire                                            t_tdi,
  input  wire [3:0]                                      t_state,
  input  wire [4:0]                                      t_ir,
  input  wire                                            t_tm,
  input  wire                                            t_ddr_en,
  input  wire [1:0]                                      t_cmd_tdo,
  input  wire [1:0]                                      t_rd_tdo,
  // DTR_STS synchroniser
  input  wire [7:0]                                      y_d
);
  localparam int NPIN  = dft_part_map_pkg::NPIN;
  localparam int NSBLK = dft_part_map_pkg::NSBLK;
  localparam int NBLK  = dft_part_map_pkg::NBLK;
  localparam int NWRAP = dft_part_map_pkg::NWRAP;
  localparam int NTOP  = dft_part_map_pkg::NTOP;
  localparam int TMW   = dft_part_map_pkg::TMW;
  localparam int NCHS  = dft_part_map_pkg::NCH_SUM;
  localparam int OFF_PCIA = dft_part_map_pkg::OFF_PCIA;
  localparam int NCH_PCIA = dft_part_map_pkg::NCH_PCIA;

  // TAP states and DDRx codes, from spec Tables 45 and 46 (MKM fsms.tap)
  localparam logic [3:0] S_CDR = 4'h6, S_SHDR = 4'h2, S_UDR = 4'h5;
  localparam logic [4:0] I_DDR0_CMD = 5'd5, I_DDR0_RD = 5'd6, I_DDR1_CMD = 5'd7, I_DDR1_RD = 5'd8;

  // ---------------------------------------------------------------- JTAG1 router
  wire j_arc_tms1, j_pcia_tms1, j_pcib_tms1, j_sms_tms1, j_tdo1, j_tdo1_oe;
  dft_jtag1_rtr #(.P_OE_GATED(1'b1), .P_TM_OPEN(1'b1)) u_jtag_fv (
    .TSEL1(TSEL1), .TMS1(TMS1), .tm(DFTTM), .arc_tms1(j_arc_tms1), .pcia_tms1(j_pcia_tms1),
    .pcib_tms1(j_pcib_tms1), .sms_tms1(j_sms_tms1), .arc_tdo1(arc_tdo1), .arc_tdo1_oe(arc_tdo1_oe),
    .pcia_tdo1(pcia_tdo1), .pcia_tdo1_oe(pcia_tdo1_oe), .pcib_tdo1(pcib_tdo1), .pcib_tdo1_oe(pcib_tdo1_oe),
    .sms_tdo1(sms_tdo1), .sms_tdo1_oe(sms_tdo1_oe), .TDO1(j_tdo1), .TDO1_OE(j_tdo1_oe));

  // ---------------------------------------------------------------- pad interface
  wire [NPIN-1:0] p_dftso, p_dftsi_i;
  wire            p_dftso_oe, p_tm, p_dftmax_i, p_dftse_i, p_rst_dtr_n;
  dft_pad_if #(.P_DFTSO_HIZ_M0(1'b1), .P_DFTMAX_COMP(1'b1)) u_pad_fv (
    .DFTTM(DFTTM), .DFTMAX(DFTMAX), .DFTSE(DFTSE), .DFTSI(DFTSI), .DFTSO(p_dftso), .DFTSO_OE(p_dftso_oe),
    .PwrOk(PwrOk), .TCK1(TCK1), .tm(p_tm), .dftmax_i(p_dftmax_i), .dftse_i(p_dftse_i), .dftsi_i(p_dftsi_i),
    .dftso_o(pad_dftso_o), .rst_dtr_n(p_rst_dtr_n));

  // ---------------------------------------------------------------- mode decode, scan router, CRG
  wire [3:0]             s_part;
  wire [NBLK-1:0]        s_sel, s_active;
  wire                   s_extest, s_loopback;
  wire [NSBLK-1:0]       s_blk_dfttm, s_blk_sse, s_blk_wse, s_blk_tp;
  wire [TMW*NSBLK-1:0]   s_blk_tm;
  wire                   s_top_sse, s_atpg_mode, s_comp_mode, s_phy0_bi, s_phy1_bi, s_shift_cg;
  wire [15:0]            s_atpg_se;
  wire [1:0]             s_scan_ctl;
  wire [NPIN-1:0]        s_dftso;
  wire [NCHS-1:0]        s_test_si;
  wire [NWRAP*NSBLK-1:0] s_wrap_si;
  wire [NTOP-1:0]        s_top_si;
  dft_mode_dec #(.P_PARTITIONED(1'b1)) u_dec_fv (
    .tm(s_tm), .dftmax_i(s_dftmax), .dftse_i(s_dftse), .dtr_cfg(s_cfg), .dtr_lpddr(s_lpddr),
    .part(s_part), .sel(s_sel), .active(s_active), .extest(s_extest), .loopback(s_loopback),
    .blk_dfttm(s_blk_dfttm), .blk_scan_shift_en(s_blk_sse), .blk_wrap_shift_en(s_blk_wse),
    .blk_test_mode(s_blk_tm), .blk_test_mode_tp(s_blk_tp), .top_scan_shift_en(s_top_sse),
    .lpddr_atpg_mode(s_atpg_mode), .lpddr_compression_mode(s_comp_mode), .lpddr_phy0_burnin(s_phy0_bi),
    .lpddr_phy1_burnin(s_phy1_bi), .lpddr_atpg_se(s_atpg_se), .lpddr_scan_ctl(s_scan_ctl),
    .lpddr_scan_shift_cg(s_shift_cg));
  dft_scan_rtr u_scan_fv (
    .tm(s_tm), .part(s_part), .sel(s_sel[NSBLK-1:0]), .extest(s_extest), .loopback(s_loopback),
    .dftsi_i(s_dftsi), .dftso_o(s_dftso), .test_si_all(s_test_si), .test_so_all(s_test_so),
    .wrap_si_all(s_wrap_si), .wrap_so_all(s_wrap_so), .top_test_si(s_top_si), .top_test_so(s_top_so));
  wire        c_test_clk_sel, c_rst_byp, c_rst_n_test, c_scan_rstn;
  wire [2:0]  c_pll_byp;
  wire [12:0] c_blk_clk_en, c_comp_clk_en;
  wire [4:0]  c_lpddr_clk_en;
  dft_crg_ctl u_crg_fv (
    .tm(s_tm), .dftmax_i(s_dftmax), .Rstn(Rstn), .dtr_cfg(s_cfg), .sel(s_sel), .active(s_active),
    .dft_crg_test_clk_sel(c_test_clk_sel), .dft_crg_pll_byp(c_pll_byp), .dft_crg_blk_clk_en(c_blk_clk_en),
    .dft_crg_comp_clk_en(c_comp_clk_en), .dft_crg_lpddr_clk_en(c_lpddr_clk_en), .dft_crg_rst_byp(c_rst_byp),
    .dft_crg_rst_n_test(c_rst_n_test), .lpddr_scan_rstn(c_scan_rstn));

  // ---------------------------------------------------------------- DDR TDR bridge
  wire       t_tdrclk, t_wrstn, t_tdo_ddr;
  wire [1:0] t_cmd_cap, t_cmd_sh, t_cmd_up, t_rd_cap, t_rd_sh, t_rd_up, t_wsi;
  dft_ddr_tdr #(.P_TDR_EN_EDGE(1'b1)) u_ddr_fv (
    .TCK1(TCK1_F), .TRSTN1(TRSTN1), .tap_tdi(t_tdi), .tap_state(t_state), .ir(t_ir), .tm(t_tm),
    .ddr_tdr_en(t_ddr_en), .lpddr_tdrclk(t_tdrclk), .lpddr_wrstn(t_wrstn),
    .lpddr_cmd_tdr_capture_en(t_cmd_cap), .lpddr_cmd_tdr_shift_en(t_cmd_sh), .lpddr_cmd_tdr_update_en(t_cmd_up),
    .lpddr_rd_tdr_capture_en(t_rd_cap), .lpddr_rd_tdr_shift_en(t_rd_sh), .lpddr_rd_tdr_update_en(t_rd_up),
    .lpddr_wsi(t_wsi), .lpddr_cmd_tdr_tdo(t_cmd_tdo), .lpddr_rd_tdr_tdo(t_rd_tdo), .dr_tdo_ddr(t_tdo_ddr));

  // ---------------------------------------------------------------- DTR_STS synchroniser
  wire [7:0] y_q;
  dft_sync2 #(.P_WIDTH(8)) u_sync_fv (.clk_i(TCK1), .d_i(y_d), .q_o(y_q));

  // ---------------------------------------------------------------- history (one step = one TCK1 cycle)
  reg        past_valid = 1'b0;
  reg        past2_valid = 1'b0;
  reg        pwr_q1, pwr_q2, trst_q, ttm_q;
  reg [3:0]  tstate_q;
  reg [4:0]  tir_q;
  reg [7:0]  y_d1, y_d2;
  always @(posedge TCK1) begin
    past_valid  <= 1'b1;
    past2_valid <= past_valid;
    pwr_q1      <= PwrOk;
    pwr_q2      <= pwr_q1;
    trst_q      <= TRSTN1;
    ttm_q       <= t_tm;
    tstate_q    <= t_state;
    tir_q       <= t_ir;
    y_d1        <= y_d;
    y_d2        <= y_d1;
  end

  // the run starts from reset: TRSTN1 and PwrOk low in the first cycle
  always @* if (!past_valid) assume (!TRSTN1 && !PwrOk);

  // ---------------------------------------------------------------- derived terms
  wire tdo_sel    = (TSEL1 == 2'b00) ? arc_tdo1    : (TSEL1 == 2'b01) ? pcia_tdo1    :
                    (TSEL1 == 2'b10) ? pcib_tdo1   : sms_tdo1;
  wire tdo_oe_sel = (TSEL1 == 2'b00) ? arc_tdo1_oe : (TSEL1 == 2'b01) ? pcia_tdo1_oe :
                    (TSEL1 == 2'b10) ? pcib_tdo1_oe : sms_tdo1_oe;
  wire [3:0] part = s_cfg[3:0];
  wire [11:0] tdr_en = {t_rd_up, t_rd_sh, t_rd_cap, t_cmd_up, t_cmd_sh, t_cmd_cap};
  // the 15.4 enable decode of the previous cycle, written independently of the RTL
  wire [1:0] q_cmd = {tir_q == I_DDR1_CMD, tir_q == I_DDR0_CMD};
  wire [1:0] q_rd  = {tir_q == I_DDR1_RD,  tir_q == I_DDR0_RD};
  wire       q_ok  = !ttm_q;
  wire [11:0] tdr_en_want = {q_rd  & {2{q_ok && tstate_q == S_UDR}},  q_rd  & {2{q_ok && tstate_q == S_SHDR}},
                             q_rd  & {2{q_ok && tstate_q == S_CDR}},
                             q_cmd & {2{q_ok && tstate_q == S_UDR}},  q_cmd & {2{q_ok && tstate_q == S_SHDR}},
                             q_cmd & {2{q_ok && tstate_q == S_CDR}}};
  wire t_phy0_ir = (t_ir == I_DDR0_CMD) || (t_ir == I_DDR0_RD);   // {phy1, phy0} = [1:0]
  wire t_phy1_ir = (t_ir == I_DDR1_CMD) || (t_ir == I_DDR1_RD);

  // every routed block's snps_test_mode code is one-hot in test mode and 0000 in M0
  logic tm_codes_ok;
  always_comb begin
    tm_codes_ok = 1'b1;
    for (int b = 0; b < NSBLK; b++) begin
      if (s_tm) tm_codes_ok = tm_codes_ok & $onehot(s_blk_tm[TMW*b +: TMW]);
      else      tm_codes_ok = tm_codes_ok & (s_blk_tm[TMW*b +: TMW] == 4'b0000);
    end
  end

  // EXTEST (PART 0): wrapper chains in series on pin b, TOP chain t on pin NSBLK + t
  logic extest_ok;
  always_comb begin
    extest_ok = (s_test_si == '0) && (s_sel == '0) && !s_loopback;
    for (int b = 0; b < NSBLK; b++) begin
      extest_ok = extest_ok && (s_wrap_si[NWRAP*b] == s_dftsi[b])
                            && (s_wrap_si[NWRAP*b + 1] == s_wrap_so[NWRAP*b])
                            && (s_dftso[b] == s_wrap_so[NWRAP*b + 1])
                            && (s_blk_tm[TMW*b +: TMW] == 4'b1000);
    end
    for (int t = 0; t < NTOP; t++) begin
      extest_ok = extest_ok && (s_top_si[t] == s_dftsi[NSBLK + t]) && (s_dftso[NSBLK + t] == s_top_so[t]);
    end
    for (int k = NSBLK + NTOP; k < NPIN; k++) begin
      extest_ok = extest_ok && (s_dftso[k] == 1'b0);
    end
  end

  // PART 1 (INTEST mode 0): pcia alone, channel j on DFTSI[j] / DFTSO[j]; every other block's test_si is 0
  logic part1_ok;
  always_comb begin
    part1_ok = (s_wrap_si == '0) && (s_top_si == '0) && !s_extest && !s_loopback;
    for (int c = 0; c < NCHS; c++) begin
      if (c >= OFF_PCIA && c < OFF_PCIA + NCH_PCIA)
        part1_ok = part1_ok && (s_test_si[c] == s_dftsi[c - OFF_PCIA]);
      else
        part1_ok = part1_ok && (s_test_si[c] == 1'b0);
    end
    for (int k = 0; k < NPIN; k++) begin
      part1_ok = part1_ok && (s_dftso[k] == s_test_so[OFF_PCIA + k]);
    end
  end

  // ---------------------------------------------------------------- properties
  always @* begin
    // REQ-04, REQ-35: the TMS equations of 8.4; the SOC_DFT TAP's sms_tms1 = 1 whenever DFTTM = 1
    p_jtag_route_tms: assert (
         (j_arc_tms1  == (((TSEL1 == 2'b00) || DFTTM) ? TMS1 : 1'b1))
      && (j_pcia_tms1 == (((TSEL1 == 2'b01) || DFTTM) ? TMS1 : 1'b1))
      && (j_pcib_tms1 == (((TSEL1 == 2'b10) || DFTTM) ? TMS1 : 1'b1))
      && (j_sms_tms1  == (((TSEL1 == 2'b11) && !DFTTM) ? TMS1 : 1'b1)));
    // REQ-05, INV-02: with P_OE_GATED = 1, TDO1 and TDO1_OE carry the TSEL1-selected target only
    p_jtag_tdo_sel: assert ((j_tdo1 == tdo_sel) && (j_tdo1_oe == tdo_oe_sel));
    // REQ-02, REQ-37: DFTSO_OE = DFTTM at P_DFTSO_HIZ_M0 = 1; dftmax_i = (DFTMAX == P_DFTMAX_COMP); pins pass straight
    p_pad_if: assert ((p_dftso_oe == DFTTM) && (p_tm == DFTTM) && (p_dftmax_i == DFTMAX)
                      && (p_dftse_i == DFTSE) && (p_dftsi_i == DFTSI) && (p_dftso == pad_dftso_o));
    // REQ-03: rst_dtr_n is 0 while PwrOk = 0 and releases on the second rising TCK1 after PwrOk = 1
    p_rst_dtr_release: assert (!PwrOk ? !p_rst_dtr_n
                                      : (!past2_valid || (p_rst_dtr_n == (pwr_q1 && pwr_q2))));
    // REQ-01, REQ-15, REQ-22, INV-03: with tm = 0 the block, TOP, CRG and LPDDR scan controls hold M0 values
    p_m0_controls: assert (s_tm || (
         (s_blk_dfttm == '0) && (s_blk_sse == '0) && (s_blk_wse == '0) && (s_blk_tp == '0) && (s_blk_tm == '0)
      && !s_top_sse && (s_sel == '0) && (s_active == '0) && !s_extest && !s_loopback
      && !c_test_clk_sel && !c_rst_byp && (c_pll_byp == 3'b000) && (c_blk_clk_en == 13'h1FFF)
      && (c_comp_clk_en == 13'h0000) && (c_lpddr_clk_en == 5'h00) && c_scan_rstn
      && (s_atpg_se == 16'h0000) && !s_phy0_bi && !s_phy1_bi && (s_scan_ctl == 2'b00)));
    // REQ-20, INV-04: with tm = 0 every router output (test_si, wrap_si, top_test_si, DFTSO) is 0
    p_rtr_tm0_zero: assert (s_tm || ((s_dftso == '0) && (s_test_si == '0) && (s_wrap_si == '0) && (s_top_si == '0)));
    // REQ-19: in loopback (tm = 1, PART = 15) DFTSO = DFTSI on every pin
    p_loopback: assert (!(s_tm && (part == 4'd15)) || (s_dftso == s_dftsi));
    // REQ-14, REQ-17: a PART code that names no mode (5..14) selects no block and routes nothing
    p_part_nonmode: assert (!(s_tm && (part >= 4'd5) && (part <= 4'd14)) || (
         (s_sel == '0) && (s_active == '0) && !s_extest && !s_loopback && (s_dftso == '0) && (s_test_si == '0)
      && (s_wrap_si == '0) && (s_top_si == '0) && (s_blk_tm == {NSBLK{4'b0100}})
      && (s_blk_sse == ((s_dftse && !s_cfg[21]) ? {NSBLK{1'b1}} : {NSBLK{1'b0}}))));
    // REQ-16, REQ-14: block test-mode codes are one-hot in test mode and FUNC (0000) in M0
    p_test_mode_onehot: assert (tm_codes_ok);
    // REQ-18: EXTEST (PART 0) puts each block's two wrapper chains in series on pin b, TOP chain t on pin 11 + t
    p_extest_decode: assert (!(s_tm && (part == 4'd0)) || extest_ok);
    // REQ-17: PART 1 routes pcia channel j to DFTSI[j] and DFTSO[j]; every unselected block's test_si is 0
    p_part1_route: assert (!(s_tm && (part == 4'd1)) || part1_ok);
    // INV-01, REQ-35: a TCK1 cycle with tm = 1 (or TRSTN1 = 0) leaves every LPDDR TDR enable at 0
    p_tdr_en_tm_off: assert (!(!TRSTN1 || (past_valid && ttm_q)) || (tdr_en == 12'h000));
    // REQ-24 (15.4): each TDR enable is the previous cycle's DDRx-instruction and TAP-state decode, gated by ~tm
    p_tdr_en_decode: assert (!TRSTN1 ? (tdr_en == 12'h000)
                                     : (!(past_valid && trst_q) || (tdr_en == tdr_en_want)));
    // REQ-24 (15.4): WSI[i] carries TDI only under PHY i's DDRx codes; the DDR DR's TDO is the selected PHY TDR's
    p_ddr_wsi_tdo: assert ((t_wsi == {t_tdi && t_phy1_ir, t_tdi && t_phy0_ir})
                           && (t_tdo_ddr == ((t_ir == I_DDR0_CMD) ? t_cmd_tdo[0] : (t_ir == I_DDR0_RD) ? t_rd_tdo[0] :
                                             (t_ir == I_DDR1_CMD) ? t_cmd_tdo[1] : (t_ir == I_DDR1_RD) ? t_rd_tdo[1] :
                                             1'b0)));
    // REQ-13: every DTR_STS input reaches the register through two TCK1 flops
    p_sts_sync2: assert (!past2_valid || (y_q == y_d2));
  end
endmodule
`default_nettype wire
