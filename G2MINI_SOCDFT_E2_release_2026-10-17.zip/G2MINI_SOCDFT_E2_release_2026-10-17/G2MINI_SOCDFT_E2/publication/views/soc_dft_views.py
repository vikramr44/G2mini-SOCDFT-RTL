"""The six architecture views of soc_dft, drawn from explicit coordinates.

Each function returns one figure_views.Fig. Box titles and wire labels carry
only names the microarchitecture record holds; descriptive words are sub rows.
Interface ids (i1, i2, ...) are the bundles tabled beside each figure.
"""
from sdip_tools.figure_views import Fig


def _hwire(f, x0, x1, y, label, both=False):
    f.wire([(x0, y), (x1, y)], arrow="both" if both else "end", label=label,
           at=((x0 + x1) / 2, y - 3, "middle"))


def overview():
    f = Fig("view-overview", 468, 340)
    f.box((6, 26, 80, 250), "pads", fill="pad", align="start",
          sub_rows=["scan pins", "JTAG1 pins", "PwrOk, Rstn"])
    f.box((6, 270, 80, 320), "targets", fill="ext", align="start",
          sub_rows=["ARC chain", "PHY TAPs"])
    f.box((96, 6, 372, 334), "soc_dft", fill="note", align="start")
    a = [("u_pad_if", "dft_pad_if", 30), ("u_jtag1_rtr", "dft_jtag1_rtr", 78),
         ("u_tap", "dft_tap", 126), ("u_dtr", "dft_dtr", 174)]
    for inst, mod, y in a:
        f.box((108, y, 230, y + 38), inst, sub_rows=[mod])
    f.box((108, 222, 230, 300), "u_sms_srv", align="start", sub_rows=["dft_sms_srv"])
    f.box((116, 256, 222, 294), "u_stub", fill="stub", sub_rows=["STUB"])
    b = [("u_mode_dec", "dft_mode_dec", 30), ("u_scan_rtr", "dft_scan_rtr", 78),
         ("u_crg_ctl", "dft_crg_ctl", 126), ("u_ddr_tdr", "dft_ddr_tdr", 174)]
    for inst, mod, y in b:
        f.box((244, y, 362, y + 38), inst, sub_rows=[mod])
    f.box((388, 26, 462, 118), "blocks", fill="ext", align="start", sub_rows=["11 + TOP"])
    f.box((388, 126, 462, 164), "clock gen", fill="ext", align="start", sub_rows=["chip CRG"])
    f.box((388, 172, 462, 212), "memory", fill="ext", align="start", sub_rows=["LPDDR5 SS"])
    f.box((388, 222, 462, 262), "sms ports", fill="ext", align="start", sub_rows=["11 WSP"])
    _hwire(f, 80, 108, 50, "i1", both=True)
    _hwire(f, 80, 108, 97, "i2", both=True)
    f.wire([(80, 296), (88, 296), (88, 110), (108, 110)], arrow="both",
           label="i3", at=(91, 205, "start"))
    _hwire(f, 362, 388, 49, "i4")
    _hwire(f, 362, 388, 97, "i7", both=True)
    _hwire(f, 362, 388, 145, "i5", both=True)
    _hwire(f, 362, 388, 193, "i6", both=True)
    f.wire([(230, 242), (388, 242)], arrow="both", label="i8", at=(300, 239, "middle"))
    return f


def serial_path():
    f = Fig("view-serial", 468, 250)
    f.box((6, 40, 70, 90), "TDI1", fill="pad", sub_rows=["pad"])
    f.box((6, 150, 70, 200), "TDO1", fill="pad", sub_rows=["pad"])
    f.box((84, 6, 380, 244), "soc_dft", fill="note", align="start")
    f.box((96, 36, 196, 96), "u_sms_srv", align="start", sub_rows=["chain device 1"])
    f.box((104, 66, 188, 92), "u_stub", fill="stub", sub_rows=["STUB"])
    f.box((222, 36, 366, 96), "u_tap", align="start", sub_rows=["chain device 2", "IR, IDCODE, BYPASS"])
    f.box((222, 118, 296, 168), "u_dtr", sub_rows=["three DTRs"])
    f.box((304, 118, 366, 168), "u_ddr_tdr", sub_rows=["DDRx"])
    f.box((96, 150, 196, 200), "u_jtag1_rtr", sub_rows=["TDO1 mux"])
    f.box((396, 110, 462, 176), "phy tdrs", fill="ext", align="start", sub_rows=["phy0, phy1"])
    _hwire(f, 70, 96, 60, "i1")
    _hwire(f, 196, 222, 60, "i2")
    f.wire([(258, 96), (258, 118)], arrow="both", label="i3", at=(262, 110, "start"))
    f.wire([(335, 96), (335, 118)], arrow="both", label="i4", at=(339, 110, "start"))
    _hwire(f, 366, 396, 142, "i5", both=True)
    f.wire([(222, 85), (210, 85), (210, 175), (196, 175)], label="i6", at=(206, 135, "end"))
    _hwire(f, 96, 70, 175, "i7")
    return f


def scan_path():
    f = Fig("view-scan", 468, 250)
    f.box((6, 70, 70, 200), "pads", fill="pad", align="start", sub_rows=["DFTSI", "DFTSO"])
    f.box((84, 6, 372, 244), "soc_dft", fill="note", align="start")
    f.box((96, 70, 176, 200), "u_pad_if", sub_rows=["dft_pad_if"])
    f.box((196, 14, 362, 52), "u_mode_dec", sub_rows=["dft_mode_dec"])
    f.box((196, 70, 362, 236), "u_scan_rtr", align="start",
          sub_rows=["dft_scan_rtr", "gated scan-in fan-out", "per lane: 4:1 over the modes",
                    "per lane: extest 2:1", "per lane: loopback 2:1"])
    f.box((388, 70, 462, 236), "blocks", fill="ext", align="start", sub_rows=["11 + TOP"])
    _hwire(f, 70, 96, 135, "i1", both=True)
    _hwire(f, 176, 196, 135, "i2", both=True)
    f.wire([(279, 52), (279, 70)], label="i3", at=(283, 64, "start"))
    _hwire(f, 362, 388, 110, "i4")
    _hwire(f, 388, 362, 190, "i5")
    return f


def control_path():
    f = Fig("view-control", 468, 260)
    f.box((6, 30, 70, 110), "pads", fill="pad", align="start", sub_rows=["DFTTM", "DFTMAX", "DFTSE"])
    f.box((84, 6, 372, 254), "soc_dft", fill="note", align="start")
    f.box((96, 30, 190, 80), "u_pad_if", sub_rows=["tm, dftmax_i"])
    f.box((96, 150, 190, 210), "u_dtr", sub_rows=["dtr_cfg", "dtr_lpddr"])
    f.box((236, 30, 362, 80), "u_mode_dec", sub_rows=["partition decode"])
    f.box((236, 100, 362, 140), "u_scan_rtr", sub_rows=["dft_scan_rtr"])
    f.box((236, 160, 362, 210), "u_crg_ctl", sub_rows=["test clock, reset"])
    f.box((388, 30, 462, 80), "blocks", fill="ext", align="start", sub_rows=["test modes"])
    f.box((388, 160, 462, 210), "clock gen", fill="ext", align="start", sub_rows=["chip CRG"])
    _hwire(f, 70, 96, 55, "i1")
    _hwire(f, 190, 236, 45, "i2")
    f.wire([(190, 70), (212, 70), (212, 175), (236, 175)], label="i3", at=(209, 120, "end"))
    f.wire([(190, 165), (228, 165), (228, 65), (236, 65)], label="i4", at=(231, 150, "start"))
    _hwire(f, 190, 236, 195, "i5")
    _hwire(f, 362, 388, 55, "i6")
    _hwire(f, 362, 388, 185, "i7")
    f.wire([(300, 80), (300, 100)], label="i8", at=(304, 92, "start"))
    return f


def clock_reset():
    f = Fig("view-clock-reset", 468, 270)
    f.box((6, 30, 80, 230), "pads", fill="pad", align="start", sub_rows=["TCK1", "TRSTN1", "PwrOk", "status"])
    f.box((96, 6, 462, 264), "soc_dft", fill="note", align="start")
    f.box((110, 30, 290, 70), "u_dft_rst_sync_dtr_dont_touch", fill="cell", sub_rows=["dft_rst_sync"])
    f.box((110, 90, 290, 130), "u_dft_sync2_sts_dont_touch", fill="cell", sub_rows=["dft_sync2"])
    f.box((110, 150, 290, 190), "u_dft_icg_tdrclk_dont_touch", fill="cell", sub_rows=["dft_icg"])
    f.box((110, 210, 290, 250), "u_dft_rst_sync_wrstn_dont_touch", fill="cell", sub_rows=["dft_rst_sync"])
    f.box((330, 30, 450, 70), "u_dtr", sub_rows=["shadows"])
    f.box((330, 90, 450, 130), "u_sts", sub_rows=["dft_dtr_reg"])
    f.box((330, 150, 450, 190), "u_tap", sub_rows=["both TCK1 edges"])
    f.box((330, 210, 450, 250), "lpddr_wrstn", fill="pad", sub_rows=["to the PHY"])
    _hwire(f, 80, 110, 50, "i1")
    _hwire(f, 80, 110, 110, "i2")
    _hwire(f, 80, 110, 170, "i3")
    _hwire(f, 80, 110, 230, "i4")
    _hwire(f, 290, 330, 50, "rst_dtr_n")
    _hwire(f, 290, 330, 110, "i5")
    _hwire(f, 290, 330, 170, "i6")
    _hwire(f, 290, 330, 230, "i7")
    return f


def register():
    f = Fig("view-register", 468, 230)
    f.box((6, 50, 70, 130), "u_tap", fill="ext", align="start", sub_rows=["tap_state", "ir"])
    f.box((86, 6, 380, 224), "u_cfg", fill="note", align="start", sub_rows=["dft_dtr_reg, DTR_CFG"])
    f.box((100, 50, 200, 110), "sr_q", fill="reg", sub_rows=["32 bits", "rising TCK1"])
    f.box((250, 50, 366, 110), "shadow_q", fill="reg", sub_rows=["32 bits", "falling TCK1"])
    f.box((100, 140, 200, 200), "update_en", fill="logic", sub_rows=["Update-DR", "and not tm"])
    f.box((250, 140, 366, 200), "clr_i", fill="logic", sub_rows=["CLR bit 31", "load_rst"])
    f.box((396, 50, 462, 110), "dtr_cfg", fill="pad", sub_rows=["to decode"])
    f.box((396, 140, 462, 200), "rst_dtr_n", fill="pad", sub_rows=["PwrOk"])
    _hwire(f, 70, 100, 80, "i1")
    _hwire(f, 200, 250, 80, "i2")
    f.wire([(150, 140), (150, 110)], label="i3", at=(154, 128, "start"))
    f.wire([(308, 140), (308, 110)], label="i4", at=(312, 128, "start"))
    _hwire(f, 366, 396, 80, "i5")
    f.wire([(396, 170), (366, 170)], label="i6", at=(381, 167, "middle"))
    return f
