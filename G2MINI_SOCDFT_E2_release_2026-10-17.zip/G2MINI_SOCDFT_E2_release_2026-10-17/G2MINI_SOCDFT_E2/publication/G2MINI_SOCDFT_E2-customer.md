# SOC_DFT chip-top DFT controller: microarchitecture

This document is generated from the design and verification records of SOC_DFT chip-top DFT controller: microarchitecture; the fully cited engineering edition is available on request. Values marked CONF-nn are the specification's baseline values awaiting confirmation by their owners; the design implements each baseline, and a changed value is a change at the sites this document names.

RTL digest (SHA-256 over every file under rtl/): d17e8e74a1ac1bdc1ab87f732b2fa69c2f982374b50535219bbd685313560f12

Publication record (SHA-256 of declarations/publication-records.json): fda24d6608fe0eb0d9b568bcef2584b00c04c0d6795429029fa7aa3a68a5b6c2; stage DV

## 1. Overview

soc_dft is the top of a design of 17 modules (soc_dft, dft_pad_if, dft_jtag1_rtr, dft_tap, dft_dtr, dft_mode_dec, dft_crg_ctl, dft_ddr_tdr, dft_sms_srv, dft_scan_rtr, dft_scan_hold, dft_icg, dft_mux2, dft_rst_sync, dft_sync2, dft_dtr_reg, dft_dtr_sts), with a boundary of 174 ports. This document follows the order an integrator reads in: configuration, interface, clocks and resets, the datapath with one transaction walked cycle by cycle, the modules, the state machines, the registers, error behaviour, the integration contract, the verification status, the limitations, the software flow and a glossary.

![SOC_DFT top-level overview](figures/view-overview.png)
**Figure 1-1.** SOC_DFT top level: the delivered instances and the eight boundary groups.

![soc_dft instance hierarchy](figures/top-diagram.png)
**Figure 1-2.** soc_dft hierarchy: the delivered instances and, dashed, the boundary of the withdrawn partial build (P_PARTITIONED = 0, refused at elaboration).

SOC_DFT is the chip-top DFT controller of the G2mini SoC. It turns the tester's 50 DFT and JTAG1 pins into the static test configuration of the DFT blocks, the TOP glue, the LPDDR subsystem and the chip clock and reset generator, routes one JTAG port to four TAP targets, and holds the JTAG-programmed configuration in three test data registers. This document describes revision 0.3, reissued for revision 0.92 of the specification: the full build, with the partition decode and the scan router that connect the 20 scan pin pairs to the block channels of each test mode; the SMS shell carries an IEEE 1149.1 TAP with the IDCODE and BYPASS registers until the generated SMS TAP and Server are inserted. The PART value of each test mode is provisional until the DFT team assigns the codes.

## 2. Configuration

soc_dft is configured at build time by 12 parameters (P_IDCODE, P_OE_GATED, P_TM_OPEN, P_DFTSO_HIZ_M0, P_CFG_RST, P_LPDDR_RST, P_RTL_REV, P_TDR_EN_EDGE, P_DFTMAX_COMP, P_SMS_IR_LEN, P_SMS_IDCODE, P_PARTITIONED); each row below gives its type, its default, the values it may legally take and what a change does.

**Table 2-1.** Configuration

| Parameter | Type | Default | Legal range | Effect |
|---|---|---|---|---|
| P_IDCODE | logic [31:0] | 32'h0000_0001 | any value with bit 0 = 1 | IDCODE of the SOC_DFT TAP; the chip top sets the assigned value |
| P_OE_GATED | bit | 1 | 0, 1 | 1 gates each target's TDO enable with its select; 0 ORs the four enables |
| P_TM_OPEN | bit | 1 | 0, 1 | 1 lets TMS1 reach the ARC and PCIe TAPs while DFTTM = 1 |
| P_DFTSO_HIZ_M0 | bit | 1 | 0, 1 | 1 leaves DFTSO in high impedance in mission mode; 0 drives it 0 |
| P_CFG_RST | logic [31:0] | 32'h003F_FFA5 | bits 22:0 meaningful | DTR_CFG value after power-good |
| P_LPDDR_RST | logic [31:0] | 32'h0000_0000 | bits 17:0 meaningful | DTR_LPDDR value after power-good |
| P_RTL_REV | logic [7:0] | 8'h05 | any | revision value read in DTR_STS |
| P_TDR_EN_EDGE | bit | 1 | 0, 1 | TCK1 edge that launches the LPDDR PHY TDR enables: 1 falling, 0 rising |
| P_DFTMAX_COMP | bit | 1 | 0, 1 | DFTMAX value that selects compressed scan |
| P_SMS_IR_LEN | int | 4 | 2 to 8 | instruction length of the SMS TAP in this release |
| P_SMS_IDCODE | logic [31:0] | 32'h0001_0001 | bit 0 = 1, different from P_IDCODE | IDCODE of the SMS TAP in this release |
| P_PARTITIONED | bit | 1 | 1 | 1 builds the partition decode and the scan router; 0, the partial build of Section 11.3, is refused at elaboration |

## 3. Interface

The boundary of soc_dft is 174 ports: 52 in, 122 out, in 8 groups: pad (11), clock and reset (4), jtag targets (9), blocks (99), top glue (3), sms (18), lpddr (22), crg (8). Each row gives a port's direction, width, the clock it is timed by, its value in reset and what it carries.

The boundary has eight groups (Figure 1-1): the scan and power pads, the JTAG1 pads, the external JTAG targets, the block test controls, the clock and reset generator controls, the LPDDR PHY TDR port, the scan channels and the SMS processor ports. Every port has the name, direction and width of Appendix B of the specification. In each test mode the scan router connects the 20 scan pin pairs to the channels of the selected blocks, the wrapper chains or the TOP chains; unmapped pins drive 0. The SMS port membership and bit order may change with confirmations CONF-33 and CONF-17.

**Table 3-1.** Ports

| Port | Direction | Width | Clock | Reset value | Group | Meaning |
|---|---|---|---|---|---|---|
| DFTTM | input | 1 | static | -- | pad | tester pin DFTTM through its pad; scan test enable |
| DFTMAX | input | 1 | static | -- | pad | tester pin DFTMAX; compression select |
| DFTSE | input | 1 | test clock | -- | pad | tester pin DFTSE; global scan shift enable |
| DFTSI | input | UNDERIVED | test clock | -- | pad | tester pins DFTSI[19:0]; scan channel inputs |
| DFTSO | output | UNDERIVED | test clock | UNDERIVED | pad | dft_pad_if from dftso_o, the router's scan-out lanes (loopback, EXTEST or the selected INTEST mode; 0 when unmapped or tm = 0) |
| DFTSO_OE | output | 1 | static | UNDERIVED | pad | dft_pad_if: P_DFTSO_HIZ_M0 ? tm: 1, one net to all 20 DFTSO pads |
| TSEL1 | input | 2 | static | -- | pad | tester pins {TSEL1_1, TSEL1_0}; JTAG1 target select |
| TCK1 | input | 1 | - | -- | clock and reset | TCK1 pad (CTS net); JTAG1 clock |
| TMS1 | input | 1 | TCK1 | -- | pad | TMS1 pad; JTAG mode select |
| TDI1 | input | 1 | TCK1 | -- | pad | TDI1 pad; JTAG data in |
| TRSTN1 | input | 1 | async | -- | clock and reset | TRSTN1 pad; asynchronous active-low TAP reset |
| TDO1 | output | 1 | TCK1 falling | UNDERIVED | pad | dft_jtag1_rtr: TDO of the selected target |
| TDO1_OE | output | 1 | TCK1 falling | UNDERIVED | pad | dft_jtag1_rtr: output enable of the TDO1 pad |
| PwrOk | input | 1 | async | -- | clock and reset | PwrOk pad; power-good, DTR shadow reset source |
| Rstn | input | 1 | async | -- | clock and reset | Rstn pad; chip reset, source of Rst_n_test |
| arc_tms1 | output | 1 | TCK1 | UNDERIVED | jtag targets | dft_jtag1_rtr: gated TMS of the arc target |
| pcia_tms1 | output | 1 | TCK1 | UNDERIVED | jtag targets | dft_jtag1_rtr: gated TMS of the pcia target |
| pcib_tms1 | output | 1 | TCK1 | UNDERIVED | jtag targets | dft_jtag1_rtr: gated TMS of the pcib target |
| arc_tdo1 | input | 1 | TCK1 falling | -- | jtag targets | arc TAP TDO |
| arc_tdo1_oe | input | 1 | TCK1 falling | -- | jtag targets | arc TAP TDO enable |
| pcia_tdo1 | input | 1 | TCK1 falling | -- | jtag targets | pcia TAP TDO |
| pcia_tdo1_oe | input | 1 | TCK1 falling | -- | jtag targets | pcia TAP TDO enable |
| pcib_tdo1 | input | 1 | TCK1 falling | -- | jtag targets | pcib TAP TDO |
| pcib_tdo1_oe | input | 1 | TCK1 falling | -- | jtag targets | pcib TAP TDO enable |
| scc_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| scc_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| scc_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| scc_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| scc_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) |
| scc_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[0 + j] (mode 2, PART 3) |
| scc_test_so | input | UNDERIVED | test clock | -- | blocks | block scc scan channel outputs |
| scc_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) |
| scc_wrap_so | input | UNDERIVED | test clock | -- | blocks | block scc wrapper chain outputs |
| hic_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| hic_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| hic_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| hic_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| hic_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) |
| hic_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[0 + j] (mode 3, PART 4) |
| hic_test_so | input | UNDERIVED | test clock | -- | blocks | block hic scan channel outputs |
| hic_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) |
| hic_wrap_so | input | UNDERIVED | test clock | -- | blocks | block hic wrapper chain outputs |
| g2muc_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| g2muc_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| g2muc_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| g2muc_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| g2muc_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) |
| g2muc_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[5 + j] (mode 2, PART 3) |
| g2muc_test_so | input | UNDERIVED | test clock | -- | blocks | block g2muc scan channel outputs |
| g2muc_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) |
| g2muc_wrap_so | input | UNDERIVED | test clock | -- | blocks | block g2muc wrapper chain outputs |
| l4ga_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| l4ga_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| l4ga_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| l4ga_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| l4ga_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) |
| l4ga_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[5 + j] (mode 3, PART 4) |
| l4ga_test_so | input | UNDERIVED | test clock | -- | blocks | block l4ga scan channel outputs |
| l4ga_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) |
| l4ga_wrap_so | input | UNDERIVED | test clock | -- | blocks | block l4ga wrapper chain outputs |
| l4gb_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| l4gb_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| l4gb_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| l4gb_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| l4gb_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) |
| l4gb_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[8 + j] (mode 3, PART 4) |
| l4gb_test_so | input | UNDERIVED | test clock | -- | blocks | block l4gb scan channel outputs |
| l4gb_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) |
| l4gb_wrap_so | input | UNDERIVED | test clock | -- | blocks | block l4gb wrapper chain outputs |
| pcia_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| pcia_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| pcia_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| pcia_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| pcia_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) |
| pcia_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[0 + j] (mode 0, PART 1) |
| pcia_test_so | input | UNDERIVED | test clock | -- | blocks | block pcia scan channel outputs |
| pcia_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) |
| pcia_wrap_so | input | UNDERIVED | test clock | -- | blocks | block pcia wrapper chain outputs |
| pcib_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| pcib_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| pcib_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| pcib_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| pcib_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) |
| pcib_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[0 + j] (mode 1, PART 2) |
| pcib_test_so | input | UNDERIVED | test clock | -- | blocks | block pcib scan channel outputs |
| pcib_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) |
| pcib_wrap_so | input | UNDERIVED | test clock | -- | blocks | block pcib wrapper chain outputs |
| ahb_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| ahb_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| ahb_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| ahb_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| ahb_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) |
| ahb_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[11 + j] (mode 2, PART 3) |
| ahb_test_so | input | UNDERIVED | test clock | -- | blocks | block ahb scan channel outputs |
| ahb_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) |
| ahb_wrap_so | input | UNDERIVED | test clock | -- | blocks | block ahb wrapper chain outputs |
| apb_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| apb_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| apb_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| apb_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| apb_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) |
| apb_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[11 + j] (mode 3, PART 4) |
| apb_test_so | input | UNDERIVED | test clock | -- | blocks | block apb scan channel outputs |
| apb_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) |
| apb_wrap_so | input | UNDERIVED | test clock | -- | blocks | block apb wrapper chain outputs |
| axis_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| axis_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| axis_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| axis_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| axis_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) |
| axis_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[17 + j] (mode 2, PART 3) |
| axis_test_so | input | UNDERIVED | test clock | -- | blocks | block axis scan channel outputs |
| axis_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) |
| axis_wrap_so | input | UNDERIVED | test clock | -- | blocks | block axis wrapper chain outputs |
| axim_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| axim_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| axim_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) |
| axim_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm |
| axim_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) |
| axim_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[15 + j] (mode 3, PART 4) |
| axim_test_so | input | UNDERIVED | test clock | -- | blocks | block axim scan channel outputs |
| axim_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) |
| axim_wrap_so | input | UNDERIVED | test clock | -- | blocks | block axim wrapper chain outputs |
| top_scan_shift_en | output | 1 | test clock | UNDERIVED | top glue | dft_mode_dec: tm & dftse_i & extest |
| top_test_si | output | UNDERIVED | test clock | UNDERIVED | top glue | dft_scan_rtr: extest & DFTSI[11 + t] |
| top_test_so | input | UNDERIVED | test clock | -- | top glue | TOP chain scan outputs |
| scc_sms_in | output | 5 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise |
| hic_sms_in | output | 5 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise |
| g2muc_sms_in | output | 5 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise |
| l4ga_sms_in | output | 5 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise |
| l4gb_sms_in | output | 5 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise |
| ahb_sms_in | output | 5 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise |
| lpddr_sms_in | output | 5 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise |
| pcia_sms_in | output | 10 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise |
| pcib_sms_in | output | 10 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise |
| scc_sms_out | input | 1 | TCK1 | -- | sms | SMS processor WSO of scc |
| hic_sms_out | input | 1 | TCK1 | -- | sms | SMS processor WSO of hic |
| g2muc_sms_out | input | 1 | TCK1 | -- | sms | SMS processor WSO of g2muc |
| l4ga_sms_out | input | 1 | TCK1 | -- | sms | SMS processor WSO of l4ga |
| l4gb_sms_out | input | 1 | TCK1 | -- | sms | SMS processor WSO of l4gb |
| ahb_sms_out | input | 1 | TCK1 | -- | sms | SMS processor WSO of ahb |
| lpddr_sms_out | input | 1 | TCK1 | -- | sms | SMS processor WSO of lpddr |
| pcia_sms_out | input | 2 | TCK1 | -- | sms | SMS processor WSO of pcia (two ports) |
| pcib_sms_out | input | 2 | TCK1 | -- | sms | SMS processor WSO of pcib (two ports) |
| lpddr_atpg_mode | output | 1 | static | UNDERIVED | lpddr | dft_mode_dec: DTR_LPDDR override, else tm & active[11] (0: LPDDR is in no mode) |
| lpddr_compression_mode | output | 1 | static | UNDERIVED | lpddr | dft_mode_dec: DTR_LPDDR override, else tm & dftmax_i & sel[11] (0: LPDDR is in no mode) |
| lpddr_phy0_burnin | output | 1 | static | UNDERIVED | lpddr | dft_mode_dec: tm & BURNIN & PHY0_BURNIN |
| lpddr_phy1_burnin | output | 1 | static | UNDERIVED | lpddr | dft_mode_dec: tm & BURNIN & PHY1_BURNIN |
| lpddr_atpg_se | output | 16 | static | UNDERIVED | lpddr | dft_mode_dec: {16{tm & dftse_i & active[11]}} (0: LPDDR is in no mode) |
| lpddr_scan_ctl | output | 2 | static | UNDERIVED | lpddr | dft_mode_dec: tied 2'b00 (CONF-19) |
| lpddr_scan_shift_cg | output | 1 | static | UNDERIVED | lpddr | dft_mode_dec: SCAN_SHIFT_CG_OVR \| (tm & dftse_i & active[11]) |
| lpddr_scan_rstn | output | 1 | static | UNDERIVED | lpddr | dft_crg_ctl: tm ? Rst_n_test: 1 |
| lpddr_sms_dm | output | 3 | static | UNDERIVED | lpddr | dft_dtr: DTR_LPDDR.SMS_DM |
| lpddr_ring_bypass | output | 7 | static | UNDERIVED | lpddr | dft_dtr: DTR_LPDDR.RING_BYPASS |
| lpddr_sfp_dft_mode | output | 1 | static | UNDERIVED | lpddr | dft_dtr: DTR_LPDDR.SFP_DFT_MODE |
| lpddr_tdrclk | output | 1 | - | UNDERIVED | lpddr | dft_ddr_tdr: TCK1 gated by ddr_tdr_en |
| lpddr_wrstn | output | 1 | static | UNDERIVED | lpddr | dft_ddr_tdr: TRSTN1 & ddr_tdr_en, released on TDRCLK |
| lpddr_cmd_tdr_capture_en | output | 2 | TCK1 falling | UNDERIVED | lpddr | dft_ddr_tdr: TDR enable, {phy1, phy0} |
| lpddr_cmd_tdr_shift_en | output | 2 | TCK1 falling | UNDERIVED | lpddr | dft_ddr_tdr: TDR enable, {phy1, phy0} |
| lpddr_cmd_tdr_update_en | output | 2 | TCK1 falling | UNDERIVED | lpddr | dft_ddr_tdr: TDR enable, {phy1, phy0} |
| lpddr_rd_tdr_capture_en | output | 2 | TCK1 falling | UNDERIVED | lpddr | dft_ddr_tdr: TDR enable, {phy1, phy0} |
| lpddr_rd_tdr_shift_en | output | 2 | TCK1 falling | UNDERIVED | lpddr | dft_ddr_tdr: TDR enable, {phy1, phy0} |
| lpddr_rd_tdr_update_en | output | 2 | TCK1 falling | UNDERIVED | lpddr | dft_ddr_tdr: TDR enable, {phy1, phy0} |
| lpddr_wsi | output | 2 | TCK1 | UNDERIVED | lpddr | dft_ddr_tdr: tap_tdi to the selected PHY TDR |
| lpddr_cmd_tdr_tdo | input | 2 | TDRCLK | -- | lpddr | PHY CsrCmd TDR TDO, {phy1, phy0} |
| lpddr_rd_tdr_tdo | input | 2 | TDRCLK | -- | lpddr | PHY CsrRdData TDR TDO, {phy1, phy0} |
| dft_crg_test_clk_sel | output | 1 | static | UNDERIVED | crg | dft_crg_ctl: = tm |
| dft_crg_rst_byp | output | 1 | static | UNDERIVED | crg | dft_crg_ctl: = tm |
| dft_crg_rst_n_test | output | 1 | static | UNDERIVED | crg | dft_crg_ctl: Rst_n_test |
| dft_crg_pll_byp | output | 3 | static | UNDERIVED | crg | dft_crg_ctl: (tm & PLL_BYP) ? 111: 000 |
| dft_crg_blk_clk_en | output | 13 | static | UNDERIVED | crg | dft_crg_ctl: ~tm \| (BLK_CLK_EN & active) |
| dft_crg_comp_clk_en | output | 13 | static | UNDERIVED | crg | dft_crg_ctl: tm & dftmax_i & sel & BLK_CLK_EN |
| dft_crg_lpddr_clk_en | output | 5 | static | UNDERIVED | crg | dft_crg_ctl: tm & active[11] & BLK_CLK_EN[11] |
| crg_pll_ready | input | 3 | async | -- | crg | chip PLLs {DfiClk, Gclk, Uclk} ready |

## 4. Clocks, resets and crossings

soc_dft is clocked by 2 clocks (TCK1, clk_i) and reset by 2 resets (TRSTN1, rst_ni); the tables give each one's source, edge and coverage, and the crossings between them follow with how each is made safe.

**Table 4-1.** Clocks

| Clock | Source | Edge | Frequency | Drives |
|---|---|---|---|---|
| TCK1 | TCK1 pad (CTS net), integrator | rising and falling | 20 MHz maximum; 10 MHz with a DDRx instruction | dft_tap, dft_ddr_tdr |
| clk_i | module clock port of the cells and the DTR engines; bound to TCK1 (u_cfg, u_lpddr, u_sts, u_dft_sync2_sts_dont_touch, u_dft_rst_sync_dtr_dont_touch) or to lpddr_tdrclk (u_dft_rst_sync_wrstn_dont_touch); for u_dft_icg_tdrclk_dont_touch it is the gated input TCK1 | rising (dft_dtr_reg shadow: falling) | that of the clock it is bound to | dft_rst_sync, dft_sync2, dft_dtr_reg, dft_dtr_sts |

**Table 4-2.** Resets

| Reset | Polarity | Synchronicity | Coverage | Synchronizer |
|---|---|---|---|---|
| TRSTN1 | active low | asynchronous assert and de-assert | dft_tap FSM, IR, BYPASS, TDO retime (both instances); dft_ddr_tdr enables; WRSTN source | none (IEEE 1149.1 TRST) |
| rst_ni | active low | asynchronous assert | module reset port of dft_dtr_reg (bound to rst_dtr_n) and of dft_rst_sync (bound to PwrOk, or to TRSTN1 & ddr_tdr_en for WRSTN) | dft_rst_sync releases its output synchronously; dft_dtr_reg receives an already released reset |

![clocks, resets and crossings](figures/view-clock-reset.png)
**Figure 4-1.** Clocks, resets and crossings: every crossing passes one synchroniser or gating cell.

PwrOk enters the TCK1 domain through a reset synchroniser: the internal DTR reset asserts as soon as PwrOk falls and releases on the second rising TCK1 after PwrOk rises.

The eight status inputs read in DTR_STS (DFTTM, the compression select, TSEL1[1:0], the three PLL-ready inputs and PwrOk) each pass a two-flop synchroniser clocked by TCK1.

The LPDDR WRSTN output is TRSTN1 & DDR_TDR_EN, asserted asynchronously and released through two flops clocked by TDRCLK.

DFTTM reaches the TCK1 logic without a synchroniser because it changes only while Rstn = 0 and while the TAP chain is in Test-Logic-Reset or Run-Test/Idle.

## 5. Datapath

The design holds 12 registers and 0 memories across its 17 modules; section 5.1 follows one transaction through them in 7 steps.

![JTAG serial path](figures/view-serial.png)
**Figure 5-1.** The TSEL1 = 11 chain: TDI1 through the SMS TAP and the SOC_DFT TAP to TDO1.

![scan channel routing](figures/view-scan.png)
**Figure 5-2.** Scan channel routing: DFTSI through the gated fan-out to the block channels, and the block scan-outs back through the per-lane mode, EXTEST and loopback selections to DFTSO.

SOC_DFT has two data paths. The scan channels are combinational: in a test mode each selected block's channel takes its DFTSI pin and returns on the same pin; in EXTEST each block's two wrapper chains run in series on one pin and the TOP chains on pins 11 to 13; in loopback each DFTSO follows its DFTSI; nothing is clocked on the way. The other is the serial JTAG scan. With TSEL1 = 11 the JTAG1 port sees two devices: TDI1 enters the SMS TAP, whose TDO is the serial input of every SOC_DFT data register, and the SOC_DFT TAP drives TDO1 through the JTAG1 router. Data rests in the shift stages between Capture-DR and Update-DR and in the register shadows after Update-DR. The storage table below lists every element with its value after reset.

**Table 5-1.** Storage

| Module | Element | Kind | Width | Value after reset | Holds |
|---|---|---|---|---|---|
| dft_tap | state_q | register | 4 | - | TAP state |
| dft_tap | ir_sr_q | register | P_IR_LEN | - | IR shift stage |
| dft_tap | ir_q | register | P_IR_LEN | - | IR update stage |
| dft_tap | idcode_sr_q | register | 32 | - | IDCODE shift register |
| dft_tap | byp_q | register | 1 | 1'b0 | BYPASS |
| dft_tap | tdo_q | register | 1 | 1'b0 | sms_tdo1 retime |
| dft_tap | tdo_oe_q | register | 1 | 1'b0 | sms_tdo1_oe retime |
| dft_ddr_tdr | en_q | register | 12 | 12'h000 | TDR capture/shift/update enables |
| dft_rst_sync | sync_q | register | 2 | 2'b00 | reset release pipeline |
| dft_sync2 | meta_q | register | P_WIDTH | - | first synchroniser stage |
| dft_sync2 | sync_q | register | 2 | - | reset release pipeline |
| dft_dtr_reg | sr_q | register | P_WIDTH | - | DR shift stage |
| dft_dtr_reg | shadow_q | register | P_WIDTH | - | DR shadow (configuration) |
| dft_dtr_sts | sr_q | register | P_WIDTH | - | DR shift stage |

### 5.1 One transaction, cycle by cycle

![one DR scan of DTR_CFG](figures/wave-dtr-update.png)
**Figure 5-3.** One DR scan of DTR_CFG: the configuration changes on the falling TCK1 of Update-DR, and only while DFTTM = 0.

The walk below writes DTR_CFG with the sequence of Section 9.8 of the specification, starting with the instruction register holding DTR_CFG in the SOC_DFT TAP and BYPASS in the SMS TAP. Each step is one rising TCK1 edge.

**Table 5-2.** Walk

| Step | Inputs sampled | State before | Registers written | Outputs after |
|---|---|---|---|---|
| 1 | TMS = 1 | RUN_TEST_IDLE | TAP state | state SELECT_DR_SCAN; TDO1 not enabled |
| 2 | TMS = 0 | SELECT_DR_SCAN | TAP state | state CAPTURE_DR |
| 3 | TMS = 0 | CAPTURE_DR | DTR_CFG shift stage loads the current configuration | state SHIFT_DR |
| 4 | TMS = 0, TDI bit 0 | SHIFT_DR | shift stage shifts toward TDO | TDO1 carries the old bit 0 |
| 5 | TMS = 1, TDI bit 31 | SHIFT_DR | shift stage holds the 32 new bits | state EXIT1_DR |
| 6 | TMS = 1 | EXIT1_DR | TAP state | state UPDATE_DR |
| 7 | TMS = 0, DFTTM = 0 | UPDATE_DR | DTR_CFG configuration loads on falling TCK1 | every control derived from DTR_CFG changes |

## 6. Modules

soc_dft is built from 17 modules: soc_dft, dft_pad_if, dft_jtag1_rtr, dft_tap, dft_dtr, dft_mode_dec, dft_crg_ctl, dft_ddr_tdr, dft_sms_srv, dft_scan_rtr and 7 more. The interconnect between them comes first, then for each module what it consumes, what it holds and its role, its parameters, its derived constants and where each mechanism is implemented.

Figure 6-1 draws configuration and control path.

![configuration and control path](figures/view-control.png)
**Figure 6-1.** Configuration and control path: pins and DTR shadows to the block and CRG controls

**Table 6-1.** Modules

| Module | Consumes | Holds | Role |
|---|---|---|---|
| soc_dft | dft_part_map_pkg, the parameters of Appendix B | no state | top: instances of Table 21; the router (g_scan_rtr, P_PARTITIONED = 1); the g_scan_hold branch with dft_scan_hold is unreachable, P_PARTITIONED = 0 being refused at elaboration (CONF-38 closed); per-block slices of the router's flat channel buses |
| dft_pad_if | P_DFTSO_HIZ_M0, P_DFTMAX_COMP | no state | pad buffers, DFTSO_OE, dftmax_i, rst_dtr_n |
| dft_jtag1_rtr | P_OE_GATED, P_TM_OPEN | no state | TSEL1 decode, TMS gating, TDO1 mux |
| dft_tap | P_IR_LEN, P_DR_CLIENTS, P_IDCODE | state_q, ir_sr_q, ir_q, idcode_sr_q, byp_q, tdo_q, tdo_oe_q | IEEE 1149.1 TAP (also the SMS stub under dft_sms_srv) |
| dft_dtr | P_CFG_RST, P_LPDDR_RST, P_RTL_REV, NPART | no state | DTR_CFG, DTR_LPDDR, DTR_STS host |
| dft_mode_dec | P_PARTITIONED, PART_MAP_SEL, P0_MEMBER, ENC_*, NBLK, NSBLK, TMW | no state | test-mode decode of 11.3: partition decode (P_PARTITIONED = 1); P_PARTITIONED = 0 is refused at elaboration (CONF-38 closed) |
| dft_crg_ctl | dtr_cfg, sel, active | no state | CRG selects and enables, Rst_n_test |
| dft_ddr_tdr | P_TDR_EN_EDGE | en_q | LPDDR PHY TDR bridge |
| dft_sms_srv | P_SMS_IR_LEN, P_SMS_IDCODE | no state | SMS shell with the dft_tap stub u_stub |
| dft_scan_rtr | NPIN, NSBLK, NMODE, NCH, OFF, PIN_BASE, SO_VALID, SO_BLK, SO_CH, PART_MODE0, NWRAP, NTOP | no state | scan router of 12.1/12.3: gated scan-in fan-out; per lane a 4:1 over the INTEST modes, a 2:1 to the wrapper/TOP path under extest and a 2:1 for loopback, all dft_mux2 cells |
| dft_scan_hold | - | no state | withdrawn partial-build boundary: instantiated only under P_PARTITIONED = 0, which dft_mode_dec refuses at elaboration (CONF-38 closed); unreachable in every legal configuration |
| dft_icg | - | no state | clock-gate cell (TDRCLK) |
| dft_mux2 | - | no state | 2:1 mux cell: every test-control mux (router levels 1, 2 and loopback; Rst_n_test, lpddr_scan_rstn) |
| dft_rst_sync | - | sync_q | async-assert, sync-de-assert reset synchroniser cell (rst_dtr_n, lpddr_wrstn) |
| dft_sync2 | P_WIDTH | meta_q, sync_q | 2-flop synchroniser cell (DTR_STS inputs) |
| dft_dtr_reg | P_WIDTH, P_RESET, P_WMASK | sr_q, shadow_q | JTAG configuration data-register engine (u_cfg, u_lpddr) |
| dft_dtr_sts | P_WIDTH | sr_q | DTR_STS capture-only status register |

**Table 6-2.** Module parameters

| Module | Parameter | Default | Use |
|---|---|---|---|
| soc_dft | P_IDCODE | 1 | IDCODE value |
| soc_dft | P_OE_GATED | 1 | TDO1_OE gated per target |
| soc_dft | P_TM_OPEN | 1 | external-target TMS opened when DFTTM = 1 |
| soc_dft | P_DFTSO_HIZ_M0 | 1 | DFTSO_OE follows DFTTM |
| soc_dft | P_CFG_RST | 4194213 | DTR_CFG shadow reset value |
| soc_dft | P_LPDDR_RST | 0 | DTR_LPDDR shadow reset value |
| soc_dft | P_RTL_REV | 5 | DTR_STS.RTL_REV |
| soc_dft | P_TDR_EN_EDGE | 1 | TDR enable launch edge |
| soc_dft | P_DFTMAX_COMP | 1 | DFTMAX value that selects compression |
| soc_dft | P_SMS_IR_LEN | 4 | IR length of the SMS TAP stub |
| soc_dft | P_SMS_IDCODE | 65537 | IDCODE of the SMS TAP stub |
| soc_dft | P_PARTITIONED | 1 | 1 selects the full build (partition decode and dft_scan_rtr), the only legal value; 0, the partial build of 11.3, is withdrawn and refused at elaboration (CONF-38 closed) |
| dft_pad_if | P_DFTSO_HIZ_M0 | 1 | DFTSO_OE follows DFTTM |
| dft_pad_if | P_DFTMAX_COMP | 1 | DFTMAX value that selects compression |
| dft_jtag1_rtr | P_OE_GATED | 1 | TDO1_OE gated per target |
| dft_jtag1_rtr | P_TM_OPEN | 1 | external-target TMS opened when DFTTM = 1 |
| dft_tap | P_IR_LEN | 5 | IR length |
| dft_tap | P_DR_CLIENTS | 1 | 1 = DTR and DDRx codes decoded |
| dft_tap | P_IDCODE | 1 | IDCODE value |
| dft_dtr | P_CFG_RST | 4194213 | DTR_CFG shadow reset value |
| dft_dtr | P_LPDDR_RST | 0 | DTR_LPDDR shadow reset value |
| dft_dtr | P_RTL_REV | 5 | DTR_STS.RTL_REV |
| dft_mode_dec | P_PARTITIONED | 1 | 1 selects the full build (partition decode and dft_scan_rtr), the only legal value; 0, the partial build of 11.3, is withdrawn and refused at elaboration (CONF-38 closed) |
| dft_ddr_tdr | P_TDR_EN_EDGE | 1 | TDR enable launch edge |
| dft_sms_srv | P_SMS_IR_LEN | 4 | IR length of the SMS TAP stub |
| dft_sms_srv | P_SMS_IDCODE | 65537 | IDCODE of the SMS TAP stub |
| dft_sync2 | P_WIDTH | 1 | register length |
| dft_dtr_reg | P_WIDTH | 32 | register length |
| dft_dtr_reg | P_RESET | 0 | shadow reset value |
| dft_dtr_reg | P_WMASK | 4294967295 | writable bits; 0 = reserved, reads 0 |
| dft_dtr_sts | P_WIDTH | 32 | register length |

**Table 6-3.** Derived constants

| Module | Constant | Definition | Value at defaults |
|---|---|---|---|
| dft_tap | IR_IDCODE | - | - |
| dft_tap | IR_DTR_CFG | - | - |
| dft_tap | IR_DTR_LPDDR | - | - |
| dft_tap | IR_DTR_STS | - | - |
| dft_tap | IR_DDR0_CMD | - | - |
| dft_tap | IR_DDR1_RD | - | - |
| dft_dtr | IR_DTR_CFG | - | - |
| dft_dtr | IR_DTR_LPDDR | - | - |
| dft_dtr | IR_DTR_STS | - | - |
| dft_dtr | CFG_WMASK | 32'h007F_FFFF | 8388607 |
| dft_dtr | LPDDR_WMASK | 32'h0003_FFFF | 262143 |
| dft_mode_dec | NBLK | dft_part_map_pkg::NBLK | - |
| dft_mode_dec | NSBLK | dft_part_map_pkg::NSBLK | - |
| dft_mode_dec | TMW | dft_part_map_pkg::TMW | - |
| dft_mode_dec | B_LPDDR | dft_part_map_pkg::B_LPDDR | - |
| dft_mode_dec | CFG_BURNIN | 4 | 4 |
| dft_mode_dec | CFG_SE_GATE | 21 | 21 |
| dft_mode_dec | LP_ATPG_MODE_OVR | 0 | 0 |
| dft_mode_dec | LP_ATPG_MODE_VAL | 1 | 1 |
| dft_mode_dec | LP_COMP_OVR | 2 | 2 |
| dft_mode_dec | LP_COMP_VAL | 3 | 3 |
| dft_mode_dec | LP_PHY0_BURNIN | 4 | 4 |
| dft_mode_dec | LP_PHY1_BURNIN | 5 | 5 |
| dft_mode_dec | LP_SCAN_SHIFT_CG | 17 | 17 |
| dft_crg_ctl | CFG_PLL_BYP | 5 | 5 |
| dft_crg_ctl | CFG_RST_OVR | 6 | 6 |
| dft_crg_ctl | CFG_RST_VAL | 7 | 7 |
| dft_crg_ctl | CFG_BLK_CLK_EN | 8 | 8 |
| dft_ddr_tdr | IR_DDR0_CMD | - | - |
| dft_ddr_tdr | IR_DDR0_RD | - | - |
| dft_ddr_tdr | IR_DDR1_CMD | - | - |
| dft_ddr_tdr | IR_DDR1_RD | - | - |
| dft_ddr_tdr | ST_CAPTURE_DR | - | - |
| dft_ddr_tdr | ST_SHIFT_DR | - | - |
| dft_ddr_tdr | ST_UPDATE_DR | - | - |
| dft_scan_rtr | NBLK | dft_part_map_pkg::NBLK | - |
| dft_scan_rtr | NPIN | dft_part_map_pkg::NPIN | - |
| dft_scan_rtr | NSBLK | dft_part_map_pkg::NSBLK | - |
| dft_scan_rtr | NWRAP | dft_part_map_pkg::NWRAP | - |
| dft_scan_rtr | NTOP | dft_part_map_pkg::NTOP | - |
| dft_scan_rtr | NMODE | dft_part_map_pkg::NMODE | - |
| dft_scan_rtr | PART_MODE0 | dft_part_map_pkg::PART_MODE0 | - |
| dft_scan_hold | HELD_VALUE | 1'b0 | 0 |
| dft_icg | EN_OPEN | 1'b1 | 1 |
| dft_mux2 | SEL_B | 1'b1 | 1 |
| dft_dtr_reg | RESET_V | - | - |
| dft_dtr_reg | WMASK_V | - | - |

**Table 6-4.** Method notes

| Module | Mechanism | Implemented at |
|---|---|---|
| dft_tap | next state of Table 45 on TMS | rtl/dft_tap.sv:83 |
| dft_tap | Capture-IR: 1; Shift-IR: {tdi, ir_sr_q[P_IR_LEN-1:1]} | rtl/dft_tap.sv:91 |
| dft_tap | Update-IR: ir_sr_q; TLR: 1 | rtl/dft_tap.sv:96 |
| dft_tap | Capture-DR with IDCODE: P_IDCODE; Shift-DR: shift | rtl/dft_tap.sv:125 |
| dft_tap | Capture-DR: 0; Shift-DR: tdi | rtl/dft_tap.sv:130 |
| dft_tap | Shift-IR: ir_sr_q[0]; Shift-DR: dr_tdo; else hold | rtl/dft_tap.sv:145 |
| dft_tap | (Shift-IR or Shift-DR) | rtl/dft_tap.sv:146 |
| dft_ddr_tdr | decoded from tap_state and ir, & ~tm, on the P_TDR_EN_EDGE edge | rtl/dft_ddr_tdr.sv:63 |
| dft_rst_sync | sync_q <= {sync_q[0], 1'b1} | rtl/cells/dft_rst_sync.sv:17 |
| dft_sync2 | meta_q <= d_i | rtl/cells/dft_sync2.sv:15 |
| dft_sync2 | sync_q <= {sync_q[0], 1'b1} | rtl/cells/dft_sync2.sv:16 |
| dft_dtr_reg | Capture-DR & sel: shadow; Shift-DR & sel: {tdi, sr_q[W-1:1]} | rtl/dft_dtr_reg.sv:35 |
| dft_dtr_reg | Update-DR & ~tm: clr ? reset: sel ? sr_q & P_WMASK: hold | rtl/dft_dtr_reg.sv:39 |
| dft_dtr_sts | Capture-DR & sel: shadow; Shift-DR & sel: {tdi, sr_q[W-1:1]} | rtl/dft_dtr_sts.sv:20 |

## 7. State machines

The RTL declares 1 enumerated type (tap_state_e, 16 values); this chapter states which of them are state machines, with their states, arcs and reset state.

![TAP state machine](figures/fsm-tap.png)
**Figure 7-1.** The IEEE 1149.1 TAP state machine with the state codes of the specification's Table 45.

The TAP holds one 16-state machine clocked on rising TCK1 and reset asynchronously to Test-Logic-Reset by TRSTN1; every state has one transition for TMS = 0 and one for TMS = 1, and all 16 codes of the 4-bit state are states.

The SMS TAP of this release is the same TAP with instruction length P_SMS_IR_LEN and only IDCODE and BYPASS, so the two devices of the chain always share one state.

## 8. Registers

This chapter is the register map: 6 rows in 1 table, each with its bits, reset value and access.

![DTR_CFG register](figures/view-register.png)
**Figure 8-1.** DTR_CFG: shift stage, configuration stage, update and clear.

The registers are JTAG data registers selected by the 5-bit instruction register of the SOC_DFT TAP; SOC_DFT has no memory-mapped register bus.

| IR code | Register | Length | Access and reset |
|---|---|---|---|
| 5'b00001 | IDCODE | 32 | capture P_IDCODE; selected after TRSTN1 and in Test-Logic-Reset |
| 5'b00010 | DTR_CFG | 32 | read/write; reset to P_CFG_RST by PwrOk or CLR only |
| 5'b00011 | DTR_LPDDR | 32 | read/write; reset to P_LPDDR_RST by PwrOk or CLR only |
| 5'b00100 | DTR_STS | 32 | capture only: synchronised pad and PLL status, PART, NPART, RTL_REV |
| 5'b00101 to 5'b01000 | DDR0_CMD, DDR0_RD, DDR1_CMD, DDR1_RD | set by the PHY | the LPDDR PHY TDRs |
| 5'b11111 and every other code | BYPASS | 1 | capture 0 |

DTR_CFG fields: PART [3:0] reset 5, BURNIN [4], PLL_BYP [5] reset 1, RST_OVR [6], RST_VAL [7] reset 1, BLK_CLK_EN [20:8] reset 13'h1FFF, SE_GATE [21] reset 1, DDR_TDR_EN [22], bits 30:23 reserved and read 0, CLR [31] self-clearing and read 0.

DTR_LPDDR fields: ATPG_MODE_OVR [0], ATPG_MODE_VAL [1], COMP_OVR [2], COMP_VAL [3], PHY0_BURNIN [4], PHY1_BURNIN [5], SFP_DFT_MODE [6], RING_BYPASS [13:7], SMS_DM [16:14], SCAN_SHIFT_CG_OVR [17], bits 31:18 reserved and read 0.

## 9. Error behaviour

soc_dft states 6 error conditions and the response to each; a condition with no row here has no defined response.

**Table 9-1.** Errors

| Condition | Response |
|---|---|
| An instruction code outside the decoded set is loaded | BYPASS is selected |
| DFTTM rises while the TAP chain is in a DR state | the SOC_DFT TAP is driven to Test-Logic-Reset and the register updates, CLR and the PHY TDR enables are blocked while DFTTM = 1 |
| A reserved register bit is written | the write is ignored and the bit reads 0 |
| DTR_STS is updated | nothing changes; DTR_STS is capture only |
| PART selects no test mode (5 to 14) | no block is selected: every block is parked and every scan output stays 0 |
| A DR scan longer than the register is shifted | the extra bits leave on TDO1 and Update-DR keeps the last bits shifted |

## 10. Integration contract

Integrating soc_dft means connecting its 174 ports in pad (11), clock and reset (4), jtag targets (9), blocks (99), top glue (3), sms (18), lpddr (22), crg (8), driving its clock input TCK1 and its reset input TRSTN1 from outside soc_dft (clk_i and rst_ni are internal, and nobody outside soc_dft drives them), as chapter 4 states, and meeting 9 obligations below, owned by integrator, soc_dft, tester. The order of work is the walk of section 5.1, from step 1 to step 7, which chapter 13 states as a procedure.

**Table 10-1.** Integration signals

| Signal | Class | Integrator action |
|---|---|---|
| TCK1 (clock) | external input | drive it |
| clk_i (clock) | internal | none; it never leaves the design |
| TRSTN1 (reset) | external input | drive it |
| rst_ni (reset) | internal | none; it never leaves the design |
| the other 50 input ports (chapter 3 lists each) | external input | drive it |
| the other 122 output ports (chapter 3 lists each) | generated output | connect it; never drive it |

**Table 10-2.** Integration

| Obligation | Owner |
|---|---|
| Drive TCK1 from the TCK1 pad tree; it is a clock net built by CTS, 20 MHz maximum, 10 MHz while a DDRx instruction is loaded | integrator |
| Drive TRSTN1 from the TRSTN1 pad, the same net that resets every TAP and SMS processor | integrator |
| Drive PwrOk from the PwrOk pad; it resets the test data registers | integrator |
| Drive Rstn from the Rstn pad; it is the source of dft_crg_rst_n_test | integrator |
| Do not drive rst_dtr_n: it is internal to soc_dft, produced by its reset synchroniser | soc_dft |
| Connect lpddr_tdrclk and lpddr_wrstn to the PHY TDRCLK and WRSTN inputs; both are soc_dft outputs and are never driven from outside | integrator |
| Connect every soc_dft port per Section 24 of the specification, with no logic and no tie-off at the chip top | integrator |
| Build the clock and reset test structure that the dft_crg_* outputs steer: root muxes, per-block clock gates, reset bypass | integrator |
| Change DFTTM only while Rstn = 0 and the TAP chain is in Test-Logic-Reset or Run-Test/Idle | tester |

The chip top sets P_IDCODE only; every other parameter keeps the delivered default. The TDRCLK clock gate is the instance u_soc_dft/u_ddr_tdr/u_dft_icg_tdrclk_dont_touch and the two reset muxes are u_soc_dft/u_crg_ctl/u_dft_mux2_rst_dont_touch and u_dft_mux2_scan_rstn_dont_touch, and every scan router selection is a dont_touch dft_mux2 instance under the scan router; constraints and equivalence checking address these paths.

## 11. Verification status

Simulated on 2 simulator(s), icarus, verilator: both verdicts and metrics match. This chapter states 8 verification claims: 1 row carries a verdict, 1 of them PASS, and 7 rows state a measured figure; each row gives its state as measured.

**Table 11-1.** Verification

| Claim | State |
|---|---|
| the bench, 10 test(s) | 675 checks, PASS |
| mutation | 49 killed of 50, 1 survived |
| formal | 15 proved, 0 failed, controls 6 of 6 refuted |
| coverage branch_percent | 96.1 |
| coverage expr_percent | 96.23 |
| coverage line_percent | 97.47 |
| coverage measured_by | verilator |
| coverage toggle_percent | 84.63 |

## 12. Limitations and open items

This chapter states 17 limitations and open items: what this revision does not cover and what is still open.

The mandatory feature LPDDR PHY TDR bridge is recorded MODEL_ONLY; the record cited carries the basis for that disposition.

The mandatory feature SMS shell and two-device chain is recorded EXTERNAL_DEPENDENCY; the record cited carries the basis for that disposition.

The mandatory feature Technology cells and sequential inventory is recorded MODEL_ONLY; the record cited carries the basis for that disposition.

An engineering assumption stands in for a confirmation its owner has yet to give; the register cited carries the issue it records and the value the design implements.

A timing question of the source stands at weakly_held; the register cited carries the question.

The evidence for dft:atpg_coverage stands at blocked, so what it backs is still open.

The evidence for dft:gate_level stands at blocked, so what it backs is still open.

The evidence for dft:lpddr_tdr_phy stands at blocked, so what it backs is still open.

The evidence for dft:sms_mbist stands at blocked, so what it backs is still open.

The evidence for dft:transition stands at blocked, so what it backs is still open.

The evidence for documents stands at partial, so what it backs is still open.

The evidence for dv:close stands at fail, so what it backs is still open.

The evidence for mutant:m_dec_in_range stands at fail, so what it backs is still open.

The evidence for mutation stands at fail, so what it backs is still open.

The evidence for rtl_checks stands at fail, so what it backs is still open.

The evidence for spec_checks:dv stands at not_run, so what it backs is still open.

The evidence for stage_audit:dft stands at blocked, so what it backs is still open.

## 13. Software flow

Driving soc_dft is the sequence below, 7 steps taken from the cycle walk of section 5.1: what to drive, what the design does in response, and what to read back.

1. Step 1: drive TMS = 1; from RUN_TEST_IDLE the design writes TAP state; read state SELECT_DR_SCAN; TDO1 not enabled.
2. Step 2: drive TMS = 0; from SELECT_DR_SCAN the design writes TAP state; read state CAPTURE_DR.
3. Step 3: drive TMS = 0; from CAPTURE_DR the design writes DTR_CFG shift stage loads the current configuration; read state SHIFT_DR.
4. Step 4: drive TMS = 0, TDI bit 0; from SHIFT_DR the design writes shift stage shifts toward TDO; read TDO1 carries the old bit 0.
5. Step 5: drive TMS = 1, TDI bit 31; from SHIFT_DR the design writes shift stage holds the 32 new bits; read state EXIT1_DR.
6. Step 6: drive TMS = 1; from EXIT1_DR the design writes TAP state; read state UPDATE_DR.
7. Step 7: drive TMS = 0, DFTTM = 0; from UPDATE_DR the design writes DTR_CFG configuration loads on falling TCK1; read every control derived from DTR_CFG changes.

## 14. Glossary

**Table 14-1.** Glossary

| Term | Meaning |
|---|---|
| soc_dft | top: instances of Table 21; the router (g_scan_rtr, P_PARTITIONED = 1); the g_scan_hold branch with dft_scan_hold is unreachable, P_PARTITIONED = 0 being refused at elaboration (CONF-38 closed); per-block slices of the router's flat channel buses |
| dft_pad_if | pad buffers, DFTSO_OE, dftmax_i, rst_dtr_n |
| dft_jtag1_rtr | TSEL1 decode, TMS gating, TDO1 mux |
| dft_tap | IEEE 1149.1 TAP (also the SMS stub under dft_sms_srv) |
| dft_dtr | DTR_CFG, DTR_LPDDR, DTR_STS host |
| dft_mode_dec | test-mode decode of 11.3: partition decode (P_PARTITIONED = 1); P_PARTITIONED = 0 is refused at elaboration (CONF-38 closed) |
| dft_crg_ctl | CRG selects and enables, Rst_n_test |
| dft_ddr_tdr | LPDDR PHY TDR bridge |
| dft_sms_srv | SMS shell with the dft_tap stub u_stub |
| dft_scan_rtr | scan router of 12.1/12.3: gated scan-in fan-out; per lane a 4:1 over the INTEST modes, a 2:1 to the wrapper/TOP path under extest and a 2:1 for loopback, all dft_mux2 cells |
| dft_scan_hold | withdrawn partial-build boundary: instantiated only under P_PARTITIONED = 0, which dft_mode_dec refuses at elaboration (CONF-38 closed); unreachable in every legal configuration |
| dft_icg | clock-gate cell (TDRCLK) |
| dft_mux2 | 2:1 mux cell: every test-control mux (router levels 1, 2 and loopback; Rst_n_test, lpddr_scan_rstn) |
| dft_rst_sync | async-assert, sync-de-assert reset synchroniser cell (rst_dtr_n, lpddr_wrstn) |
| dft_sync2 | 2-flop synchroniser cell (DTR_STS inputs) |
| dft_dtr_reg | JTAG configuration data-register engine (u_cfg, u_lpddr) |
| dft_dtr_sts | DTR_STS capture-only status register |
| TCK1 | clock, from TCK1 pad (CTS net), integrator, rising and falling edge |
| clk_i | clock, from module clock port of the cells and the DTR engines; bound to TCK1 (u_cfg, u_lpddr, u_sts, u_dft_sync2_sts_dont_touch, u_dft_rst_sync_dtr_dont_touch) or to lpddr_tdrclk (u_dft_rst_sync_wrstn_dont_touch); for u_dft_icg_tdrclk_dont_touch it is the gated input TCK1, rising (dft_dtr_reg shadow: falling) edge |
| TRSTN1 | reset, active low, asynchronous assert and de-assert |
| rst_ni | reset, active low, asynchronous assert |
| TDRCLK | clock-gate cell |

## List of figures

| Figure | Title |
|---|---|
| Figure 1-1 | SOC_DFT top level: the delivered instances and the eight boundary groups. |
| Figure 1-2 | soc_dft hierarchy: the delivered instances and, dashed, the boundary of the withdrawn partial build (P_PARTITIONED = 0, refused at elaboration). |
| Figure 4-1 | Clocks, resets and crossings: every crossing passes one synchroniser or gating cell. |
| Figure 5-1 | The TSEL1 = 11 chain: TDI1 through the SMS TAP and the SOC_DFT TAP to TDO1. |
| Figure 5-2 | Scan channel routing: DFTSI through the gated fan-out to the block channels, and the block scan-outs back through the per-lane mode, EXTEST and loopback selections to DFTSO. |
| Figure 5-3 | One DR scan of DTR_CFG: the configuration changes on the falling TCK1 of Update-DR, and only while DFTTM = 0. |
| Figure 6-1 | Configuration and control path: pins and DTR shadows to the block and CRG controls |
| Figure 7-1 | The IEEE 1149.1 TAP state machine with the state codes of the specification's Table 45. |
| Figure 8-1 | DTR_CFG: shift stage, configuration stage, update and clear. |

## List of tables

| Table | Title |
|---|---|
| Table 2-1 | Configuration |
| Table 3-1 | Ports |
| Table 4-1 | Clocks |
| Table 4-2 | Resets |
| Table 5-1 | Storage |
| Table 5-2 | Walk |
| Table 6-1 | Modules |
| Table 6-2 | Module parameters |
| Table 6-3 | Derived constants |
| Table 6-4 | Method notes |
| Table 9-1 | Errors |
| Table 10-1 | Integration signals |
| Table 10-2 | Integration |
| Table 11-1 | Verification |
| Table 14-1 | Glossary |
| Table 14-2 | Revisions |

## Revision history

**Table 14-2.** Revisions

| Revision | Date | Change |
|---|---|---|
| 0.1 | 2026-10-16 | architecture-stage edition from the design record; the RTL-derived and verification sections are marked pending, the limitations written from the records of this stage |
| 0.2 | 2026-10-16 | RTL-derived sections regenerated from the RTL sources, prose from the design record |
| 0.3 | 2026-10-16 | verification status regenerated from the verification reports |
