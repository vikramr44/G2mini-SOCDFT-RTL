<!-- The outline every edition fills, internal and outward alike; each edition is written for its own reader, never derived from the other by deletion. Keep every heading and every table header as written. Cite with [src: path], [src: path:line], [src: path#anchor], [canon: D<number>] or [spec: <clause>]; an outward edition cites only what it delivers (the RTL, the constraints, the figures) and the source specification's clauses. A category the design has none of is stated as absent, never left empty. -->
<!-- Every numbered chapter opens with its lead-in slot (<chapter>-lead), and chapters 13 and 14 are the Software flow and the Glossary; gen_publication writes all of them from the records the edition is built from (sdip_tools/edition_prose), so the package fills none of them. -->
<!-- The customer render is a declared output, not a third edition: the standalone edition's content rendered with the traceability apparatus removed (sdip_tools/customer_render), held to a boundary that must find nothing. -->
<!-- OUTPUT: customer from=standalone boundary=apparatus -->

<!-- SLOT: title cite=none -->
# SOC_DFT chip-top DFT controller: microarchitecture
<!-- END SLOT: title -->

<!-- SLOT: identity cite=none -->
Artifact identity: Standalone engineering microarchitecture

RTL digest (SHA-256 over every file under rtl/): d17e8e74a1ac1bdc1ab87f732b2fa69c2f982374b50535219bbd685313560f12

Publication record (SHA-256 of declarations/publication-records.json): fda24d6608fe0eb0d9b568bcef2584b00c04c0d6795429029fa7aa3a68a5b6c2; stage DV
<!-- END SLOT: identity -->

## 1. Overview

<!-- SLOT: overview-lead cite=any -->
soc_dft is the top of a design of 17 modules (soc_dft, dft_pad_if, dft_jtag1_rtr, dft_tap, dft_dtr, dft_mode_dec, dft_crg_ctl, dft_ddr_tdr, dft_sms_srv, dft_scan_rtr, dft_scan_hold, dft_icg, dft_mux2, dft_rst_sync, dft_sync2, dft_dtr_reg, dft_dtr_sts), with a boundary of 174 ports [src: rtl/soc_dft.sv]. This document follows the order an integrator reads in: configuration, interface, clocks and resets, the datapath with one transaction walked cycle by cycle, the modules, the state machines, the registers, error behaviour, the integration contract, the verification status, the limitations, the software flow and a glossary.
<!-- END SLOT: overview-lead -->

<!-- SLOT: overview cite=any -->
![SOC_DFT top-level overview](figures/view-overview.png)
**Figure 1-1.** SOC_DFT top level: the delivered instances and the eight boundary groups. [src: publication/figures/view-overview.json]

![soc_dft instance hierarchy](figures/top-diagram.png)
**Figure 1-2.** soc_dft hierarchy: the delivered instances and, dashed, the boundary of the withdrawn partial build (P_PARTITIONED = 0, refused at elaboration). [src: publication/figures/top-diagram.dot]

SOC_DFT is the chip-top DFT controller of the G2mini SoC. It turns the tester's 50 DFT and JTAG1 pins into the static test configuration of the DFT blocks, the TOP glue, the LPDDR subsystem and the chip clock and reset generator, routes one JTAG port to four TAP targets, and holds the JTAG-programmed configuration in three test data registers [spec: 4.1] [spec: 6.1]. This document describes revision 0.3, reissued for revision 0.92 of the specification: the full build, with the partition decode and the scan router that connect the 20 scan pin pairs to the block channels of each test mode; the SMS shell carries an IEEE 1149.1 TAP with the IDCODE and BYPASS registers until the generated SMS TAP and Server are inserted [spec: 11.3] [spec: 12.3] [spec: 14.6]. The PART value of each test mode is provisional until the DFT team assigns the codes [spec: 12.7].
<!-- END SLOT: overview -->

## 2. Configuration

<!-- SLOT: configuration-lead cite=any -->
soc_dft is configured at build time by 12 parameters (P_IDCODE, P_OE_GATED, P_TM_OPEN, P_DFTSO_HIZ_M0, P_CFG_RST, P_LPDDR_RST, P_RTL_REV, P_TDR_EN_EDGE, P_DFTMAX_COMP, P_SMS_IR_LEN, P_SMS_IDCODE, P_PARTITIONED); each row below gives its type, its default, the values it may legally take and what a change does [src: rtl/soc_dft.sv].
<!-- END SLOT: configuration-lead -->

**Table 2-1.** Configuration

<!-- SLOT: configuration cite=each -->
| Parameter | Type | Default | Legal range | Effect |
|---|---|---|---|---|
| P_IDCODE | logic [31:0] | 32'h0000_0001 | any value with bit 0 = 1 | IDCODE of the SOC_DFT TAP; the chip top sets the assigned value [spec: 9.5] |
| P_OE_GATED | bit | 1 | 0, 1 | 1 gates each target's TDO enable with its select; 0 ORs the four enables [spec: 8.4] |
| P_TM_OPEN | bit | 1 | 0, 1 | 1 lets TMS1 reach the ARC and PCIe TAPs while DFTTM = 1 [spec: 8.4] |
| P_DFTSO_HIZ_M0 | bit | 1 | 0, 1 | 1 leaves DFTSO in high impedance in mission mode; 0 drives it 0 [spec: 7.3] |
| P_CFG_RST | logic [31:0] | 32'h003F_FFA5 | bits 22:0 meaningful | DTR_CFG value after power-good [spec: 10.2] |
| P_LPDDR_RST | logic [31:0] | 32'h0000_0000 | bits 17:0 meaningful | DTR_LPDDR value after power-good [spec: 10.3] |
| P_RTL_REV | logic [7:0] | 8'h05 | any | revision value read in DTR_STS [spec: 10.4] |
| P_TDR_EN_EDGE | bit | 1 | 0, 1 | TCK1 edge that launches the LPDDR PHY TDR enables: 1 falling, 0 rising [spec: 15.4] |
| P_DFTMAX_COMP | bit | 1 | 0, 1 | DFTMAX value that selects compressed scan [spec: 7.3] |
| P_SMS_IR_LEN | int | 4 | 2 to 8 | instruction length of the SMS TAP in this release [spec: 14.6] |
| P_SMS_IDCODE | logic [31:0] | 32'h0001_0001 | bit 0 = 1, different from P_IDCODE | IDCODE of the SMS TAP in this release [spec: 14.6] |
| P_PARTITIONED | bit | 1 | 1 | 1 builds the partition decode and the scan router; 0, the partial build of Section 11.3, is refused at elaboration [spec: 11.3] |
<!-- END SLOT: configuration -->

## 3. Interface

<!-- SLOT: interface-lead cite=any -->
The boundary of soc_dft is 174 ports: 52 in, 122 out, in 8 groups: pad (11), clock and reset (4), jtag targets (9), blocks (99), top glue (3), sms (18), lpddr (22), crg (8). Each row gives a port's direction, width, the clock it is timed by, its value in reset and what it carries [src: rtl/soc_dft.sv:26] [src: rtl/soc_dft.sv:27].
<!-- END SLOT: interface-lead -->

<!-- SLOT: interface-summary cite=any -->
The boundary has eight groups (Figure 1-1): the scan and power pads, the JTAG1 pads, the external JTAG targets, the block test controls, the clock and reset generator controls, the LPDDR PHY TDR port, the scan channels and the SMS processor ports [spec: 6.4]. Every port has the name, direction and width of Appendix B of the specification [spec: Appendix B]. In each test mode the scan router connects the 20 scan pin pairs to the channels of the selected blocks, the wrapper chains or the TOP chains; unmapped pins drive 0 [spec: 12.3]. The SMS port membership and bit order may change with confirmations CONF-33 and CONF-17 [spec: 14.2] [spec: 14.3].
<!-- END SLOT: interface-summary -->

**Table 3-1.** Ports

<!-- SLOT: ports cite=each -->
| Port | Direction | Width | Clock | Reset value | Group | Meaning |
|---|---|---|---|---|---|---|
| DFTTM | input | 1 | static | -- | pad | tester pin DFTTM through its pad; scan test enable [src: rtl/soc_dft.sv:26] |
| DFTMAX | input | 1 | static | -- | pad | tester pin DFTMAX; compression select [src: rtl/soc_dft.sv:27] |
| DFTSE | input | 1 | test clock | -- | pad | tester pin DFTSE; global scan shift enable [src: rtl/soc_dft.sv:28] |
| DFTSI | input | UNDERIVED | test clock | -- | pad | tester pins DFTSI[19:0]; scan channel inputs [src: rtl/soc_dft.sv:29] |
| DFTSO | output | UNDERIVED | test clock | UNDERIVED | pad | dft_pad_if from dftso_o, the router's scan-out lanes (loopback, EXTEST or the selected INTEST mode; 0 when unmapped or tm = 0) [src: rtl/soc_dft.sv:30] |
| DFTSO_OE | output | 1 | static | UNDERIVED | pad | dft_pad_if: P_DFTSO_HIZ_M0 ? tm : 1, one net to all 20 DFTSO pads [src: rtl/soc_dft.sv:31] |
| TSEL1 | input | 2 | static | -- | pad | tester pins {TSEL1_1, TSEL1_0}; JTAG1 target select [src: rtl/soc_dft.sv:32] |
| TCK1 | input | 1 | - | -- | clock and reset | TCK1 pad (CTS net); JTAG1 clock [src: rtl/soc_dft.sv:33] |
| TMS1 | input | 1 | TCK1 | -- | pad | TMS1 pad; JTAG mode select [src: rtl/soc_dft.sv:34] |
| TDI1 | input | 1 | TCK1 | -- | pad | TDI1 pad; JTAG data in [src: rtl/soc_dft.sv:35] |
| TRSTN1 | input | 1 | async | -- | clock and reset | TRSTN1 pad; asynchronous active-low TAP reset [src: rtl/soc_dft.sv:36] |
| TDO1 | output | 1 | TCK1 falling | UNDERIVED | pad | dft_jtag1_rtr: TDO of the selected target [src: rtl/soc_dft.sv:37] |
| TDO1_OE | output | 1 | TCK1 falling | UNDERIVED | pad | dft_jtag1_rtr: output enable of the TDO1 pad [src: rtl/soc_dft.sv:38] |
| PwrOk | input | 1 | async | -- | clock and reset | PwrOk pad; power-good, DTR shadow reset source [src: rtl/soc_dft.sv:40] |
| Rstn | input | 1 | async | -- | clock and reset | Rstn pad; chip reset, source of Rst_n_test [src: rtl/soc_dft.sv:42] |
| arc_tms1 | output | 1 | TCK1 | UNDERIVED | jtag targets | dft_jtag1_rtr: gated TMS of the arc target [src: rtl/soc_dft.sv:44] |
| pcia_tms1 | output | 1 | TCK1 | UNDERIVED | jtag targets | dft_jtag1_rtr: gated TMS of the pcia target [src: rtl/soc_dft.sv:45] |
| pcib_tms1 | output | 1 | TCK1 | UNDERIVED | jtag targets | dft_jtag1_rtr: gated TMS of the pcib target [src: rtl/soc_dft.sv:46] |
| arc_tdo1 | input | 1 | TCK1 falling | -- | jtag targets | arc TAP TDO [src: rtl/soc_dft.sv:47] |
| arc_tdo1_oe | input | 1 | TCK1 falling | -- | jtag targets | arc TAP TDO enable [src: rtl/soc_dft.sv:48] |
| pcia_tdo1 | input | 1 | TCK1 falling | -- | jtag targets | pcia TAP TDO [src: rtl/soc_dft.sv:49] |
| pcia_tdo1_oe | input | 1 | TCK1 falling | -- | jtag targets | pcia TAP TDO enable [src: rtl/soc_dft.sv:50] |
| pcib_tdo1 | input | 1 | TCK1 falling | -- | jtag targets | pcib TAP TDO [src: rtl/soc_dft.sv:51] |
| pcib_tdo1_oe | input | 1 | TCK1 falling | -- | jtag targets | pcib TAP TDO enable [src: rtl/soc_dft.sv:52] |
| scc_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:54] |
| scc_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:55] |
| scc_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:56] |
| scc_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:57] |
| scc_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) [src: rtl/soc_dft.sv:58] |
| scc_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[0 + j] (mode 2, PART 3) [src: rtl/soc_dft.sv:59] |
| scc_test_so | input | UNDERIVED | test clock | -- | blocks | block scc scan channel outputs [src: rtl/soc_dft.sv:60] |
| scc_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) [src: rtl/soc_dft.sv:61] |
| scc_wrap_so | input | UNDERIVED | test clock | -- | blocks | block scc wrapper chain outputs [src: rtl/soc_dft.sv:62] |
| hic_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:63] |
| hic_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:64] |
| hic_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:65] |
| hic_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:66] |
| hic_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) [src: rtl/soc_dft.sv:67] |
| hic_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[0 + j] (mode 3, PART 4) [src: rtl/soc_dft.sv:68] |
| hic_test_so | input | UNDERIVED | test clock | -- | blocks | block hic scan channel outputs [src: rtl/soc_dft.sv:69] |
| hic_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) [src: rtl/soc_dft.sv:70] |
| hic_wrap_so | input | UNDERIVED | test clock | -- | blocks | block hic wrapper chain outputs [src: rtl/soc_dft.sv:71] |
| g2muc_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:72] |
| g2muc_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:73] |
| g2muc_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:74] |
| g2muc_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:75] |
| g2muc_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) [src: rtl/soc_dft.sv:76] |
| g2muc_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[5 + j] (mode 2, PART 3) [src: rtl/soc_dft.sv:77] |
| g2muc_test_so | input | UNDERIVED | test clock | -- | blocks | block g2muc scan channel outputs [src: rtl/soc_dft.sv:78] |
| g2muc_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) [src: rtl/soc_dft.sv:79] |
| g2muc_wrap_so | input | UNDERIVED | test clock | -- | blocks | block g2muc wrapper chain outputs [src: rtl/soc_dft.sv:80] |
| l4ga_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:81] |
| l4ga_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:82] |
| l4ga_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:83] |
| l4ga_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:84] |
| l4ga_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) [src: rtl/soc_dft.sv:85] |
| l4ga_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[5 + j] (mode 3, PART 4) [src: rtl/soc_dft.sv:86] |
| l4ga_test_so | input | UNDERIVED | test clock | -- | blocks | block l4ga scan channel outputs [src: rtl/soc_dft.sv:87] |
| l4ga_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) [src: rtl/soc_dft.sv:88] |
| l4ga_wrap_so | input | UNDERIVED | test clock | -- | blocks | block l4ga wrapper chain outputs [src: rtl/soc_dft.sv:89] |
| l4gb_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:90] |
| l4gb_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:91] |
| l4gb_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:92] |
| l4gb_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:93] |
| l4gb_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) [src: rtl/soc_dft.sv:94] |
| l4gb_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[8 + j] (mode 3, PART 4) [src: rtl/soc_dft.sv:95] |
| l4gb_test_so | input | UNDERIVED | test clock | -- | blocks | block l4gb scan channel outputs [src: rtl/soc_dft.sv:96] |
| l4gb_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) [src: rtl/soc_dft.sv:97] |
| l4gb_wrap_so | input | UNDERIVED | test clock | -- | blocks | block l4gb wrapper chain outputs [src: rtl/soc_dft.sv:98] |
| pcia_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:99] |
| pcia_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:100] |
| pcia_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:101] |
| pcia_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:102] |
| pcia_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) [src: rtl/soc_dft.sv:103] |
| pcia_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[0 + j] (mode 0, PART 1) [src: rtl/soc_dft.sv:104] |
| pcia_test_so | input | UNDERIVED | test clock | -- | blocks | block pcia scan channel outputs [src: rtl/soc_dft.sv:105] |
| pcia_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) [src: rtl/soc_dft.sv:106] |
| pcia_wrap_so | input | UNDERIVED | test clock | -- | blocks | block pcia wrapper chain outputs [src: rtl/soc_dft.sv:107] |
| pcib_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:108] |
| pcib_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:109] |
| pcib_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:110] |
| pcib_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:111] |
| pcib_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) [src: rtl/soc_dft.sv:112] |
| pcib_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[0 + j] (mode 1, PART 2) [src: rtl/soc_dft.sv:113] |
| pcib_test_so | input | UNDERIVED | test clock | -- | blocks | block pcib scan channel outputs [src: rtl/soc_dft.sv:114] |
| pcib_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) [src: rtl/soc_dft.sv:115] |
| pcib_wrap_so | input | UNDERIVED | test clock | -- | blocks | block pcib wrapper chain outputs [src: rtl/soc_dft.sv:116] |
| ahb_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:117] |
| ahb_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:118] |
| ahb_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:119] |
| ahb_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:120] |
| ahb_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) [src: rtl/soc_dft.sv:121] |
| ahb_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[11 + j] (mode 2, PART 3) [src: rtl/soc_dft.sv:122] |
| ahb_test_so | input | UNDERIVED | test clock | -- | blocks | block ahb scan channel outputs [src: rtl/soc_dft.sv:123] |
| ahb_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) [src: rtl/soc_dft.sv:124] |
| ahb_wrap_so | input | UNDERIVED | test clock | -- | blocks | block ahb wrapper chain outputs [src: rtl/soc_dft.sv:125] |
| apb_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:126] |
| apb_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:127] |
| apb_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:128] |
| apb_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:129] |
| apb_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) [src: rtl/soc_dft.sv:130] |
| apb_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[11 + j] (mode 3, PART 4) [src: rtl/soc_dft.sv:131] |
| apb_test_so | input | UNDERIVED | test clock | -- | blocks | block apb scan channel outputs [src: rtl/soc_dft.sv:132] |
| apb_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) [src: rtl/soc_dft.sv:133] |
| apb_wrap_so | input | UNDERIVED | test clock | -- | blocks | block apb wrapper chain outputs [src: rtl/soc_dft.sv:134] |
| axis_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:135] |
| axis_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:136] |
| axis_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:137] |
| axis_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:138] |
| axis_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) [src: rtl/soc_dft.sv:139] |
| axis_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[17 + j] (mode 2, PART 3) [src: rtl/soc_dft.sv:140] |
| axis_test_so | input | UNDERIVED | test clock | -- | blocks | block axis scan channel outputs [src: rtl/soc_dft.sv:141] |
| axis_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) [src: rtl/soc_dft.sv:142] |
| axis_wrap_so | input | UNDERIVED | test clock | -- | blocks | block axis wrapper chain outputs [src: rtl/soc_dft.sv:143] |
| axim_dfttm | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:144] |
| axim_scan_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:145] |
| axim_wrap_shift_en | output | 1 | static | combinational | blocks | dft_mode_dec: tm & dftse_i & (active[b] \| ~SE_GATE) [src: rtl/soc_dft.sv:146] |
| axim_test_mode_tp | output | 1 | static | combinational | blocks | dft_mode_dec: = tm [src: rtl/soc_dft.sv:147] |
| axim_test_mode | output | 4 | static | combinational | blocks | dft_mode_dec: ENC_FUNC when tm = 0, ENC_WRP_OF in EXTEST, ENC_WRP_IF when not selected, else ENC_COMP or ENC_SCAN by dftmax_i (Table 55) [src: rtl/soc_dft.sv:148] |
| axim_test_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: sel[b] & DFTSI[15 + j] (mode 3, PART 4) [src: rtl/soc_dft.sv:149] |
| axim_test_so | input | UNDERIVED | test clock | -- | blocks | block axim scan channel outputs [src: rtl/soc_dft.sv:150] |
| axim_wrap_si | output | UNDERIVED | test clock | combinational | blocks | dft_scan_rtr: [0] = extest & DFTSI[b]; [1] = extest & <blk>_wrap_so[0] (chains in series) [src: rtl/soc_dft.sv:151] |
| axim_wrap_so | input | UNDERIVED | test clock | -- | blocks | block axim wrapper chain outputs [src: rtl/soc_dft.sv:152] |
| top_scan_shift_en | output | 1 | test clock | UNDERIVED | top glue | dft_mode_dec: tm & dftse_i & extest [src: rtl/soc_dft.sv:154] |
| top_test_si | output | UNDERIVED | test clock | UNDERIVED | top glue | dft_scan_rtr: extest & DFTSI[11 + t] [src: rtl/soc_dft.sv:155] |
| top_test_so | input | UNDERIVED | test clock | -- | top glue | TOP chain scan outputs [src: rtl/soc_dft.sv:156] |
| scc_sms_in | output | 5 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise [src: rtl/soc_dft.sv:158] |
| hic_sms_in | output | 5 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise [src: rtl/soc_dft.sv:159] |
| g2muc_sms_in | output | 5 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise [src: rtl/soc_dft.sv:160] |
| l4ga_sms_in | output | 5 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise [src: rtl/soc_dft.sv:161] |
| l4gb_sms_in | output | 5 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise [src: rtl/soc_dft.sv:162] |
| ahb_sms_in | output | 5 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise [src: rtl/soc_dft.sv:163] |
| lpddr_sms_in | output | 5 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise [src: rtl/soc_dft.sv:164] |
| pcia_sms_in | output | 10 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise [src: rtl/soc_dft.sv:165] |
| pcib_sms_in | output | 10 | TCK1 falling | UNDERIVED | sms | dft_sms_srv: 0 from the stub; generated SMS Server otherwise [src: rtl/soc_dft.sv:166] |
| scc_sms_out | input | 1 | TCK1 | -- | sms | SMS processor WSO of scc [src: rtl/soc_dft.sv:167] |
| hic_sms_out | input | 1 | TCK1 | -- | sms | SMS processor WSO of hic [src: rtl/soc_dft.sv:168] |
| g2muc_sms_out | input | 1 | TCK1 | -- | sms | SMS processor WSO of g2muc [src: rtl/soc_dft.sv:169] |
| l4ga_sms_out | input | 1 | TCK1 | -- | sms | SMS processor WSO of l4ga [src: rtl/soc_dft.sv:170] |
| l4gb_sms_out | input | 1 | TCK1 | -- | sms | SMS processor WSO of l4gb [src: rtl/soc_dft.sv:171] |
| ahb_sms_out | input | 1 | TCK1 | -- | sms | SMS processor WSO of ahb [src: rtl/soc_dft.sv:172] |
| lpddr_sms_out | input | 1 | TCK1 | -- | sms | SMS processor WSO of lpddr [src: rtl/soc_dft.sv:173] |
| pcia_sms_out | input | 2 | TCK1 | -- | sms | SMS processor WSO of pcia (two ports) [src: rtl/soc_dft.sv:174] |
| pcib_sms_out | input | 2 | TCK1 | -- | sms | SMS processor WSO of pcib (two ports) [src: rtl/soc_dft.sv:175] |
| lpddr_atpg_mode | output | 1 | static | UNDERIVED | lpddr | dft_mode_dec: DTR_LPDDR override, else tm & active[11] (0: LPDDR is in no mode) [src: rtl/soc_dft.sv:177] |
| lpddr_compression_mode | output | 1 | static | UNDERIVED | lpddr | dft_mode_dec: DTR_LPDDR override, else tm & dftmax_i & sel[11] (0: LPDDR is in no mode) [src: rtl/soc_dft.sv:178] |
| lpddr_phy0_burnin | output | 1 | static | UNDERIVED | lpddr | dft_mode_dec: tm & BURNIN & PHY0_BURNIN [src: rtl/soc_dft.sv:179] |
| lpddr_phy1_burnin | output | 1 | static | UNDERIVED | lpddr | dft_mode_dec: tm & BURNIN & PHY1_BURNIN [src: rtl/soc_dft.sv:180] |
| lpddr_atpg_se | output | 16 | static | UNDERIVED | lpddr | dft_mode_dec: {16{tm & dftse_i & active[11]}} (0: LPDDR is in no mode) [src: rtl/soc_dft.sv:181] |
| lpddr_scan_ctl | output | 2 | static | UNDERIVED | lpddr | dft_mode_dec: tied 2'b00 (CONF-19) [src: rtl/soc_dft.sv:182] |
| lpddr_scan_shift_cg | output | 1 | static | UNDERIVED | lpddr | dft_mode_dec: SCAN_SHIFT_CG_OVR \| (tm & dftse_i & active[11]) [src: rtl/soc_dft.sv:183] |
| lpddr_scan_rstn | output | 1 | static | UNDERIVED | lpddr | dft_crg_ctl: tm ? Rst_n_test : 1 [src: rtl/soc_dft.sv:184] |
| lpddr_sms_dm | output | 3 | static | UNDERIVED | lpddr | dft_dtr: DTR_LPDDR.SMS_DM [src: rtl/soc_dft.sv:185] |
| lpddr_ring_bypass | output | 7 | static | UNDERIVED | lpddr | dft_dtr: DTR_LPDDR.RING_BYPASS [src: rtl/soc_dft.sv:186] |
| lpddr_sfp_dft_mode | output | 1 | static | UNDERIVED | lpddr | dft_dtr: DTR_LPDDR.SFP_DFT_MODE [src: rtl/soc_dft.sv:187] |
| lpddr_tdrclk | output | 1 | - | UNDERIVED | lpddr | dft_ddr_tdr: TCK1 gated by ddr_tdr_en [src: rtl/soc_dft.sv:188] |
| lpddr_wrstn | output | 1 | static | UNDERIVED | lpddr | dft_ddr_tdr: TRSTN1 & ddr_tdr_en, released on TDRCLK [src: rtl/soc_dft.sv:189] |
| lpddr_cmd_tdr_capture_en | output | 2 | TCK1 falling | UNDERIVED | lpddr | dft_ddr_tdr: TDR enable, {phy1, phy0} [src: rtl/soc_dft.sv:190] |
| lpddr_cmd_tdr_shift_en | output | 2 | TCK1 falling | UNDERIVED | lpddr | dft_ddr_tdr: TDR enable, {phy1, phy0} [src: rtl/soc_dft.sv:191] |
| lpddr_cmd_tdr_update_en | output | 2 | TCK1 falling | UNDERIVED | lpddr | dft_ddr_tdr: TDR enable, {phy1, phy0} [src: rtl/soc_dft.sv:192] |
| lpddr_rd_tdr_capture_en | output | 2 | TCK1 falling | UNDERIVED | lpddr | dft_ddr_tdr: TDR enable, {phy1, phy0} [src: rtl/soc_dft.sv:193] |
| lpddr_rd_tdr_shift_en | output | 2 | TCK1 falling | UNDERIVED | lpddr | dft_ddr_tdr: TDR enable, {phy1, phy0} [src: rtl/soc_dft.sv:194] |
| lpddr_rd_tdr_update_en | output | 2 | TCK1 falling | UNDERIVED | lpddr | dft_ddr_tdr: TDR enable, {phy1, phy0} [src: rtl/soc_dft.sv:195] |
| lpddr_wsi | output | 2 | TCK1 | UNDERIVED | lpddr | dft_ddr_tdr: tap_tdi to the selected PHY TDR [src: rtl/soc_dft.sv:196] |
| lpddr_cmd_tdr_tdo | input | 2 | TDRCLK | -- | lpddr | PHY CsrCmd TDR TDO, {phy1, phy0} [src: rtl/soc_dft.sv:197] |
| lpddr_rd_tdr_tdo | input | 2 | TDRCLK | -- | lpddr | PHY CsrRdData TDR TDO, {phy1, phy0} [src: rtl/soc_dft.sv:198] |
| dft_crg_test_clk_sel | output | 1 | static | UNDERIVED | crg | dft_crg_ctl: = tm [src: rtl/soc_dft.sv:200] |
| dft_crg_rst_byp | output | 1 | static | UNDERIVED | crg | dft_crg_ctl: = tm [src: rtl/soc_dft.sv:201] |
| dft_crg_rst_n_test | output | 1 | static | UNDERIVED | crg | dft_crg_ctl: Rst_n_test [src: rtl/soc_dft.sv:202] |
| dft_crg_pll_byp | output | 3 | static | UNDERIVED | crg | dft_crg_ctl: (tm & PLL_BYP) ? 111 : 000 [src: rtl/soc_dft.sv:203] |
| dft_crg_blk_clk_en | output | 13 | static | UNDERIVED | crg | dft_crg_ctl: ~tm \| (BLK_CLK_EN & active) [src: rtl/soc_dft.sv:204] |
| dft_crg_comp_clk_en | output | 13 | static | UNDERIVED | crg | dft_crg_ctl: tm & dftmax_i & sel & BLK_CLK_EN [src: rtl/soc_dft.sv:205] |
| dft_crg_lpddr_clk_en | output | 5 | static | UNDERIVED | crg | dft_crg_ctl: tm & active[11] & BLK_CLK_EN[11] [src: rtl/soc_dft.sv:206] |
| crg_pll_ready | input | 3 | async | -- | crg | chip PLLs {DfiClk, Gclk, Uclk} ready [src: rtl/soc_dft.sv:207] |
<!-- END SLOT: ports -->

## 4. Clocks, resets and crossings

<!-- SLOT: clocks-lead cite=any -->
soc_dft is clocked by 2 clocks (TCK1, clk_i) and reset by 2 resets (TRSTN1, rst_ni); the tables give each one's source, edge and coverage, and the crossings between them follow with how each is made safe [src: rtl/soc_dft.sv] [src: rtl/soc_dft.sv:36].
<!-- END SLOT: clocks-lead -->

**Table 4-1.** Clocks

<!-- SLOT: clocks cite=each -->
| Clock | Source | Edge | Frequency | Drives |
|---|---|---|---|---|
| TCK1 | TCK1 pad (CTS net), integrator | rising and falling | 20 MHz maximum; 10 MHz with a DDRx instruction | dft_tap, dft_ddr_tdr [src: rtl/soc_dft.sv] |
| clk_i | module clock port of the cells and the DTR engines; bound to TCK1 (u_cfg, u_lpddr, u_sts, u_dft_sync2_sts_dont_touch, u_dft_rst_sync_dtr_dont_touch) or to lpddr_tdrclk (u_dft_rst_sync_wrstn_dont_touch); for u_dft_icg_tdrclk_dont_touch it is the gated input TCK1 | rising (dft_dtr_reg shadow: falling) | that of the clock it is bound to | dft_rst_sync, dft_sync2, dft_dtr_reg, dft_dtr_sts [src: rtl/soc_dft.sv] |
<!-- END SLOT: clocks -->

**Table 4-2.** Resets

<!-- SLOT: resets cite=each -->
| Reset | Polarity | Synchronicity | Coverage | Synchronizer |
|---|---|---|---|---|
| TRSTN1 | active low | asynchronous assert and de-assert | dft_tap FSM, IR, BYPASS, TDO retime (both instances); dft_ddr_tdr enables; WRSTN source | none (IEEE 1149.1 TRST) [src: rtl/soc_dft.sv:36] |
| rst_ni | active low | asynchronous assert | module reset port of dft_dtr_reg (bound to rst_dtr_n) and of dft_rst_sync (bound to PwrOk, or to TRSTN1 & ddr_tdr_en for WRSTN) | dft_rst_sync releases its output synchronously; dft_dtr_reg receives an already released reset [src: rtl/soc_dft.sv] |
<!-- END SLOT: resets -->

<!-- SLOT: crossings cite=each -->
![clocks, resets and crossings](figures/view-clock-reset.png)
**Figure 4-1.** Clocks, resets and crossings: every crossing passes one synchroniser or gating cell. [src: publication/figures/view-clock-reset.json]

PwrOk enters the TCK1 domain through a reset synchroniser: the internal DTR reset asserts as soon as PwrOk falls and releases on the second rising TCK1 after PwrOk rises [spec: 7.3].

The eight status inputs read in DTR_STS (DFTTM, the compression select, TSEL1[1:0], the three PLL-ready inputs and PwrOk) each pass a two-flop synchroniser clocked by TCK1 [spec: 10.4] [spec: 18.4].

The LPDDR WRSTN output is TRSTN1 & DDR_TDR_EN, asserted asynchronously and released through two flops clocked by TDRCLK [spec: 15.4].

DFTTM reaches the TCK1 logic without a synchroniser because it changes only while Rstn = 0 and while the TAP chain is in Test-Logic-Reset or Run-Test/Idle [spec: 5.4] [spec: 10.6].
<!-- END SLOT: crossings -->

## 5. Datapath

<!-- SLOT: datapath-lead cite=any -->
The design holds 12 registers and 0 memories across its 17 modules; section 5.1 follows one transaction through them in 7 steps [src: rtl/dft_tap.sv:83] [src: rtl/dft_tap.sv:91].
<!-- END SLOT: datapath-lead -->

<!-- SLOT: datapath cite=any -->
![JTAG serial path](figures/view-serial.png)
**Figure 5-1.** The TSEL1 = 11 chain: TDI1 through the SMS TAP and the SOC_DFT TAP to TDO1. [src: publication/figures/view-serial.json]

![scan channel routing](figures/view-scan.png)
**Figure 5-2.** Scan channel routing: DFTSI through the gated fan-out to the block channels, and the block scan-outs back through the per-lane mode, EXTEST and loopback selections to DFTSO. [src: publication/figures/view-scan.json]

SOC_DFT has two data paths. The scan channels are combinational: in a test mode each selected block's channel takes its DFTSI pin and returns on the same pin; in EXTEST each block's two wrapper chains run in series on one pin and the TOP chains on pins 11 to 13; in loopback each DFTSO follows its DFTSI; nothing is clocked on the way [spec: 12.3]. The other is the serial JTAG scan. With TSEL1 = 11 the JTAG1 port sees two devices: TDI1 enters the SMS TAP, whose TDO is the serial input of every SOC_DFT data register, and the SOC_DFT TAP drives TDO1 through the JTAG1 router [spec: 9.1]. Data rests in the shift stages between Capture-DR and Update-DR and in the register shadows after Update-DR [spec: 10.6]. The storage table below lists every element with its value after reset.
<!-- END SLOT: datapath -->

**Table 5-1.** Storage

<!-- SLOT: storage cite=each -->
| Module | Element | Kind | Width | Value after reset | Holds |
|---|---|---|---|---|---|
| dft_tap | state_q | register | 4 | - | TAP state [src: rtl/dft_tap.sv:83] |
| dft_tap | ir_sr_q | register | P_IR_LEN | - | IR shift stage [src: rtl/dft_tap.sv:91] |
| dft_tap | ir_q | register | P_IR_LEN | - | IR update stage [src: rtl/dft_tap.sv:96] |
| dft_tap | idcode_sr_q | register | 32 | - | IDCODE shift register [src: rtl/dft_tap.sv:125] |
| dft_tap | byp_q | register | 1 | 1'b0 | BYPASS [src: rtl/dft_tap.sv:130] |
| dft_tap | tdo_q | register | 1 | 1'b0 | sms_tdo1 retime [src: rtl/dft_tap.sv:145] |
| dft_tap | tdo_oe_q | register | 1 | 1'b0 | sms_tdo1_oe retime [src: rtl/dft_tap.sv:146] |
| dft_ddr_tdr | en_q | register | 12 | 12'h000 | TDR capture/shift/update enables [src: rtl/dft_ddr_tdr.sv:63] |
| dft_rst_sync | sync_q | register | 2 | 2'b00 | reset release pipeline [src: rtl/cells/dft_rst_sync.sv:17] |
| dft_sync2 | meta_q | register | P_WIDTH | - | first synchroniser stage [src: rtl/cells/dft_sync2.sv:15] |
| dft_sync2 | sync_q | register | 2 | - | reset release pipeline [src: rtl/cells/dft_sync2.sv:16] |
| dft_dtr_reg | sr_q | register | P_WIDTH | - | DR shift stage [src: rtl/dft_dtr_reg.sv:35] |
| dft_dtr_reg | shadow_q | register | P_WIDTH | - | DR shadow (configuration) [src: rtl/dft_dtr_reg.sv:39] |
| dft_dtr_sts | sr_q | register | P_WIDTH | - | DR shift stage [src: rtl/dft_dtr_sts.sv:20] |
<!-- END SLOT: storage -->

### 5.1 One transaction, cycle by cycle

<!-- SLOT: transaction cite=any -->
![one DR scan of DTR_CFG](figures/wave-dtr-update.png)
**Figure 5-3.** One DR scan of DTR_CFG: the configuration changes on the falling TCK1 of Update-DR, and only while DFTTM = 0. [src: publication/figures/wave-dtr-update.json]

The walk below writes DTR_CFG with the sequence of Section 9.8 of the specification, starting with the instruction register holding DTR_CFG in the SOC_DFT TAP and BYPASS in the SMS TAP. Each step is one rising TCK1 edge [spec: 9.8].
<!-- END SLOT: transaction -->

**Table 5-2.** Walk

<!-- SLOT: walk cite=each -->
| Step | Inputs sampled | State before | Registers written | Outputs after |
|---|---|---|---|---|
| 1 | TMS = 1 | RUN_TEST_IDLE | TAP state | state SELECT_DR_SCAN; TDO1 not enabled [spec: 9.3] |
| 2 | TMS = 0 | SELECT_DR_SCAN | TAP state | state CAPTURE_DR [spec: 9.3] |
| 3 | TMS = 0 | CAPTURE_DR | DTR_CFG shift stage loads the current configuration | state SHIFT_DR [spec: 10.6] |
| 4 | TMS = 0, TDI bit 0 | SHIFT_DR | shift stage shifts toward TDO | TDO1 carries the old bit 0 [spec: 9.6] |
| 5 | TMS = 1, TDI bit 31 | SHIFT_DR | shift stage holds the 32 new bits | state EXIT1_DR [spec: 9.3] |
| 6 | TMS = 1 | EXIT1_DR | TAP state | state UPDATE_DR [spec: 9.3] |
| 7 | TMS = 0, DFTTM = 0 | UPDATE_DR | DTR_CFG configuration loads on falling TCK1 | every control derived from DTR_CFG changes [spec: 10.6] |
<!-- END SLOT: walk -->

## 6. Modules

<!-- SLOT: modules-lead cite=any -->
soc_dft is built from 17 modules: soc_dft, dft_pad_if, dft_jtag1_rtr, dft_tap, dft_dtr, dft_mode_dec, dft_crg_ctl, dft_ddr_tdr, dft_sms_srv, dft_scan_rtr and 7 more. The interconnect between them comes first, then for each module what it consumes, what it holds and its role, its parameters, its derived constants and where each mechanism is implemented [src: rtl/soc_dft.sv] [src: rtl/dft_pad_if.sv].
<!-- END SLOT: modules-lead -->

<!-- SLOT: interconnect cite=any -->
Figure 6-1 draws configuration and control path.

![configuration and control path](figures/view-control.png)
**Figure 6-1.** Configuration and control path: pins and DTR shadows to the block and CRG controls [src: publication/figures/view-control.json]
<!-- END SLOT: interconnect -->

**Table 6-1.** Modules

<!-- SLOT: modules cite=each -->
| Module | Consumes | Holds | Role |
|---|---|---|---|
| soc_dft | dft_part_map_pkg, the parameters of Appendix B | no state | top: instances of Table 21; the router (g_scan_rtr, P_PARTITIONED = 1); the g_scan_hold branch with dft_scan_hold is unreachable, P_PARTITIONED = 0 being refused at elaboration (CONF-38 closed); per-block slices of the router's flat channel buses [src: rtl/soc_dft.sv] |
| dft_pad_if | P_DFTSO_HIZ_M0, P_DFTMAX_COMP | no state | pad buffers, DFTSO_OE, dftmax_i, rst_dtr_n [src: rtl/dft_pad_if.sv] |
| dft_jtag1_rtr | P_OE_GATED, P_TM_OPEN | no state | TSEL1 decode, TMS gating, TDO1 mux [src: rtl/dft_jtag1_rtr.sv] |
| dft_tap | P_IR_LEN, P_DR_CLIENTS, P_IDCODE | state_q, ir_sr_q, ir_q, idcode_sr_q, byp_q, tdo_q, tdo_oe_q | IEEE 1149.1 TAP (also the SMS stub under dft_sms_srv) [src: rtl/dft_tap.sv] |
| dft_dtr | P_CFG_RST, P_LPDDR_RST, P_RTL_REV, NPART | no state | DTR_CFG, DTR_LPDDR, DTR_STS host [src: rtl/dft_dtr.sv] |
| dft_mode_dec | P_PARTITIONED, PART_MAP_SEL, P0_MEMBER, ENC_*, NBLK, NSBLK, TMW | no state | test-mode decode of 11.3: partition decode (P_PARTITIONED = 1); P_PARTITIONED = 0 is refused at elaboration (CONF-38 closed) [src: rtl/dft_mode_dec.sv] |
| dft_crg_ctl | dtr_cfg, sel, active | no state | CRG selects and enables, Rst_n_test [src: rtl/dft_crg_ctl.sv] |
| dft_ddr_tdr | P_TDR_EN_EDGE | en_q | LPDDR PHY TDR bridge [src: rtl/dft_ddr_tdr.sv] |
| dft_sms_srv | P_SMS_IR_LEN, P_SMS_IDCODE | no state | SMS shell with the dft_tap stub u_stub [src: rtl/dft_sms_srv.sv] |
| dft_scan_rtr | NPIN, NSBLK, NMODE, NCH, OFF, PIN_BASE, SO_VALID, SO_BLK, SO_CH, PART_MODE0, NWRAP, NTOP | no state | scan router of 12.1/12.3: gated scan-in fan-out; per lane a 4:1 over the INTEST modes, a 2:1 to the wrapper/TOP path under extest and a 2:1 for loopback, all dft_mux2 cells [src: rtl/dft_scan_rtr.sv] |
| dft_scan_hold | - | no state | withdrawn partial-build boundary: instantiated only under P_PARTITIONED = 0, which dft_mode_dec refuses at elaboration (CONF-38 closed); unreachable in every legal configuration [src: rtl/dft_scan_hold.sv] |
| dft_icg | - | no state | clock-gate cell (TDRCLK) [src: rtl/cells/dft_icg.sv] |
| dft_mux2 | - | no state | 2:1 mux cell: every test-control mux (router levels 1, 2 and loopback; Rst_n_test, lpddr_scan_rstn) [src: rtl/cells/dft_mux2.sv] |
| dft_rst_sync | - | sync_q | async-assert, sync-de-assert reset synchroniser cell (rst_dtr_n, lpddr_wrstn) [src: rtl/cells/dft_rst_sync.sv] |
| dft_sync2 | P_WIDTH | meta_q, sync_q | 2-flop synchroniser cell (DTR_STS inputs) [src: rtl/cells/dft_sync2.sv] |
| dft_dtr_reg | P_WIDTH, P_RESET, P_WMASK | sr_q, shadow_q | JTAG configuration data-register engine (u_cfg, u_lpddr) [src: rtl/dft_dtr_reg.sv] |
| dft_dtr_sts | P_WIDTH | sr_q | DTR_STS capture-only status register [src: rtl/dft_dtr_sts.sv] |
<!-- END SLOT: modules -->

**Table 6-2.** Module parameters

<!-- SLOT: module-parameters cite=each -->
| Module | Parameter | Default | Use |
|---|---|---|---|
| soc_dft | P_IDCODE | 1 | IDCODE value [src: rtl/soc_dft.sv:12] |
| soc_dft | P_OE_GATED | 1 | TDO1_OE gated per target [src: rtl/soc_dft.sv:13] |
| soc_dft | P_TM_OPEN | 1 | external-target TMS opened when DFTTM = 1 [src: rtl/soc_dft.sv:14] |
| soc_dft | P_DFTSO_HIZ_M0 | 1 | DFTSO_OE follows DFTTM [src: rtl/soc_dft.sv:15] |
| soc_dft | P_CFG_RST | 4194213 | DTR_CFG shadow reset value [src: rtl/soc_dft.sv:16] |
| soc_dft | P_LPDDR_RST | 0 | DTR_LPDDR shadow reset value [src: rtl/soc_dft.sv:17] |
| soc_dft | P_RTL_REV | 5 | DTR_STS.RTL_REV [src: rtl/soc_dft.sv:18] |
| soc_dft | P_TDR_EN_EDGE | 1 | TDR enable launch edge [src: rtl/soc_dft.sv:19] |
| soc_dft | P_DFTMAX_COMP | 1 | DFTMAX value that selects compression [src: rtl/soc_dft.sv:20] |
| soc_dft | P_SMS_IR_LEN | 4 | IR length of the SMS TAP stub [src: rtl/soc_dft.sv:21] |
| soc_dft | P_SMS_IDCODE | 65537 | IDCODE of the SMS TAP stub [src: rtl/soc_dft.sv:22] |
| soc_dft | P_PARTITIONED | 1 | 1 selects the full build (partition decode and dft_scan_rtr), the only legal value; 0, the partial build of 11.3, is withdrawn and refused at elaboration (CONF-38 closed) [src: rtl/soc_dft.sv:23] |
| dft_pad_if | P_DFTSO_HIZ_M0 | 1 | DFTSO_OE follows DFTTM [src: rtl/dft_pad_if.sv:8] |
| dft_pad_if | P_DFTMAX_COMP | 1 | DFTMAX value that selects compression [src: rtl/dft_pad_if.sv:9] |
| dft_jtag1_rtr | P_OE_GATED | 1 | TDO1_OE gated per target [src: rtl/dft_jtag1_rtr.sv:8] |
| dft_jtag1_rtr | P_TM_OPEN | 1 | external-target TMS opened when DFTTM = 1 [src: rtl/dft_jtag1_rtr.sv:9] |
| dft_tap | P_IR_LEN | 5 | IR length [src: rtl/dft_tap.sv:10] |
| dft_tap | P_DR_CLIENTS | 1 | 1 = DTR and DDRx codes decoded [src: rtl/dft_tap.sv:11] |
| dft_tap | P_IDCODE | 1 | IDCODE value [src: rtl/dft_tap.sv:12] |
| dft_dtr | P_CFG_RST | 4194213 | DTR_CFG shadow reset value [src: rtl/dft_dtr.sv:11] |
| dft_dtr | P_LPDDR_RST | 0 | DTR_LPDDR shadow reset value [src: rtl/dft_dtr.sv:12] |
| dft_dtr | P_RTL_REV | 5 | DTR_STS.RTL_REV [src: rtl/dft_dtr.sv:13] |
| dft_mode_dec | P_PARTITIONED | 1 | 1 selects the full build (partition decode and dft_scan_rtr), the only legal value; 0, the partial build of 11.3, is withdrawn and refused at elaboration (CONF-38 closed) [src: rtl/dft_mode_dec.sv:11] |
| dft_ddr_tdr | P_TDR_EN_EDGE | 1 | TDR enable launch edge [src: rtl/dft_ddr_tdr.sv:11] |
| dft_sms_srv | P_SMS_IR_LEN | 4 | IR length of the SMS TAP stub [src: rtl/dft_sms_srv.sv:10] |
| dft_sms_srv | P_SMS_IDCODE | 65537 | IDCODE of the SMS TAP stub [src: rtl/dft_sms_srv.sv:11] |
| dft_sync2 | P_WIDTH | 1 | register length [src: rtl/cells/dft_sync2.sv:6] |
| dft_dtr_reg | P_WIDTH | 32 | register length [src: rtl/dft_dtr_reg.sv:11] |
| dft_dtr_reg | P_RESET | 0 | shadow reset value [src: rtl/dft_dtr_reg.sv:12] |
| dft_dtr_reg | P_WMASK | 4294967295 | writable bits; 0 = reserved, reads 0 [src: rtl/dft_dtr_reg.sv:13] |
| dft_dtr_sts | P_WIDTH | 32 | register length [src: rtl/dft_dtr_sts.sv:8] |
<!-- END SLOT: module-parameters -->

**Table 6-3.** Derived constants

<!-- SLOT: derived-constants cite=each -->
| Module | Constant | Definition | Value at defaults |
|---|---|---|---|
| dft_tap | IR_IDCODE | - | - [src: rtl/dft_tap.sv:49] |
| dft_tap | IR_DTR_CFG | - | - [src: rtl/dft_tap.sv:50] |
| dft_tap | IR_DTR_LPDDR | - | - [src: rtl/dft_tap.sv:51] |
| dft_tap | IR_DTR_STS | - | - [src: rtl/dft_tap.sv:52] |
| dft_tap | IR_DDR0_CMD | - | - [src: rtl/dft_tap.sv:53] |
| dft_tap | IR_DDR1_RD | - | - [src: rtl/dft_tap.sv:54] |
| dft_dtr | IR_DTR_CFG | - | - [src: rtl/dft_dtr.sv:38] |
| dft_dtr | IR_DTR_LPDDR | - | - [src: rtl/dft_dtr.sv:39] |
| dft_dtr | IR_DTR_STS | - | - [src: rtl/dft_dtr.sv:40] |
| dft_dtr | CFG_WMASK | 32'h007F_FFFF | 8388607 [src: rtl/dft_dtr.sv:41] |
| dft_dtr | LPDDR_WMASK | 32'h0003_FFFF | 262143 [src: rtl/dft_dtr.sv:42] |
| dft_mode_dec | NBLK | dft_part_map_pkg::NBLK | - [src: rtl/dft_mode_dec.sv:39] |
| dft_mode_dec | NSBLK | dft_part_map_pkg::NSBLK | - [src: rtl/dft_mode_dec.sv:40] |
| dft_mode_dec | TMW | dft_part_map_pkg::TMW | - [src: rtl/dft_mode_dec.sv:41] |
| dft_mode_dec | B_LPDDR | dft_part_map_pkg::B_LPDDR | - [src: rtl/dft_mode_dec.sv:42] |
| dft_mode_dec | CFG_BURNIN | 4 | 4 [src: rtl/dft_mode_dec.sv:44] |
| dft_mode_dec | CFG_SE_GATE | 21 | 21 [src: rtl/dft_mode_dec.sv:45] |
| dft_mode_dec | LP_ATPG_MODE_OVR | 0 | 0 [src: rtl/dft_mode_dec.sv:46] |
| dft_mode_dec | LP_ATPG_MODE_VAL | 1 | 1 [src: rtl/dft_mode_dec.sv:47] |
| dft_mode_dec | LP_COMP_OVR | 2 | 2 [src: rtl/dft_mode_dec.sv:48] |
| dft_mode_dec | LP_COMP_VAL | 3 | 3 [src: rtl/dft_mode_dec.sv:49] |
| dft_mode_dec | LP_PHY0_BURNIN | 4 | 4 [src: rtl/dft_mode_dec.sv:50] |
| dft_mode_dec | LP_PHY1_BURNIN | 5 | 5 [src: rtl/dft_mode_dec.sv:51] |
| dft_mode_dec | LP_SCAN_SHIFT_CG | 17 | 17 [src: rtl/dft_mode_dec.sv:52] |
| dft_crg_ctl | CFG_PLL_BYP | 5 | 5 [src: rtl/dft_crg_ctl.sv:27] |
| dft_crg_ctl | CFG_RST_OVR | 6 | 6 [src: rtl/dft_crg_ctl.sv:28] |
| dft_crg_ctl | CFG_RST_VAL | 7 | 7 [src: rtl/dft_crg_ctl.sv:29] |
| dft_crg_ctl | CFG_BLK_CLK_EN | 8 | 8 [src: rtl/dft_crg_ctl.sv:30] |
| dft_ddr_tdr | IR_DDR0_CMD | - | - [src: rtl/dft_ddr_tdr.sv:33] |
| dft_ddr_tdr | IR_DDR0_RD | - | - [src: rtl/dft_ddr_tdr.sv:34] |
| dft_ddr_tdr | IR_DDR1_CMD | - | - [src: rtl/dft_ddr_tdr.sv:35] |
| dft_ddr_tdr | IR_DDR1_RD | - | - [src: rtl/dft_ddr_tdr.sv:36] |
| dft_ddr_tdr | ST_CAPTURE_DR | - | - [src: rtl/dft_ddr_tdr.sv:37] |
| dft_ddr_tdr | ST_SHIFT_DR | - | - [src: rtl/dft_ddr_tdr.sv:38] |
| dft_ddr_tdr | ST_UPDATE_DR | - | - [src: rtl/dft_ddr_tdr.sv:39] |
| dft_scan_rtr | NBLK | dft_part_map_pkg::NBLK | - [src: rtl/dft_scan_rtr.sv:29] |
| dft_scan_rtr | NPIN | dft_part_map_pkg::NPIN | - [src: rtl/dft_scan_rtr.sv:30] |
| dft_scan_rtr | NSBLK | dft_part_map_pkg::NSBLK | - [src: rtl/dft_scan_rtr.sv:31] |
| dft_scan_rtr | NWRAP | dft_part_map_pkg::NWRAP | - [src: rtl/dft_scan_rtr.sv:32] |
| dft_scan_rtr | NTOP | dft_part_map_pkg::NTOP | - [src: rtl/dft_scan_rtr.sv:33] |
| dft_scan_rtr | NMODE | dft_part_map_pkg::NMODE | - [src: rtl/dft_scan_rtr.sv:34] |
| dft_scan_rtr | PART_MODE0 | dft_part_map_pkg::PART_MODE0 | - [src: rtl/dft_scan_rtr.sv:35] |
| dft_scan_hold | HELD_VALUE | 1'b0 | 0 [src: rtl/dft_scan_hold.sv:21] |
| dft_icg | EN_OPEN | 1'b1 | 1 [src: rtl/cells/dft_icg.sv:13] |
| dft_mux2 | SEL_B | 1'b1 | 1 [src: rtl/cells/dft_mux2.sv:13] |
| dft_dtr_reg | RESET_V | - | - [src: rtl/dft_dtr_reg.sv:30] |
| dft_dtr_reg | WMASK_V | - | - [src: rtl/dft_dtr_reg.sv:31] |
<!-- END SLOT: derived-constants -->

**Table 6-4.** Method notes

<!-- SLOT: method-notes cite=each -->
| Module | Mechanism | Implemented at |
|---|---|---|
| dft_tap | next state of Table 45 on TMS | rtl/dft_tap.sv:83 [src: rtl/dft_tap.sv:83] |
| dft_tap | Capture-IR: 1; Shift-IR: {tdi, ir_sr_q[P_IR_LEN-1:1]} | rtl/dft_tap.sv:91 [src: rtl/dft_tap.sv:91] |
| dft_tap | Update-IR: ir_sr_q; TLR: 1 | rtl/dft_tap.sv:96 [src: rtl/dft_tap.sv:96] |
| dft_tap | Capture-DR with IDCODE: P_IDCODE; Shift-DR: shift | rtl/dft_tap.sv:125 [src: rtl/dft_tap.sv:125] |
| dft_tap | Capture-DR: 0; Shift-DR: tdi | rtl/dft_tap.sv:130 [src: rtl/dft_tap.sv:130] |
| dft_tap | Shift-IR: ir_sr_q[0]; Shift-DR: dr_tdo; else hold | rtl/dft_tap.sv:145 [src: rtl/dft_tap.sv:145] |
| dft_tap | (Shift-IR or Shift-DR) | rtl/dft_tap.sv:146 [src: rtl/dft_tap.sv:146] |
| dft_ddr_tdr | decoded from tap_state and ir, & ~tm, on the P_TDR_EN_EDGE edge | rtl/dft_ddr_tdr.sv:63 [src: rtl/dft_ddr_tdr.sv:63] |
| dft_rst_sync | sync_q <= {sync_q[0], 1'b1} | rtl/cells/dft_rst_sync.sv:17 [src: rtl/cells/dft_rst_sync.sv:17] |
| dft_sync2 | meta_q <= d_i | rtl/cells/dft_sync2.sv:15 [src: rtl/cells/dft_sync2.sv:15] |
| dft_sync2 | sync_q <= {sync_q[0], 1'b1} | rtl/cells/dft_sync2.sv:16 [src: rtl/cells/dft_sync2.sv:16] |
| dft_dtr_reg | Capture-DR & sel: shadow; Shift-DR & sel: {tdi, sr_q[W-1:1]} | rtl/dft_dtr_reg.sv:35 [src: rtl/dft_dtr_reg.sv:35] |
| dft_dtr_reg | Update-DR & ~tm: clr ? reset : sel ? sr_q & P_WMASK : hold | rtl/dft_dtr_reg.sv:39 [src: rtl/dft_dtr_reg.sv:39] |
| dft_dtr_sts | Capture-DR & sel: shadow; Shift-DR & sel: {tdi, sr_q[W-1:1]} | rtl/dft_dtr_sts.sv:20 [src: rtl/dft_dtr_sts.sv:20] |
<!-- END SLOT: method-notes -->

## 7. State machines

<!-- SLOT: fsms-lead cite=any -->
The RTL declares 1 enumerated type (tap_state_e, 16 values); this chapter states which of them are state machines, with their states, arcs and reset state [spec: 9.3] [spec: 9.1].
<!-- END SLOT: fsms-lead -->

<!-- SLOT: fsms cite=each -->
![TAP state machine](figures/fsm-tap.png)
**Figure 7-1.** The IEEE 1149.1 TAP state machine with the state codes of the specification's Table 45. [src: publication/figures/fsm-tap.dot]

The TAP holds one 16-state machine clocked on rising TCK1 and reset asynchronously to Test-Logic-Reset by TRSTN1; every state has one transition for TMS = 0 and one for TMS = 1, and all 16 codes of the 4-bit state are states [spec: 9.3].

The SMS TAP of this release is the same TAP with instruction length P_SMS_IR_LEN and only IDCODE and BYPASS, so the two devices of the chain always share one state [spec: 9.1] [spec: 14.6].
<!-- END SLOT: fsms -->

## 8. Registers

<!-- SLOT: registers-lead cite=any -->
This chapter is the register map: 6 rows in 1 table, each with its bits, reset value and access [spec: 9.4] [spec: 9.5].
<!-- END SLOT: registers-lead -->

<!-- SLOT: registers cite=each -->
![DTR_CFG register](figures/view-register.png)
**Figure 8-1.** DTR_CFG: shift stage, configuration stage, update and clear. [src: publication/figures/view-register.json]

The registers are JTAG data registers selected by the 5-bit instruction register of the SOC_DFT TAP; SOC_DFT has no memory-mapped register bus [spec: 9.4].

| IR code | Register | Length | Access and reset |
|---|---|---|---|
| 5'b00001 | IDCODE | 32 | capture P_IDCODE; selected after TRSTN1 and in Test-Logic-Reset [spec: 9.5] |
| 5'b00010 | DTR_CFG | 32 | read/write; reset to P_CFG_RST by PwrOk or CLR only [spec: 10.2] |
| 5'b00011 | DTR_LPDDR | 32 | read/write; reset to P_LPDDR_RST by PwrOk or CLR only [spec: 10.3] |
| 5'b00100 | DTR_STS | 32 | capture only: synchronised pad and PLL status, PART, NPART, RTL_REV [spec: 10.4] |
| 5'b00101 to 5'b01000 | DDR0_CMD, DDR0_RD, DDR1_CMD, DDR1_RD | set by the PHY | the LPDDR PHY TDRs [spec: 15.4] |
| 5'b11111 and every other code | BYPASS | 1 | capture 0 [spec: 9.4] |

DTR_CFG fields: PART [3:0] reset 5, BURNIN [4], PLL_BYP [5] reset 1, RST_OVR [6], RST_VAL [7] reset 1, BLK_CLK_EN [20:8] reset 13'h1FFF, SE_GATE [21] reset 1, DDR_TDR_EN [22], bits 30:23 reserved and read 0, CLR [31] self-clearing and read 0 [spec: 10.2].

DTR_LPDDR fields: ATPG_MODE_OVR [0], ATPG_MODE_VAL [1], COMP_OVR [2], COMP_VAL [3], PHY0_BURNIN [4], PHY1_BURNIN [5], SFP_DFT_MODE [6], RING_BYPASS [13:7], SMS_DM [16:14], SCAN_SHIFT_CG_OVR [17], bits 31:18 reserved and read 0 [spec: 10.3].
<!-- END SLOT: registers -->

## 9. Error behaviour

<!-- SLOT: errors-lead cite=any -->
soc_dft states 6 error conditions and the response to each; a condition with no row here has no defined response [spec: 9.4] [spec: 8.1].
<!-- END SLOT: errors-lead -->

**Table 9-1.** Errors

<!-- SLOT: errors cite=each -->
| Condition | Response |
|---|---|
| An instruction code outside the decoded set is loaded | BYPASS is selected [spec: 9.4] |
| DFTTM rises while the TAP chain is in a DR state | the SOC_DFT TAP is driven to Test-Logic-Reset and the register updates, CLR and the PHY TDR enables are blocked while DFTTM = 1 [spec: 8.1] [spec: 10.6] |
| A reserved register bit is written | the write is ignored and the bit reads 0 [spec: 10.2] |
| DTR_STS is updated | nothing changes; DTR_STS is capture only [spec: 10.4] |
| PART selects no test mode (5 to 14) | no block is selected: every block is parked and every scan output stays 0 [spec: 12.3] |
| A DR scan longer than the register is shifted | the extra bits leave on TDO1 and Update-DR keeps the last bits shifted [spec: 9.8] |
<!-- END SLOT: errors -->

## 10. Integration contract

<!-- SLOT: integration-lead cite=any -->
Integrating soc_dft means connecting its 174 ports in pad (11), clock and reset (4), jtag targets (9), blocks (99), top glue (3), sms (18), lpddr (22), crg (8), driving its clock input TCK1 and its reset input TRSTN1 from outside soc_dft (clk_i and rst_ni are internal, and nobody outside soc_dft drives them), as chapter 4 states, and meeting 9 obligations below, owned by integrator, soc_dft, tester. The order of work is the walk of section 5.1, from step 1 to step 7, which chapter 13 states as a procedure [spec: 24.2] [spec: 24.3].
<!-- END SLOT: integration-lead -->

**Table 10-1.** Integration signals

<!-- SLOT: integration-signals cite=each -->
| Signal | Class | Integrator action |
|---|---|---|
| TCK1 (clock) | external input | drive it [src: rtl/soc_dft.sv] |
| clk_i (clock) | internal | none; it never leaves the design [src: rtl/soc_dft.sv] |
| TRSTN1 (reset) | external input | drive it [src: rtl/soc_dft.sv] |
| rst_ni (reset) | internal | none; it never leaves the design [src: rtl/soc_dft.sv] |
| the other 50 input ports (chapter 3 lists each) | external input | drive it [src: rtl/soc_dft.sv] |
| the other 122 output ports (chapter 3 lists each) | generated output | connect it; never drive it [src: rtl/soc_dft.sv] |
<!-- END SLOT: integration-signals -->

**Table 10-2.** Integration

<!-- SLOT: integration cite=each -->
| Obligation | Owner |
|---|---|
| Drive TCK1 from the TCK1 pad tree; it is a clock net built by CTS, 20 MHz maximum, 10 MHz while a DDRx instruction is loaded | integrator [spec: 24.2] |
| Drive TRSTN1 from the TRSTN1 pad, the same net that resets every TAP and SMS processor | integrator [spec: 24.3] |
| Drive PwrOk from the PwrOk pad; it resets the test data registers | integrator [spec: 24.2] |
| Drive Rstn from the Rstn pad; it is the source of dft_crg_rst_n_test | integrator [spec: 24.2] |
| Do not drive rst_dtr_n: it is internal to soc_dft, produced by its reset synchroniser | soc_dft [spec: 7.3] |
| Connect lpddr_tdrclk and lpddr_wrstn to the PHY TDRCLK and WRSTN inputs; both are soc_dft outputs and are never driven from outside | integrator [spec: 24.4] |
| Connect every soc_dft port per Section 24 of the specification, with no logic and no tie-off at the chip top | integrator [spec: 24.1] [spec: 24.6] |
| Build the clock and reset test structure that the dft_crg_* outputs steer: root muxes, per-block clock gates, reset bypass | integrator [spec: 13.3] |
| Change DFTTM only while Rstn = 0 and the TAP chain is in Test-Logic-Reset or Run-Test/Idle | tester [spec: 5.4] |
<!-- END SLOT: integration -->

<!-- SLOT: integration-detail cite=any -->
The chip top sets P_IDCODE only; every other parameter keeps the delivered default [spec: 24.9]. The TDRCLK clock gate is the instance u_soc_dft/u_ddr_tdr/u_dft_icg_tdrclk_dont_touch and the two reset muxes are u_soc_dft/u_crg_ctl/u_dft_mux2_rst_dont_touch and u_dft_mux2_scan_rstn_dont_touch, and every scan router selection is a dont_touch dft_mux2 instance under the scan router; constraints and equivalence checking address these paths [spec: 24.7] [spec: 24.11].
<!-- END SLOT: integration-detail -->

## 11. Verification status

<!-- SLOT: verification-lead cite=any -->
Simulated on 2 simulator(s), icarus, verilator: both verdicts and metrics match [src: reports/dual-sim.json]. This chapter states 8 verification claims: 1 row carries a verdict, 1 of them PASS, and 7 rows state a measured figure; each row gives its state as measured [src: reports/dual-sim.json] [src: reports/mutation-summary.json].
<!-- END SLOT: verification-lead -->

**Table 11-1.** Verification

<!-- SLOT: verification cite=each -->
| Claim | State |
|---|---|
| the bench, 10 test(s) | 675 checks, PASS [src: reports/dual-sim.json] |
| mutation | 49 killed of 50, 1 survived [src: reports/mutation-summary.json] |
| formal | 15 proved, 0 failed, controls 6 of 6 refuted [src: reports/formal-summary.json] |
| coverage branch_percent | 96.1 [src: reports/coverage.json] |
| coverage expr_percent | 96.23 [src: reports/coverage.json] |
| coverage line_percent | 97.47 [src: reports/coverage.json] |
| coverage measured_by | verilator [src: reports/coverage.json] |
| coverage toggle_percent | 84.63 [src: reports/coverage.json] |
<!-- END SLOT: verification -->

## 12. Limitations and open items

<!-- SLOT: limitations-lead cite=any -->
This chapter states 17 limitations and open items: what this revision does not cover and what is still open [src: declarations/dispositions.json] [src: declarations/adm.json].
<!-- END SLOT: limitations-lead -->

<!-- SLOT: limitations cite=each -->
The mandatory feature LPDDR PHY TDR bridge is recorded MODEL_ONLY; the record cited carries the basis for that disposition [src: declarations/dispositions.json].

The mandatory feature SMS shell and two-device chain is recorded EXTERNAL_DEPENDENCY; the record cited carries the basis for that disposition [src: declarations/dispositions.json].

The mandatory feature Technology cells and sequential inventory is recorded MODEL_ONLY; the record cited carries the basis for that disposition [src: declarations/dispositions.json].

An engineering assumption stands in for a confirmation its owner has yet to give; the register cited carries the issue it records and the value the design implements [src: declarations/adm.json].

A timing question of the source stands at weakly_held; the register cited carries the question [src: declarations/adm.json].

The evidence for dft:atpg_coverage stands at blocked, so what it backs is still open [src: .sdip/evidence_ledger.jsonl].

The evidence for dft:gate_level stands at blocked, so what it backs is still open [src: .sdip/evidence_ledger.jsonl].

The evidence for dft:lpddr_tdr_phy stands at blocked, so what it backs is still open [src: .sdip/evidence_ledger.jsonl].

The evidence for dft:sms_mbist stands at blocked, so what it backs is still open [src: .sdip/evidence_ledger.jsonl].

The evidence for dft:transition stands at blocked, so what it backs is still open [src: .sdip/evidence_ledger.jsonl].

The evidence for documents stands at partial, so what it backs is still open [src: .sdip/evidence_ledger.jsonl].

The evidence for dv:close stands at fail, so what it backs is still open [src: .sdip/evidence_ledger.jsonl].

The evidence for mutant:m_dec_in_range stands at fail, so what it backs is still open [src: .sdip/evidence_ledger.jsonl].

The evidence for mutation stands at fail, so what it backs is still open [src: .sdip/evidence_ledger.jsonl].

The evidence for rtl_checks stands at fail, so what it backs is still open [src: .sdip/evidence_ledger.jsonl].

The evidence for spec_checks:dv stands at not_run, so what it backs is still open [src: .sdip/evidence_ledger.jsonl].

The evidence for stage_audit:dft stands at blocked, so what it backs is still open [src: .sdip/evidence_ledger.jsonl].
<!-- END SLOT: limitations -->

## 13. Software flow

<!-- SLOT: software-flow cite=each -->
Driving soc_dft is the sequence below, 7 steps taken from the cycle walk of section 5.1: what to drive, what the design does in response, and what to read back [spec: 9.3] [spec: 10.6].

1. Step 1: drive TMS = 1; from RUN_TEST_IDLE the design writes TAP state; read state SELECT_DR_SCAN; TDO1 not enabled [spec: 9.3].
2. Step 2: drive TMS = 0; from SELECT_DR_SCAN the design writes TAP state; read state CAPTURE_DR [spec: 9.3].
3. Step 3: drive TMS = 0; from CAPTURE_DR the design writes DTR_CFG shift stage loads the current configuration; read state SHIFT_DR [spec: 10.6].
4. Step 4: drive TMS = 0, TDI bit 0; from SHIFT_DR the design writes shift stage shifts toward TDO; read TDO1 carries the old bit 0 [spec: 9.6].
5. Step 5: drive TMS = 1, TDI bit 31; from SHIFT_DR the design writes shift stage holds the 32 new bits; read state EXIT1_DR [spec: 9.3].
6. Step 6: drive TMS = 1; from EXIT1_DR the design writes TAP state; read state UPDATE_DR [spec: 9.3].
7. Step 7: drive TMS = 0, DFTTM = 0; from UPDATE_DR the design writes DTR_CFG configuration loads on falling TCK1; read every control derived from DTR_CFG changes [spec: 10.6].
<!-- END SLOT: software-flow -->

## 14. Glossary

**Table 14-1.** Glossary

<!-- SLOT: glossary cite=each -->
| Term | Meaning |
|---|---|
| soc_dft | top: instances of Table 21; the router (g_scan_rtr, P_PARTITIONED = 1); the g_scan_hold branch with dft_scan_hold is unreachable, P_PARTITIONED = 0 being refused at elaboration (CONF-38 closed); per-block slices of the router's flat channel buses [src: rtl/soc_dft.sv] |
| dft_pad_if | pad buffers, DFTSO_OE, dftmax_i, rst_dtr_n [src: rtl/dft_pad_if.sv] |
| dft_jtag1_rtr | TSEL1 decode, TMS gating, TDO1 mux [src: rtl/dft_jtag1_rtr.sv] |
| dft_tap | IEEE 1149.1 TAP (also the SMS stub under dft_sms_srv) [src: rtl/dft_tap.sv] |
| dft_dtr | DTR_CFG, DTR_LPDDR, DTR_STS host [src: rtl/dft_dtr.sv] |
| dft_mode_dec | test-mode decode of 11.3: partition decode (P_PARTITIONED = 1); P_PARTITIONED = 0 is refused at elaboration (CONF-38 closed) [src: rtl/dft_mode_dec.sv] |
| dft_crg_ctl | CRG selects and enables, Rst_n_test [src: rtl/dft_crg_ctl.sv] |
| dft_ddr_tdr | LPDDR PHY TDR bridge [src: rtl/dft_ddr_tdr.sv] |
| dft_sms_srv | SMS shell with the dft_tap stub u_stub [src: rtl/dft_sms_srv.sv] |
| dft_scan_rtr | scan router of 12.1/12.3: gated scan-in fan-out; per lane a 4:1 over the INTEST modes, a 2:1 to the wrapper/TOP path under extest and a 2:1 for loopback, all dft_mux2 cells [src: rtl/dft_scan_rtr.sv] |
| dft_scan_hold | withdrawn partial-build boundary: instantiated only under P_PARTITIONED = 0, which dft_mode_dec refuses at elaboration (CONF-38 closed); unreachable in every legal configuration [src: rtl/dft_scan_hold.sv] |
| dft_icg | clock-gate cell (TDRCLK) [src: rtl/cells/dft_icg.sv] |
| dft_mux2 | 2:1 mux cell: every test-control mux (router levels 1, 2 and loopback; Rst_n_test, lpddr_scan_rstn) [src: rtl/cells/dft_mux2.sv] |
| dft_rst_sync | async-assert, sync-de-assert reset synchroniser cell (rst_dtr_n, lpddr_wrstn) [src: rtl/cells/dft_rst_sync.sv] |
| dft_sync2 | 2-flop synchroniser cell (DTR_STS inputs) [src: rtl/cells/dft_sync2.sv] |
| dft_dtr_reg | JTAG configuration data-register engine (u_cfg, u_lpddr) [src: rtl/dft_dtr_reg.sv] |
| dft_dtr_sts | DTR_STS capture-only status register [src: rtl/dft_dtr_sts.sv] |
| TCK1 | clock, from TCK1 pad (CTS net), integrator, rising and falling edge [src: rtl/soc_dft.sv] |
| clk_i | clock, from module clock port of the cells and the DTR engines; bound to TCK1 (u_cfg, u_lpddr, u_sts, u_dft_sync2_sts_dont_touch, u_dft_rst_sync_dtr_dont_touch) or to lpddr_tdrclk (u_dft_rst_sync_wrstn_dont_touch); for u_dft_icg_tdrclk_dont_touch it is the gated input TCK1, rising (dft_dtr_reg shadow: falling) edge [src: rtl/soc_dft.sv] |
| TRSTN1 | reset, active low, asynchronous assert and de-assert [src: rtl/soc_dft.sv:36] |
| rst_ni | reset, active low, asynchronous assert [src: rtl/soc_dft.sv] |
| TDRCLK | clock-gate cell [src: rtl/soc_dft.sv] |
| CONF-nn | a configuration value the specification adopts as its baseline while its owner confirms it; the design implements the baseline at the sites the edition names [src: rtl/soc_dft.sv] |
<!-- END SLOT: glossary -->

## List of figures

<!-- SLOT: figures cite=each -->
| Figure | Title | Source | Render |
|---|---|---|---|
| Figure 1-1 | SOC_DFT top level: the delivered instances and the eight boundary groups. | [src: publication/figures/view-overview.json] | [src: publication/figures/view-overview.png] |
| Figure 1-2 | soc_dft hierarchy: the delivered instances and, dashed, the boundary of the withdrawn partial build (P_PARTITIONED = 0, refused at elaboration). | [src: publication/figures/top-diagram.dot] | [src: publication/figures/top-diagram.png] |
| Figure 4-1 | Clocks, resets and crossings: every crossing passes one synchroniser or gating cell. | [src: publication/figures/view-clock-reset.json] | [src: publication/figures/view-clock-reset.png] |
| Figure 5-1 | The TSEL1 = 11 chain: TDI1 through the SMS TAP and the SOC_DFT TAP to TDO1. | [src: publication/figures/view-serial.json] | [src: publication/figures/view-serial.png] |
| Figure 5-2 | Scan channel routing: DFTSI through the gated fan-out to the block channels, and the block scan-outs back through the per-lane mode, EXTEST and loopback selections to DFTSO. | [src: publication/figures/view-scan.json] | [src: publication/figures/view-scan.png] |
| Figure 5-3 | One DR scan of DTR_CFG: the configuration changes on the falling TCK1 of Update-DR, and only while DFTTM = 0. | [src: publication/figures/wave-dtr-update.json] | [src: publication/figures/wave-dtr-update.png] |
| Figure 6-1 | Configuration and control path: pins and DTR shadows to the block and CRG controls | [src: publication/figures/view-control.json] | [src: publication/figures/view-control.png] |
| Figure 7-1 | The IEEE 1149.1 TAP state machine with the state codes of the specification's Table 45. | [src: publication/figures/fsm-tap.dot] | [src: publication/figures/fsm-tap.png] |
| Figure 8-1 | DTR_CFG: shift stage, configuration stage, update and clear. | [src: publication/figures/view-register.json] | [src: publication/figures/view-register.png] |
<!-- END SLOT: figures -->

## List of tables

<!-- SLOT: tables cite=none -->
| Table | Subject |
|---|---|
| Table 2-1 | Configuration |
| Table 3-1 | Ports |
| Table 4-1 | Clocks |
| Table 4-2 | Resets |
| Table 5-1 | Storage |
| Table 5-2 | Walk |
| Table 6-1 | Modules |
| Table 6-2 | Module parameters |
| Table 6-3 | Derived constants |
| Table 6-4 | Method notes |
| Table 9-1 | Errors |
| Table 10-1 | Integration signals |
| Table 10-2 | Integration |
| Table 11-1 | Verification |
| Table 14-1 | Glossary |
| Table 14-2 | Revisions |
<!-- END SLOT: tables -->

## Revision history

**Table 14-2.** Revisions

<!-- SLOT: revisions cite=each -->
| Revision | Date | Change | Basis |
|---|---|---|---|
| 0.1 | 2026-10-16 | architecture-stage edition from the design record; the RTL-derived and verification sections are marked pending, the limitations written from the records of this stage | [src: declarations/publication-records.json] |
| 0.2 | 2026-10-16 | RTL-derived sections regenerated from the RTL sources, prose from the design record | [src: declarations/publication-records.json] |
| 0.3 | 2026-10-16 | verification status regenerated from the verification reports | [src: declarations/publication-records.json] |
<!-- END SLOT: revisions -->
