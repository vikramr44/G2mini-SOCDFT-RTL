// Artifact identity: Verification plan and results
// tb_soc_dft: full-depth bench of soc_dft (DV depth full). It carries t_reset_startup,
// t_reset_occupied, t_connectivity and one test per port group, and it is parameterised:
// the bench takes every soc_dft parameter under the same name, type and default and passes
// each to u_dut, so the parameter sweep (REQ-30) overrides the bench top. Every expected
// value is written from the spec r0.92 equations (Table 82, 7.3, 8.4, 9.4, 10.2 to 10.4,
// 11.3, 13.2, 14.6, 15.4) and the generated map, as a function of these parameters where
// the spec makes it one; checkers sample on the bench's TCK1 (canon D80). Tests announce
// themselves as 'TEST START <t>' / 'TEST PASS <t>' / 'TEST FAIL <t>'; the run ends
// 'RESULT PASS|FAIL'.
`timescale 1ns/1ps
`default_nettype none
module tb_soc_dft
#(
  parameter int unsigned P_IDCODE       = 32'h0000_0001,  // CONF-10
  parameter bit          P_OE_GATED     = 1'b1,           // CONF-07
  parameter bit          P_TM_OPEN      = 1'b1,           // 8.4
  parameter bit          P_DFTSO_HIZ_M0 = 1'b1,           // CONF-03
  parameter int unsigned P_CFG_RST      = 32'h003F_FFA5,  // CONF-06 (10.2)
  parameter int unsigned P_LPDDR_RST    = 32'h0000_0000,  // CONF-26 (10.3)
  parameter int unsigned P_RTL_REV      = 32'h05,         // Table 82 default
  parameter bit          P_TDR_EN_EDGE  = 1'b1,           // CONF-25
  parameter bit          P_DFTMAX_COMP  = 1'b1,           // CONF-39
  parameter int          P_SMS_IR_LEN   = 4,              // CONF-40
  parameter int unsigned P_SMS_IDCODE   = 32'h0001_0001,
  parameter bit          P_PARTITIONED  = 1'b1            // 11.3: 1 full build, 0 partial build
);
  localparam int TCK_HALF = 25;                       // 20 MHz TCK1 (spec 6.7)
  localparam logic [31:0] IDCODE     = P_IDCODE;      // dft_tap IDCODE (9.5)
  localparam logic [31:0] SMS_IDCODE = P_SMS_IDCODE;  // SMS TAP stub IDCODE (14.6)
  localparam logic [31:0] CFG_RST    = P_CFG_RST;     // DTR_CFG shadow reset value (10.2)
  localparam logic [31:0] LPDDR_RST  = P_LPDDR_RST;   // DTR_LPDDR shadow reset value (10.3)
  localparam logic [31:0] CFG_WMASK  = 32'h007F_FFFF; // DTR_CFG stored bits: 30:23 reserved, 31 CLR (Table 50)
  localparam logic [31:0] LPDDR_WMASK = 32'h0003_FFFF; // DTR_LPDDR stored bits: 31:18 reserved (Table 51)
  localparam logic [31:0] CFG_RV     = CFG_RST & CFG_WMASK;      // DTR_CFG read-back after reset or CLR
  localparam logic [31:0] LPDDR_RV   = LPDDR_RST & LPDDR_WMASK;  // DTR_LPDDR read-back after reset or CLR
  localparam logic [7:0]  RTL_REV    = P_RTL_REV[7:0];  // DTR_STS[23:16] (10.4)
  // The DTR_CFG word the mode tests program (with their PART or field written over it):
  // the Table 50 default value, BLK_CLK_EN = 13'h1FFF, SE_GATE = 1, PLL_BYP = 1,
  // RST_OVR = 0. It is written over JTAG, so those tests' expectations hold for any
  // P_CFG_RST; P_CFG_RST itself is checked where the reset value is what is in force.
  localparam logic [31:0] CFG_TEST   = 32'h003F_FFA5;
  // DFTMAX level that selects compression and the one that selects scan (7.3, CONF-39)
  localparam bit DMAX_COMP = P_DFTMAX_COMP;
  localparam bit DMAX_SCAN = !P_DFTMAX_COMP;
  // DFTSO_OE in M0 (DFTTM = 0): 0 (Hi-Z) with P_DFTSO_HIZ_M0 = 1, else 1 (7.3, 17)
  localparam bit M0_DFTSO_OE = !P_DFTSO_HIZ_M0;
  // IR length of the TSEL1 = 11 chain: dft_tap (5, nearest TDO1) then the SMS TAP stub (9.4, 14.6)
  localparam int IR_CHAIN = 5 + P_SMS_IR_LEN;
  // block test-mode code: the routed value in the full build, ENC_FUNC in the partial build (11.3)
  function automatic logic [3:0] rtm(input logic [3:0] code);
    return P_PARTITIONED ? code : dft_part_map_pkg::ENC_FUNC[3:0];
  endfunction
  // the blocks a PART selects / makes active with DFTTM = 1 (11.3; 13'h0 in the partial build)
  function automatic logic [12:0] exp_sel(input logic [3:0] part);
    if (!P_PARTITIONED || part < 4'd1 || part > 4'd14) return 13'h0;
    return dft_part_map_pkg::PART_MAP_SEL[13*part +: 13];
  endfunction
  function automatic logic [12:0] exp_active(input logic [3:0] part);
    if (!P_PARTITIONED) return 13'h0;
    return exp_sel(part) | ((part == dft_part_map_pkg::PART_EXTEST) ? dft_part_map_pkg::P0_MEMBER : 13'h0);
  endfunction

  // ---------------------------------------------------------------- DUT inputs
  logic DFTTM;
  logic DFTMAX;
  logic DFTSE;
  logic [19:0] DFTSI;
  logic [1:0] TSEL1;
  logic TCK1;
  logic TMS1;
  logic TDI1;
  logic TRSTN1;
  logic PwrOk;
  logic Rstn;
  logic arc_tdo1;
  logic arc_tdo1_oe;
  logic pcia_tdo1;
  logic pcia_tdo1_oe;
  logic pcib_tdo1;
  logic pcib_tdo1_oe;
  logic [4:0] scc_test_so;
  logic [1:0] scc_wrap_so;
  logic [4:0] hic_test_so;
  logic [1:0] hic_wrap_so;
  logic [5:0] g2muc_test_so;
  logic [1:0] g2muc_wrap_so;
  logic [2:0] l4ga_test_so;
  logic [1:0] l4ga_wrap_so;
  logic [2:0] l4gb_test_so;
  logic [1:0] l4gb_wrap_so;
  logic [19:0] pcia_test_so;
  logic [1:0] pcia_wrap_so;
  logic [19:0] pcib_test_so;
  logic [1:0] pcib_wrap_so;
  logic [5:0] ahb_test_so;
  logic [1:0] ahb_wrap_so;
  logic [3:0] apb_test_so;
  logic [1:0] apb_wrap_so;
  logic [2:0] axis_test_so;
  logic [1:0] axis_wrap_so;
  logic [3:0] axim_test_so;
  logic [1:0] axim_wrap_so;
  logic [2:0] top_test_so;
  logic scc_sms_out;
  logic hic_sms_out;
  logic g2muc_sms_out;
  logic l4ga_sms_out;
  logic l4gb_sms_out;
  logic ahb_sms_out;
  logic lpddr_sms_out;
  logic [1:0] pcia_sms_out;
  logic [1:0] pcib_sms_out;
  logic [1:0] lpddr_cmd_tdr_tdo;
  logic [1:0] lpddr_rd_tdr_tdo;
  logic [2:0] crg_pll_ready;
  // ---------------------------------------------------------------- DUT outputs
  wire [19:0] DFTSO;
  wire DFTSO_OE;
  wire TDO1;
  wire TDO1_OE;
  wire arc_tms1;
  wire pcia_tms1;
  wire pcib_tms1;
  wire scc_dfttm;
  wire scc_scan_shift_en;
  wire scc_wrap_shift_en;
  wire scc_test_mode_tp;
  wire [3:0] scc_test_mode;
  wire [4:0] scc_test_si;
  wire [1:0] scc_wrap_si;
  wire hic_dfttm;
  wire hic_scan_shift_en;
  wire hic_wrap_shift_en;
  wire hic_test_mode_tp;
  wire [3:0] hic_test_mode;
  wire [4:0] hic_test_si;
  wire [1:0] hic_wrap_si;
  wire g2muc_dfttm;
  wire g2muc_scan_shift_en;
  wire g2muc_wrap_shift_en;
  wire g2muc_test_mode_tp;
  wire [3:0] g2muc_test_mode;
  wire [5:0] g2muc_test_si;
  wire [1:0] g2muc_wrap_si;
  wire l4ga_dfttm;
  wire l4ga_scan_shift_en;
  wire l4ga_wrap_shift_en;
  wire l4ga_test_mode_tp;
  wire [3:0] l4ga_test_mode;
  wire [2:0] l4ga_test_si;
  wire [1:0] l4ga_wrap_si;
  wire l4gb_dfttm;
  wire l4gb_scan_shift_en;
  wire l4gb_wrap_shift_en;
  wire l4gb_test_mode_tp;
  wire [3:0] l4gb_test_mode;
  wire [2:0] l4gb_test_si;
  wire [1:0] l4gb_wrap_si;
  wire pcia_dfttm;
  wire pcia_scan_shift_en;
  wire pcia_wrap_shift_en;
  wire pcia_test_mode_tp;
  wire [3:0] pcia_test_mode;
  wire [19:0] pcia_test_si;
  wire [1:0] pcia_wrap_si;
  wire pcib_dfttm;
  wire pcib_scan_shift_en;
  wire pcib_wrap_shift_en;
  wire pcib_test_mode_tp;
  wire [3:0] pcib_test_mode;
  wire [19:0] pcib_test_si;
  wire [1:0] pcib_wrap_si;
  wire ahb_dfttm;
  wire ahb_scan_shift_en;
  wire ahb_wrap_shift_en;
  wire ahb_test_mode_tp;
  wire [3:0] ahb_test_mode;
  wire [5:0] ahb_test_si;
  wire [1:0] ahb_wrap_si;
  wire apb_dfttm;
  wire apb_scan_shift_en;
  wire apb_wrap_shift_en;
  wire apb_test_mode_tp;
  wire [3:0] apb_test_mode;
  wire [3:0] apb_test_si;
  wire [1:0] apb_wrap_si;
  wire axis_dfttm;
  wire axis_scan_shift_en;
  wire axis_wrap_shift_en;
  wire axis_test_mode_tp;
  wire [3:0] axis_test_mode;
  wire [2:0] axis_test_si;
  wire [1:0] axis_wrap_si;
  wire axim_dfttm;
  wire axim_scan_shift_en;
  wire axim_wrap_shift_en;
  wire axim_test_mode_tp;
  wire [3:0] axim_test_mode;
  wire [3:0] axim_test_si;
  wire [1:0] axim_wrap_si;
  wire top_scan_shift_en;
  wire [2:0] top_test_si;
  wire [4:0] scc_sms_in;
  wire [4:0] hic_sms_in;
  wire [4:0] g2muc_sms_in;
  wire [4:0] l4ga_sms_in;
  wire [4:0] l4gb_sms_in;
  wire [4:0] ahb_sms_in;
  wire [4:0] lpddr_sms_in;
  wire [9:0] pcia_sms_in;
  wire [9:0] pcib_sms_in;
  wire lpddr_atpg_mode;
  wire lpddr_compression_mode;
  wire lpddr_phy0_burnin;
  wire lpddr_phy1_burnin;
  wire [15:0] lpddr_atpg_se;
  wire [1:0] lpddr_scan_ctl;
  wire lpddr_scan_shift_cg;
  wire lpddr_scan_rstn;
  wire [2:0] lpddr_sms_dm;
  wire [6:0] lpddr_ring_bypass;
  wire lpddr_sfp_dft_mode;
  wire lpddr_tdrclk;
  wire lpddr_wrstn;
  wire [1:0] lpddr_cmd_tdr_capture_en;
  wire [1:0] lpddr_cmd_tdr_shift_en;
  wire [1:0] lpddr_cmd_tdr_update_en;
  wire [1:0] lpddr_rd_tdr_capture_en;
  wire [1:0] lpddr_rd_tdr_shift_en;
  wire [1:0] lpddr_rd_tdr_update_en;
  wire [1:0] lpddr_wsi;
  wire dft_crg_test_clk_sel;
  wire dft_crg_rst_byp;
  wire dft_crg_rst_n_test;
  wire [2:0] dft_crg_pll_byp;
  wire [12:0] dft_crg_blk_clk_en;
  wire [12:0] dft_crg_comp_clk_en;
  wire [4:0] dft_crg_lpddr_clk_en;

  soc_dft #(
    .P_IDCODE(P_IDCODE),
    .P_OE_GATED(P_OE_GATED),
    .P_TM_OPEN(P_TM_OPEN),
    .P_DFTSO_HIZ_M0(P_DFTSO_HIZ_M0),
    .P_CFG_RST(P_CFG_RST),
    .P_LPDDR_RST(P_LPDDR_RST),
    .P_RTL_REV(P_RTL_REV),
    .P_TDR_EN_EDGE(P_TDR_EN_EDGE),
    .P_DFTMAX_COMP(P_DFTMAX_COMP),
    .P_SMS_IR_LEN(P_SMS_IR_LEN),
    .P_SMS_IDCODE(P_SMS_IDCODE),
    .P_PARTITIONED(P_PARTITIONED)
  ) u_dut (
    .DFTTM(DFTTM),
    .DFTMAX(DFTMAX),
    .DFTSE(DFTSE),
    .DFTSI(DFTSI),
    .DFTSO(DFTSO),
    .DFTSO_OE(DFTSO_OE),
    .TSEL1(TSEL1),
    .TCK1(TCK1),
    .TMS1(TMS1),
    .TDI1(TDI1),
    .TRSTN1(TRSTN1),
    .TDO1(TDO1),
    .TDO1_OE(TDO1_OE),
    .PwrOk(PwrOk),
    .Rstn(Rstn),
    .arc_tms1(arc_tms1),
    .pcia_tms1(pcia_tms1),
    .pcib_tms1(pcib_tms1),
    .arc_tdo1(arc_tdo1),
    .arc_tdo1_oe(arc_tdo1_oe),
    .pcia_tdo1(pcia_tdo1),
    .pcia_tdo1_oe(pcia_tdo1_oe),
    .pcib_tdo1(pcib_tdo1),
    .pcib_tdo1_oe(pcib_tdo1_oe),
    .scc_dfttm(scc_dfttm),
    .scc_scan_shift_en(scc_scan_shift_en),
    .scc_wrap_shift_en(scc_wrap_shift_en),
    .scc_test_mode_tp(scc_test_mode_tp),
    .scc_test_mode(scc_test_mode),
    .scc_test_si(scc_test_si),
    .scc_test_so(scc_test_so),
    .scc_wrap_si(scc_wrap_si),
    .scc_wrap_so(scc_wrap_so),
    .hic_dfttm(hic_dfttm),
    .hic_scan_shift_en(hic_scan_shift_en),
    .hic_wrap_shift_en(hic_wrap_shift_en),
    .hic_test_mode_tp(hic_test_mode_tp),
    .hic_test_mode(hic_test_mode),
    .hic_test_si(hic_test_si),
    .hic_test_so(hic_test_so),
    .hic_wrap_si(hic_wrap_si),
    .hic_wrap_so(hic_wrap_so),
    .g2muc_dfttm(g2muc_dfttm),
    .g2muc_scan_shift_en(g2muc_scan_shift_en),
    .g2muc_wrap_shift_en(g2muc_wrap_shift_en),
    .g2muc_test_mode_tp(g2muc_test_mode_tp),
    .g2muc_test_mode(g2muc_test_mode),
    .g2muc_test_si(g2muc_test_si),
    .g2muc_test_so(g2muc_test_so),
    .g2muc_wrap_si(g2muc_wrap_si),
    .g2muc_wrap_so(g2muc_wrap_so),
    .l4ga_dfttm(l4ga_dfttm),
    .l4ga_scan_shift_en(l4ga_scan_shift_en),
    .l4ga_wrap_shift_en(l4ga_wrap_shift_en),
    .l4ga_test_mode_tp(l4ga_test_mode_tp),
    .l4ga_test_mode(l4ga_test_mode),
    .l4ga_test_si(l4ga_test_si),
    .l4ga_test_so(l4ga_test_so),
    .l4ga_wrap_si(l4ga_wrap_si),
    .l4ga_wrap_so(l4ga_wrap_so),
    .l4gb_dfttm(l4gb_dfttm),
    .l4gb_scan_shift_en(l4gb_scan_shift_en),
    .l4gb_wrap_shift_en(l4gb_wrap_shift_en),
    .l4gb_test_mode_tp(l4gb_test_mode_tp),
    .l4gb_test_mode(l4gb_test_mode),
    .l4gb_test_si(l4gb_test_si),
    .l4gb_test_so(l4gb_test_so),
    .l4gb_wrap_si(l4gb_wrap_si),
    .l4gb_wrap_so(l4gb_wrap_so),
    .pcia_dfttm(pcia_dfttm),
    .pcia_scan_shift_en(pcia_scan_shift_en),
    .pcia_wrap_shift_en(pcia_wrap_shift_en),
    .pcia_test_mode_tp(pcia_test_mode_tp),
    .pcia_test_mode(pcia_test_mode),
    .pcia_test_si(pcia_test_si),
    .pcia_test_so(pcia_test_so),
    .pcia_wrap_si(pcia_wrap_si),
    .pcia_wrap_so(pcia_wrap_so),
    .pcib_dfttm(pcib_dfttm),
    .pcib_scan_shift_en(pcib_scan_shift_en),
    .pcib_wrap_shift_en(pcib_wrap_shift_en),
    .pcib_test_mode_tp(pcib_test_mode_tp),
    .pcib_test_mode(pcib_test_mode),
    .pcib_test_si(pcib_test_si),
    .pcib_test_so(pcib_test_so),
    .pcib_wrap_si(pcib_wrap_si),
    .pcib_wrap_so(pcib_wrap_so),
    .ahb_dfttm(ahb_dfttm),
    .ahb_scan_shift_en(ahb_scan_shift_en),
    .ahb_wrap_shift_en(ahb_wrap_shift_en),
    .ahb_test_mode_tp(ahb_test_mode_tp),
    .ahb_test_mode(ahb_test_mode),
    .ahb_test_si(ahb_test_si),
    .ahb_test_so(ahb_test_so),
    .ahb_wrap_si(ahb_wrap_si),
    .ahb_wrap_so(ahb_wrap_so),
    .apb_dfttm(apb_dfttm),
    .apb_scan_shift_en(apb_scan_shift_en),
    .apb_wrap_shift_en(apb_wrap_shift_en),
    .apb_test_mode_tp(apb_test_mode_tp),
    .apb_test_mode(apb_test_mode),
    .apb_test_si(apb_test_si),
    .apb_test_so(apb_test_so),
    .apb_wrap_si(apb_wrap_si),
    .apb_wrap_so(apb_wrap_so),
    .axis_dfttm(axis_dfttm),
    .axis_scan_shift_en(axis_scan_shift_en),
    .axis_wrap_shift_en(axis_wrap_shift_en),
    .axis_test_mode_tp(axis_test_mode_tp),
    .axis_test_mode(axis_test_mode),
    .axis_test_si(axis_test_si),
    .axis_test_so(axis_test_so),
    .axis_wrap_si(axis_wrap_si),
    .axis_wrap_so(axis_wrap_so),
    .axim_dfttm(axim_dfttm),
    .axim_scan_shift_en(axim_scan_shift_en),
    .axim_wrap_shift_en(axim_wrap_shift_en),
    .axim_test_mode_tp(axim_test_mode_tp),
    .axim_test_mode(axim_test_mode),
    .axim_test_si(axim_test_si),
    .axim_test_so(axim_test_so),
    .axim_wrap_si(axim_wrap_si),
    .axim_wrap_so(axim_wrap_so),
    .top_scan_shift_en(top_scan_shift_en),
    .top_test_si(top_test_si),
    .top_test_so(top_test_so),
    .scc_sms_in(scc_sms_in),
    .hic_sms_in(hic_sms_in),
    .g2muc_sms_in(g2muc_sms_in),
    .l4ga_sms_in(l4ga_sms_in),
    .l4gb_sms_in(l4gb_sms_in),
    .ahb_sms_in(ahb_sms_in),
    .lpddr_sms_in(lpddr_sms_in),
    .pcia_sms_in(pcia_sms_in),
    .pcib_sms_in(pcib_sms_in),
    .scc_sms_out(scc_sms_out),
    .hic_sms_out(hic_sms_out),
    .g2muc_sms_out(g2muc_sms_out),
    .l4ga_sms_out(l4ga_sms_out),
    .l4gb_sms_out(l4gb_sms_out),
    .ahb_sms_out(ahb_sms_out),
    .lpddr_sms_out(lpddr_sms_out),
    .pcia_sms_out(pcia_sms_out),
    .pcib_sms_out(pcib_sms_out),
    .lpddr_atpg_mode(lpddr_atpg_mode),
    .lpddr_compression_mode(lpddr_compression_mode),
    .lpddr_phy0_burnin(lpddr_phy0_burnin),
    .lpddr_phy1_burnin(lpddr_phy1_burnin),
    .lpddr_atpg_se(lpddr_atpg_se),
    .lpddr_scan_ctl(lpddr_scan_ctl),
    .lpddr_scan_shift_cg(lpddr_scan_shift_cg),
    .lpddr_scan_rstn(lpddr_scan_rstn),
    .lpddr_sms_dm(lpddr_sms_dm),
    .lpddr_ring_bypass(lpddr_ring_bypass),
    .lpddr_sfp_dft_mode(lpddr_sfp_dft_mode),
    .lpddr_tdrclk(lpddr_tdrclk),
    .lpddr_wrstn(lpddr_wrstn),
    .lpddr_cmd_tdr_capture_en(lpddr_cmd_tdr_capture_en),
    .lpddr_cmd_tdr_shift_en(lpddr_cmd_tdr_shift_en),
    .lpddr_cmd_tdr_update_en(lpddr_cmd_tdr_update_en),
    .lpddr_rd_tdr_capture_en(lpddr_rd_tdr_capture_en),
    .lpddr_rd_tdr_shift_en(lpddr_rd_tdr_shift_en),
    .lpddr_rd_tdr_update_en(lpddr_rd_tdr_update_en),
    .lpddr_wsi(lpddr_wsi),
    .lpddr_cmd_tdr_tdo(lpddr_cmd_tdr_tdo),
    .lpddr_rd_tdr_tdo(lpddr_rd_tdr_tdo),
    .dft_crg_test_clk_sel(dft_crg_test_clk_sel),
    .dft_crg_rst_byp(dft_crg_rst_byp),
    .dft_crg_rst_n_test(dft_crg_rst_n_test),
    .dft_crg_pll_byp(dft_crg_pll_byp),
    .dft_crg_blk_clk_en(dft_crg_blk_clk_en),
    .dft_crg_comp_clk_en(dft_crg_comp_clk_en),
    .dft_crg_lpddr_clk_en(dft_crg_lpddr_clk_en),
    .crg_pll_ready(crg_pll_ready)
  );

  // soc_dft_sva states its C-01 (DFTSO_OE = 0 in M0) for P_DFTSO_HIZ_M0 = 1 and its C-02 for
  // P_OE_GATED = 1, so it is instanced where both hold. The bench monitor below applies the
  // same three boundary checks with the configured values in every configuration.
  wire [2:0] sva_fails;
  if (P_OE_GATED && P_DFTSO_HIZ_M0) begin : g_sva
    soc_dft_sva u_sva (
      .TCK1(TCK1),
      .TRSTN1(TRSTN1),
      .DFTTM(DFTTM),
      .TSEL1(TSEL1),
      .TDO1_OE(TDO1_OE),
      .arc_tdo1_oe(arc_tdo1_oe),
      .pcia_tdo1_oe(pcia_tdo1_oe),
      .pcib_tdo1_oe(pcib_tdo1_oe),
      .DFTSO(DFTSO),
      .DFTSO_OE(DFTSO_OE),
      .scc_dfttm(scc_dfttm),
      .scc_scan_shift_en(scc_scan_shift_en),
      .scc_test_mode(scc_test_mode),
      .top_scan_shift_en(top_scan_shift_en),
      .dft_crg_test_clk_sel(dft_crg_test_clk_sel),
      .dft_crg_rst_byp(dft_crg_rst_byp),
      .dft_crg_pll_byp(dft_crg_pll_byp),
      .dft_crg_blk_clk_en(dft_crg_blk_clk_en),
      .dft_crg_comp_clk_en(dft_crg_comp_clk_en),
      .dft_crg_lpddr_clk_en(dft_crg_lpddr_clk_en),
      .scc_test_si(scc_test_si),
      .scc_wrap_si(scc_wrap_si),
      .top_test_si(top_test_si),
      .fail_count(sva_fails)
    );
  end else begin : g_no_sva
    assign sva_fails = 3'd0;
    initial $display("NOTE soc_dft_sva not instanced: it states P_DFTSO_HIZ_M0 = 1 and P_OE_GATED = 1, this configuration has %0d and %0d; the bench monitor applies C-01..C-03 with the configured values", P_DFTSO_HIZ_M0, P_OE_GATED);
  end

  // ---------------------------------------------------------------- clock and check counters
  initial TCK1 = 1'b0;
  always #(TCK_HALF) TCK1 = ~TCK1;

  // ---------------------------------------------------------------- configured boundary monitor
  // C-01 (Section 17): with DFTTM = 0 the block, TOP and CRG test controls hold their M0 values
  //      and DFTSO_OE = M0_DFTSO_OE (7.3). C-02 (8.4): TDO1_OE is the selected target's enable
  //      with P_OE_GATED = 1, the OR of the targets' enables with P_OE_GATED = 0 (the SOC_DFT
  //      chain is parked with TMS = 1 while TSEL1 != 11, so its enable is 0). C-03 (REQ-20,
  //      REQ-02): with DFTTM = 0 every scan-channel output and DFTSO is 0.
  wire m01 = TRSTN1 && !DFTTM &&
             !(scc_dfttm == 1'b0 && scc_scan_shift_en == 1'b0 && scc_test_mode == 4'b0000
               && top_scan_shift_en == 1'b0 && dft_crg_test_clk_sel == 1'b0
               && dft_crg_rst_byp == 1'b0 && dft_crg_pll_byp == 3'b000
               && dft_crg_blk_clk_en == 13'h1FFF && dft_crg_comp_clk_en == 13'h0000
               && dft_crg_lpddr_clk_en == 5'h00 && DFTSO_OE == M0_DFTSO_OE);
  wire tdo1_oe_sel = (TSEL1 == 2'b00) ? arc_tdo1_oe : (TSEL1 == 2'b01) ? pcia_tdo1_oe : pcib_tdo1_oe;
  wire m02 = TSEL1 != 2'b11 &&
             TDO1_OE != (P_OE_GATED ? tdo1_oe_sel : (arc_tdo1_oe | pcia_tdo1_oe | pcib_tdo1_oe));
  wire m03 = TRSTN1 && !DFTTM && (DFTSO != '0 || scc_test_si != '0 || scc_wrap_si != '0 || top_test_si != '0);
  int mon_fails;
  initial mon_fails = 0;
  always @(posedge TCK1) begin
    if (m01) $display("FAIL [C-01] M0 test controls not at their configured Section 17 values");
    if (m02) $display("FAIL [C-02] TDO1_OE is not the configured TDO1_OE (P_OE_GATED = %0d)", P_OE_GATED);
    if (m03) $display("FAIL [C-03] a scan-channel output or DFTSO is not 0 with DFTTM = 0");
    mon_fails <= mon_fails + int'(m01) + int'(m02) + int'(m03);
  end
  int errors;
  int checks;
  int test_errors;
  string cur;
  task automatic check(input bit cond, input string what);
    checks = checks + 1;
    if (!cond) begin
      errors = errors + 1;
      test_errors = test_errors + 1;
      $display("FAIL [%s] %s", cur, what);
    end
  endtask
  int n_tests;
  task automatic start(input string name);
    n_tests = n_tests + 1;
    cur = name;
    test_errors = 0;
    $display("TEST START %s", name);
  endtask
  // watchdog: a design that never produces an awaited edge fails the run instead of hanging
  // it (a complete run takes about 0.13 ms of simulated time)
  initial begin
    #(2_000_000);
    $display("FAIL [%s] watchdog: the run did not finish within 2 ms of simulated time", cur);
    $display("TEST FAIL %s", cur);
    $display("RESULT FAIL");
    $finish;
  end
  task automatic finish_test();
    if (test_errors == 0) $display("TEST PASS %s", cur);
    else $display("TEST FAIL %s", cur);
  endtask

  // ---------------------------------------------------------------- output toggle record (t_connectivity)
  wire [280:0] live_outs = {DFTSO, DFTSO_OE, TDO1, TDO1_OE, arc_tms1, pcia_tms1, pcib_tms1, scc_dfttm, scc_scan_shift_en, scc_wrap_shift_en, scc_test_mode_tp, scc_test_mode, scc_test_si, scc_wrap_si, hic_dfttm, hic_scan_shift_en, hic_wrap_shift_en, hic_test_mode_tp, hic_test_mode, hic_test_si, hic_wrap_si, g2muc_dfttm, g2muc_scan_shift_en, g2muc_wrap_shift_en, g2muc_test_mode_tp, g2muc_test_mode, g2muc_test_si, g2muc_wrap_si, l4ga_dfttm, l4ga_scan_shift_en, l4ga_wrap_shift_en, l4ga_test_mode_tp, l4ga_test_mode, l4ga_test_si, l4ga_wrap_si, l4gb_dfttm, l4gb_scan_shift_en, l4gb_wrap_shift_en, l4gb_test_mode_tp, l4gb_test_mode, l4gb_test_si, l4gb_wrap_si, pcia_dfttm, pcia_scan_shift_en, pcia_wrap_shift_en, pcia_test_mode_tp, pcia_test_mode, pcia_test_si, pcia_wrap_si, pcib_dfttm, pcib_scan_shift_en, pcib_wrap_shift_en, pcib_test_mode_tp, pcib_test_mode, pcib_test_si, pcib_wrap_si, ahb_dfttm, ahb_scan_shift_en, ahb_wrap_shift_en, ahb_test_mode_tp, ahb_test_mode, ahb_test_si, ahb_wrap_si, apb_dfttm, apb_scan_shift_en, apb_wrap_shift_en, apb_test_mode_tp, apb_test_mode, apb_test_si, apb_wrap_si, axis_dfttm, axis_scan_shift_en, axis_wrap_shift_en, axis_test_mode_tp, axis_test_mode, axis_test_si, axis_wrap_si, axim_dfttm, axim_scan_shift_en, axim_wrap_shift_en, axim_test_mode_tp, axim_test_mode, axim_test_si, axim_wrap_si, top_scan_shift_en, top_test_si, lpddr_atpg_mode, lpddr_compression_mode, lpddr_phy0_burnin, lpddr_phy1_burnin, lpddr_scan_shift_cg, lpddr_scan_rstn, lpddr_sms_dm, lpddr_ring_bypass, lpddr_sfp_dft_mode, lpddr_wrstn, lpddr_cmd_tdr_capture_en, lpddr_cmd_tdr_shift_en, lpddr_cmd_tdr_update_en, lpddr_rd_tdr_capture_en, lpddr_rd_tdr_shift_en, lpddr_rd_tdr_update_en, lpddr_wsi, dft_crg_test_clk_sel, dft_crg_rst_byp, dft_crg_rst_n_test, dft_crg_pll_byp, dft_crg_blk_clk_en, dft_crg_comp_clk_en[10:0]};
  wire [79:0] held_outs = {scc_sms_in, hic_sms_in, g2muc_sms_in, l4ga_sms_in, l4gb_sms_in, ahb_sms_in, lpddr_sms_in, pcia_sms_in, pcib_sms_in, lpddr_atpg_se, lpddr_scan_ctl, dft_crg_comp_clk_en[12:11], dft_crg_lpddr_clk_en};
  logic [280:0] live_ref;
  logic [280:0] live_seen;
  logic         tracking;
  logic         held_moved;
  initial begin tracking = 1'b0; held_moved = 1'b0; live_seen = '0; live_ref = '0; end
  always @(posedge TCK1) begin
    if (tracking) begin
      live_seen <= live_seen | (live_outs ^ live_ref);
      if (held_outs != '0) held_moved <= 1'b1;
    end
  end
  // lpddr_tdrclk is a gated clock: its movement is recorded on its own edges
  logic tdrclk_seen;
  initial tdrclk_seen = 1'b0;
  always @(posedge TCK1) begin
    #5;                                                 // inside the TCK1-high phase
    if (tracking && lpddr_tdrclk) tdrclk_seen <= 1'b1;
  end

  // ---------------------------------------------------------------- JTAG BFM (spec 9.3, 9.8)
  task automatic jclk(input bit tms, input bit tdi, output bit tdo);
    @(negedge TCK1);
    TMS1 = tms;
    TDI1 = tdi;
    @(posedge TCK1);
    tdo = TDO1;
    #1;                                                 // never act in the edge's own instant
  endtask
  task automatic jstep(input bit tms, input bit tdi);
    @(negedge TCK1);
    TMS1 = tms;
    TDI1 = tdi;
    @(posedge TCK1);
    #1;                                                 // never act in the edge's own instant
  endtask
  task automatic jtlr();
    for (int i = 0; i < 5; i++) jstep(1'b1, 1'b0);
    jstep(1'b0, 1'b0);                                  // Run-Test/Idle
  endtask
  logic        ir_oe_all;                             // TDO1_OE seen 1 on every Shift-IR bit of the last ir_scan
  // IR scan of n bits (n <= 64) of the two-device chain from Run-Test/Idle; returns the bits
  // seen on TDO1. The first 5 bits shifted land in dft_tap (nearest TDO1), the next
  // P_SMS_IR_LEN in the SMS TAP stub (9.4, 14.6).
  task automatic ir_scan(input int n, input logic [63:0] v, output logic [63:0] o);
    bit d;
    o = '0;
    jstep(1'b1, 1'b0); jstep(1'b1, 1'b0); jstep(1'b0, 1'b0); jstep(1'b0, 1'b0);   // Select-DR, Select-IR, Capture-IR, Shift-IR
    ir_oe_all = 1'b1;
    for (int i = 0; i < n; i++) begin jclk(i == n - 1, v[i], d); o[i] = d; ir_oe_all = ir_oe_all & TDO1_OE; end
    jstep(1'b1, 1'b0); jstep(1'b0, 1'b0);              // Update-IR, Run-Test/Idle
  endtask
  // IR and DR scans that leave Shift after bit k-1 for Exit1, Pause (two cycles), Exit2 and
  // return to Shift with TMS = 0 (9.3 state diagram); the bits out equal an unpaused scan.
  task automatic ir_scan_paused(input int n, input int k, input logic [63:0] v, output logic [63:0] o);
    bit d;
    o = '0;
    jstep(1'b1, 1'b0); jstep(1'b1, 1'b0); jstep(1'b0, 1'b0); jstep(1'b0, 1'b0);   // Select-DR, Select-IR, Capture-IR, Shift-IR
    for (int i = 0; i < n; i++) begin
      jclk((i == n - 1) || (i == k - 1), v[i], d); o[i] = d;
      if (i == k - 1) begin
        jstep(1'b0, 1'b0); jstep(1'b0, 1'b0);          // Pause-IR, Pause-IR
        jstep(1'b1, 1'b0); jstep(1'b0, 1'b0);          // Exit2-IR, Shift-IR
      end
    end
    jstep(1'b1, 1'b0); jstep(1'b0, 1'b0);              // Update-IR, Run-Test/Idle
  endtask
  task automatic dr_scan_paused(input int n, input int k, input logic [63:0] v, output logic [63:0] o);
    bit d;
    o = '0;
    jstep(1'b1, 1'b0); jstep(1'b0, 1'b0); jstep(1'b0, 1'b0);   // Select-DR, Capture-DR, Shift-DR
    for (int i = 0; i < n; i++) begin
      jclk((i == n - 1) || (i == k - 1), v[i], d); o[i] = d;
      if (i == k - 1) begin
        jstep(1'b0, 1'b0); jstep(1'b0, 1'b0);          // Pause-DR, Pause-DR
        jstep(1'b1, 1'b0); jstep(1'b0, 1'b0);          // Exit2-DR, Shift-DR
      end
    end
    jstep(1'b1, 1'b0); jstep(1'b0, 1'b0);              // Update-DR, Run-Test/Idle
  endtask
  // code to dft_tap, the SMS TAP stub in BYPASS (all ones over P_SMS_IR_LEN bits, spec 9.8)
  logic [63:0] o_ir;
  task automatic shift_ir(input logic [4:0] code);
    ir_scan(IR_CHAIN, {{(64 - 5){1'b1}}, code}, o_ir);
    check(o_ir == ((64'd1 << 5) | 64'd1), "IR scan returns the Capture-IR ...01 of dft_tap then of the SMS TAP stub, 5 + P_SMS_IR_LEN bits (9.4)");
  endtask
  // DR scan of n bits (n <= 64) from Run-Test/Idle; returns the bits seen on TDO1
  task automatic shift_dr(input int n, input logic [63:0] v, output logic [63:0] o);
    bit d;
    o = '0;
    jstep(1'b1, 1'b0); jstep(1'b0, 1'b0); jstep(1'b0, 1'b0);   // Select-DR, Capture-DR, Shift-DR
    for (int i = 0; i < n; i++) begin jclk(i == n - 1, v[i], d); o[i] = d; end
    jstep(1'b1, 1'b0); jstep(1'b0, 1'b0);              // Update-DR, Run-Test/Idle
  endtask
  logic [63:0] o_scan;
  task automatic dtr_write(input logic [4:0] code, input logic [31:0] v);
    shift_ir(code);                          // SMS TAP in BYPASS (spec 9.8)
    shift_dr(33, {31'h0, 1'b0, v}, o_scan);
  endtask
  // A DR read writes back what is shifted in, so a read of DTR_CFG or DTR_LPDDR is
  // followed by a write of the value read (DTR_STS has no shadow and is not restored).
  task automatic dtr_read(input logic [4:0] code, output logic [31:0] r);
    shift_ir(code);
    shift_dr(33, 64'h0, o_scan);
    r = o_scan[31:0];
    check(o_scan[63:32] == 32'h0, "the 33rd bit out is the SMS TAP BYPASS capture 0 (REQ-08)");
    if (code != 5'b00100) dtr_write(code, r);
  endtask
  task automatic chain_reset();
    TRSTN1 = 1'b0;
    repeat (2) @(posedge TCK1);
    #1;
    TRSTN1 = 1'b1;
    jtlr();
  endtask
  task automatic power_on();
    PwrOk = 1'b0;
    repeat (2) @(posedge TCK1);
    PwrOk = 1'b1;
    repeat (3) @(posedge TCK1);
    #1;
  endtask

  // ---------------------------------------------------------------- the smoke tests
  task automatic settle();                            // next rising TCK1, then 1 ns
    @(posedge TCK1);
    #1;
  endtask
  logic [31:0] r32;
  logic [63:0] r64;
  int n_en;
  // every routed block's scan and wrapper shift enable, block b at bit b
  wire [10:0] all_scan_se = {axim_scan_shift_en, axis_scan_shift_en, apb_scan_shift_en, ahb_scan_shift_en, pcib_scan_shift_en, pcia_scan_shift_en, l4gb_scan_shift_en, l4ga_scan_shift_en, g2muc_scan_shift_en, hic_scan_shift_en, scc_scan_shift_en};
  wire [10:0] all_wrap_se = {axim_wrap_shift_en, axis_wrap_shift_en, apb_wrap_shift_en, ahb_wrap_shift_en, pcib_wrap_shift_en, pcia_wrap_shift_en, l4gb_wrap_shift_en, l4ga_wrap_shift_en, g2muc_wrap_shift_en, hic_wrap_shift_en, scc_wrap_shift_en};
  // TDRCLK rising edges, and LPDDR TDR enables / WSI seen while a flag is armed
  int   tdrclk_n;
  initial tdrclk_n = 0;
  always @(posedge lpddr_tdrclk) tdrclk_n <= tdrclk_n + 1;
  wire [11:0] ddr_en_all = {lpddr_rd_tdr_update_en, lpddr_rd_tdr_shift_en, lpddr_rd_tdr_capture_en,
                            lpddr_cmd_tdr_update_en, lpddr_cmd_tdr_shift_en, lpddr_cmd_tdr_capture_en};
  logic ddr_en_seen;
  logic wsi_seen;
  initial begin ddr_en_seen = 1'b0; wsi_seen = 1'b0; end
  always @(posedge TCK1 or negedge TCK1) begin
    if (ddr_en_all != 12'h000) ddr_en_seen <= 1'b1;
    if (lpddr_wsi != 2'b00) wsi_seen <= 1'b1;
  end
  task automatic drive_test_so(input bit v);
    scc_test_so = {$bits(scc_test_so){v}};
    hic_test_so = {$bits(hic_test_so){v}};
    g2muc_test_so = {$bits(g2muc_test_so){v}};
    l4ga_test_so = {$bits(l4ga_test_so){v}};
    l4gb_test_so = {$bits(l4gb_test_so){v}};
    pcia_test_so = {$bits(pcia_test_so){v}};
    pcib_test_so = {$bits(pcib_test_so){v}};
    ahb_test_so = {$bits(ahb_test_so){v}};
    apb_test_so = {$bits(apb_test_so){v}};
    axis_test_so = {$bits(axis_test_so){v}};
    axim_test_so = {$bits(axim_test_so){v}};
  endtask
  // TCK1 just after the edge that launched phy0 CmdTdrShiftEn (P_TDR_EN_EDGE, 15.4)
  logic en_edge_tck;
  logic en_edge_seen;
  initial begin en_edge_tck = 1'b0; en_edge_seen = 1'b0; end
  always @(posedge lpddr_cmd_tdr_shift_en[0]) begin
    if (!en_edge_seen) en_edge_tck <= TCK1;
    en_edge_seen <= 1'b1;
  end
  logic [12:0] crg_sel;
  logic [12:0] crg_act;
  initial begin
    errors = 0; checks = 0; test_errors = 0; cur = "none"; n_tests = 0;
    DFTTM = '0;
    DFTMAX = '0;
    DFTSE = '0;
    DFTSI = '0;
    TSEL1 = '0;
    TMS1 = 1'b1;
    TDI1 = 1'b1;
    TRSTN1 = '0;
    PwrOk = '0;
    Rstn = 1'b1;
    arc_tdo1 = '0;
    arc_tdo1_oe = '0;
    pcia_tdo1 = '0;
    pcia_tdo1_oe = '0;
    pcib_tdo1 = '0;
    pcib_tdo1_oe = '0;
    scc_test_so = '0;
    scc_wrap_so = '0;
    hic_test_so = '0;
    hic_wrap_so = '0;
    g2muc_test_so = '0;
    g2muc_wrap_so = '0;
    l4ga_test_so = '0;
    l4ga_wrap_so = '0;
    l4gb_test_so = '0;
    l4gb_wrap_so = '0;
    pcia_test_so = '0;
    pcia_wrap_so = '0;
    pcib_test_so = '0;
    pcib_wrap_so = '0;
    ahb_test_so = '0;
    ahb_wrap_so = '0;
    apb_test_so = '0;
    apb_wrap_so = '0;
    axis_test_so = '0;
    axis_wrap_so = '0;
    axim_test_so = '0;
    axim_wrap_so = '0;
    top_test_so = '0;
    scc_sms_out = '0;
    hic_sms_out = '0;
    g2muc_sms_out = '0;
    l4ga_sms_out = '0;
    l4gb_sms_out = '0;
    ahb_sms_out = '0;
    lpddr_sms_out = '0;
    pcia_sms_out = '0;
    pcib_sms_out = '0;
    lpddr_cmd_tdr_tdo = '0;
    lpddr_rd_tdr_tdo = '0;
    crg_pll_ready = '0;
    TSEL1 = 2'b11;
    repeat (2) @(posedge TCK1);

    start("t_reset_startup");
    @(negedge TCK1); PwrOk = 1'b1;
    check(u_dut.rst_dtr_n == 1'b0, "rst_dtr_n held low while PwrOk was low");
    @(posedge TCK1); #1;
    check(u_dut.rst_dtr_n == 1'b0, "rst_dtr_n still low after the first rising TCK1 (REQ-03)");
    @(posedge TCK1); #1;
    check(u_dut.rst_dtr_n == 1'b1, "rst_dtr_n released on the second rising TCK1 (REQ-03)");
    TRSTN1 = 1'b1;
    #1;
    check(TDO1_OE == 1'b0, "TDO1_OE = 0 after TRSTN1 (REQ-09)");
    check(dft_crg_blk_clk_en == 13'h1FFF && dft_crg_comp_clk_en == 13'h0 && dft_crg_lpddr_clk_en == 5'h0, "CRG enables at their M0 values (REQ-01)");
    check(dft_crg_test_clk_sel == 1'b0 && dft_crg_pll_byp == 3'b000 && dft_crg_rst_byp == 1'b0 && lpddr_scan_rstn == 1'b1, "CRG selects at their M0 values (REQ-01)");
    check(lpddr_wrstn == 1'b0 && DFTSO_OE == M0_DFTSO_OE && DFTSO == 20'h0, "WRSTN = 0, DFTSO_OE at its M0 value for P_DFTSO_HIZ_M0 (0 = Hi-Z when 1, 1 when 0) and DFTSO = 0 in M0 (REQ-01, REQ-02, 7.3)");
    check(lpddr_sms_dm == LPDDR_RV[16:14] && lpddr_ring_bypass == LPDDR_RV[13:7] && lpddr_sfp_dft_mode == LPDDR_RV[6], "LPDDR statics at the P_LPDDR_RST fields after PwrOk (REQ-31, 10.3)");
    check(lpddr_atpg_mode == (LPDDR_RV[0] & LPDDR_RV[1]) && lpddr_compression_mode == (LPDDR_RV[2] & LPDDR_RV[3]) && lpddr_scan_shift_cg == LPDDR_RV[17], "LPDDR override paths at the P_LPDDR_RST fields in M0 (REQ-31, 11.3)");
    jtlr();
    dtr_read(5'b00010, r32);
    check(r32 == CFG_RV, "DTR_CFG reads P_CFG_RST after PwrOk (REQ-10, REQ-31)");
    dtr_read(5'b00011, r32);
    check(r32 == LPDDR_RV, "DTR_LPDDR reads P_LPDDR_RST after PwrOk (REQ-10, REQ-31, CONF-26)");
    finish_test();
    live_ref = live_outs;
    tracking = 1'b1;

    start("t_reset_occupied");
    dtr_write(5'b00010, 32'h003F_FFA3);                // the 9.8 example: PART = 3
    dtr_read(5'b00100, r32);
    check(r32[11:8] == 4'd3, "DTR_STS.PART reads the written PART (spec 9.8)");
    check(r32[15:12] == 4'd6 && r32[23:16] == RTL_REV && r32[31:24] == 8'h00, "DTR_STS NPART = 6, RTL_REV = P_RTL_REV[7:0], bits 31:24 = 0 (REQ-13, 10.4)");
    chain_reset();
    dtr_read(5'b00010, r32);
    check(r32 == 32'h003F_FFA3, "TRSTN1 and Test-Logic-Reset leave DTR_CFG unchanged (REQ-11)");
    dtr_write(5'b00011, 32'h0001_5555);
    dtr_write(5'b00010, 32'h8000_0000);                // CLR
    dtr_read(5'b00010, r32);
    check(r32 == CFG_RV, "CLR returns DTR_CFG to its reset value P_CFG_RST and reads 0 (REQ-12)");
    dtr_read(5'b00011, r32);
    check(r32 == LPDDR_RV, "CLR returns DTR_LPDDR to its reset value P_LPDDR_RST (REQ-12)");
    dtr_write(5'b00010, 32'h7FFF_FFFF);                // every bit but CLR
    dtr_read(5'b00010, r32);
    check(r32 == 32'h007F_FFFF, "DTR_CFG reserved bits 30:23 are not stored and read 0 (Table 50, 10.2)");
    dtr_write(5'b00011, 32'hFFFF_FFFF);
    dtr_read(5'b00011, r32);
    check(r32 == 32'h0003_FFFF, "DTR_LPDDR reserved bits 31:18 are not stored and read 0 (Table 51, 10.3)");
    dtr_write(5'b00010, 32'h003F_FFA3);
    power_on();
    dtr_read(5'b00010, r32);
    check(r32 == CFG_RV, "PwrOk returns DTR_CFG to P_CFG_RST (REQ-11)");
    finish_test();

    start("t_pad");
    DFTTM = 1'b1; DFTSI = 20'hFFFFF; DFTSE = 1'b1; settle();
    check(DFTSO_OE == 1'b1, "DFTSO_OE = 1 with DFTTM = 1 for either P_DFTSO_HIZ_M0 (REQ-02, 7.3)");
    check(DFTSO == ((P_PARTITIONED && CFG_RST[3:0] == dft_part_map_pkg::PART_LOOPBACK) ? DFTSI : 20'h0), "the reset PART P_CFG_RST[3:0] with every channel return 0: DFTSO = 0 unless that PART is loopback; 0 in the partial build (REQ-20, REQ-31, 11.3)");
    DFTTM = 1'b0; DFTSE = 1'b0; DFTSI = 20'h0; settle();
    jtlr(); dtr_write(5'b00010, (CFG_TEST & ~32'h0000_000F) | 32'd15);              // PART = 15: scan_test_mode_loopback
    DFTTM = 1'b1;
    DFTSI = 20'hA5A5A; settle(); check(DFTSO == (P_PARTITIONED ? 20'hA5A5A : '0), "loopback: DFTSO = DFTSI on every pin (REQ-19, 11.3)");
    DFTSI = 20'h5A5A5; settle(); check(DFTSO == (P_PARTITIONED ? 20'h5A5A5 : '0), "loopback: DFTSO = DFTSI, inverted pattern (REQ-19, 11.3)");
    check(scc_test_si == '0 && pcia_test_si == '0 && top_test_si == 3'b000, "loopback selects no block channel (REQ-17)");
    DFTTM = 1'b0; settle();
    check(DFTSO_OE == M0_DFTSO_OE && DFTSO == 20'h0, "DFTSO_OE at its M0 value for P_DFTSO_HIZ_M0 and DFTSO = 0 with DFTTM = 0 (REQ-02, REQ-20, 7.3)");
    DFTSI = 20'h0;
    jtlr(); dtr_write(5'b00010, CFG_RST);
    DFTMAX = 1'b1; repeat (3) @(posedge TCK1);
    dtr_read(5'b00100, r32);
    check(r32[1] == P_DFTMAX_COMP && r32[0] == 1'b0, "DTR_STS DFTMAX_COMP = (DFTMAX == P_DFTMAX_COMP) for DFTMAX = 1, DFTTM = 0 (REQ-37, 7.3)");
    DFTMAX = 1'b0; repeat (3) @(posedge TCK1);
    dtr_read(5'b00100, r32);
    check(r32[1] == !P_DFTMAX_COMP && r32[3:2] == 2'b11 && r32[7] == 1'b1, "DTR_STS DFTMAX_COMP = (DFTMAX == P_DFTMAX_COMP) for DFTMAX = 0, TSEL1 = 11, PWROK = 1 (REQ-13, REQ-37)");
    crg_pll_ready = 3'b101; repeat (3) @(posedge TCK1);
    dtr_read(5'b00100, r32);
    check(r32[6:4] == 3'b101, "DTR_STS PLL_RDY follows crg_pll_ready through the synchroniser (REQ-13)");
    // PART = 5 selects no INTEST mode: with every block channel return at 1 the INTEST lanes drive 0
    jtlr(); dtr_write(5'b00010, CFG_TEST);             // PART = 5
    drive_test_so(1'b1);
    DFTTM = 1'b1; settle();
    check(DFTSO == 20'h0, "PART = 5 (no INTEST mode) with every channel return 1: DFTSO = 0 (12.3, REQ-20)");
    DFTTM = 1'b0; settle();
    check(DFTSO == 20'h0, "M0 with every channel return 1: DFTSO = 0 (12.3, REQ-20)");
    drive_test_so(1'b0);
    finish_test();

    start("t_jtag_targets");
    for (int s = 0; s < 3; s++) begin
      for (int m = 0; m < 2; m++) begin
        for (int t = 0; t < 2; t++) begin
          TSEL1 = s[1:0]; DFTTM = m[0]; TMS1 = t[0];
          arc_tdo1 = 1'b1; arc_tdo1_oe = 1'b1; pcia_tdo1 = 1'b0; pcia_tdo1_oe = 1'b1; pcib_tdo1 = 1'b1; pcib_tdo1_oe = 1'b0;
          #1;
          check(arc_tms1  == (t[0] | ~((s == 0) | (m[0] & P_TM_OPEN))), "arc_tms1 per 8.4, tm_o = DFTTM & P_TM_OPEN (REQ-04)");
          check(pcia_tms1 == (t[0] | ~((s == 1) | (m[0] & P_TM_OPEN))), "pcia_tms1 per 8.4, tm_o = DFTTM & P_TM_OPEN (REQ-04)");
          check(pcib_tms1 == (t[0] | ~((s == 2) | (m[0] & P_TM_OPEN))), "pcib_tms1 per 8.4, tm_o = DFTTM & P_TM_OPEN (REQ-04)");
          check(TDO1 == ((s == 0) ? 1'b1 : (s == 1) ? 1'b0 : 1'b1), "TDO1 is the selected target's TDO (REQ-05)");
          check(TDO1_OE == (P_OE_GATED ? ((s == 0) ? 1'b1 : (s == 1) ? 1'b1 : 1'b0) : 1'b1), "TDO1_OE is the selected target's enable with P_OE_GATED = 1, the OR of the four enables with P_OE_GATED = 0 (REQ-05, 8.4)");
          settle();                                    // one TCK1 edge per setting, so t_connectivity sees the routed TMS
        end
      end
    end
    arc_tdo1 = 1'b0; arc_tdo1_oe = 1'b0; pcia_tdo1 = 1'b1; pcia_tdo1_oe = 1'b0; pcib_tdo1 = 1'b0; pcib_tdo1_oe = 1'b1; #1;
    TSEL1 = 2'b10; #1;
    check(TDO1 == 1'b0 && TDO1_OE == 1'b1, "TDO1/TDO1_OE follow Pcib with TSEL1 = 10 (REQ-05)");
    TSEL1 = 2'b11; DFTTM = 1'b0; TMS1 = 1'b1; #1;
    check(arc_tms1 && pcia_tms1 && pcib_tms1, "unselected targets see TMS = 1 with TSEL1 = 11 (REQ-04)");
    chain_reset();
    finish_test();

    start("t_blocks");
    DFTTM = 1'b0; settle(); jtlr(); dtr_write(5'b00010, (CFG_TEST & ~32'h0000_000F) | 32'd1);   // INTEST mode 0 on PART 1 (ADM-23)
    DFTTM = 1'b1;
    DFTMAX = DMAX_SCAN; DFTSE = 1'b1; settle();
    check(scc_test_mode == rtm(4'b0100) && !scc_scan_shift_en && !scc_wrap_shift_en, "PART 1: scc parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(hic_test_mode == rtm(4'b0100) && !hic_scan_shift_en && !hic_wrap_shift_en, "PART 1: hic parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(g2muc_test_mode == rtm(4'b0100) && !g2muc_scan_shift_en && !g2muc_wrap_shift_en, "PART 1: g2muc parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(l4ga_test_mode == rtm(4'b0100) && !l4ga_scan_shift_en && !l4ga_wrap_shift_en, "PART 1: l4ga parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(l4gb_test_mode == rtm(4'b0100) && !l4gb_scan_shift_en && !l4gb_wrap_shift_en, "PART 1: l4gb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(pcia_test_mode == rtm(4'b0001) && pcia_scan_shift_en == P_PARTITIONED && pcia_wrap_shift_en == P_PARTITIONED && pcia_dfttm && pcia_test_mode_tp, "PART 1: pcia selected, SCAN, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(pcib_test_mode == rtm(4'b0100) && !pcib_scan_shift_en && !pcib_wrap_shift_en, "PART 1: pcib parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(ahb_test_mode == rtm(4'b0100) && !ahb_scan_shift_en && !ahb_wrap_shift_en, "PART 1: ahb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(apb_test_mode == rtm(4'b0100) && !apb_scan_shift_en && !apb_wrap_shift_en, "PART 1: apb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(axis_test_mode == rtm(4'b0100) && !axis_scan_shift_en && !axis_wrap_shift_en, "PART 1: axis parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(axim_test_mode == rtm(4'b0100) && !axim_scan_shift_en && !axim_wrap_shift_en, "PART 1: axim parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    DFTMAX = DMAX_COMP; DFTSE = 1'b1; settle();
    check(scc_test_mode == rtm(4'b0100) && !scc_scan_shift_en && !scc_wrap_shift_en, "PART 1: scc parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(hic_test_mode == rtm(4'b0100) && !hic_scan_shift_en && !hic_wrap_shift_en, "PART 1: hic parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(g2muc_test_mode == rtm(4'b0100) && !g2muc_scan_shift_en && !g2muc_wrap_shift_en, "PART 1: g2muc parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(l4ga_test_mode == rtm(4'b0100) && !l4ga_scan_shift_en && !l4ga_wrap_shift_en, "PART 1: l4ga parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(l4gb_test_mode == rtm(4'b0100) && !l4gb_scan_shift_en && !l4gb_wrap_shift_en, "PART 1: l4gb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(pcia_test_mode == rtm(4'b0010) && pcia_scan_shift_en == P_PARTITIONED && pcia_wrap_shift_en == P_PARTITIONED && pcia_dfttm && pcia_test_mode_tp, "PART 1: pcia selected, COMP, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(pcib_test_mode == rtm(4'b0100) && !pcib_scan_shift_en && !pcib_wrap_shift_en, "PART 1: pcib parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(ahb_test_mode == rtm(4'b0100) && !ahb_scan_shift_en && !ahb_wrap_shift_en, "PART 1: ahb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(apb_test_mode == rtm(4'b0100) && !apb_scan_shift_en && !apb_wrap_shift_en, "PART 1: apb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(axis_test_mode == rtm(4'b0100) && !axis_scan_shift_en && !axis_wrap_shift_en, "PART 1: axis parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(axim_test_mode == rtm(4'b0100) && !axim_scan_shift_en && !axim_wrap_shift_en, "PART 1: axim parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    DFTSE = 1'b0; DFTMAX = DMAX_SCAN; settle();
    check(dft_crg_blk_clk_en == (P_PARTITIONED ? 13'h20 : '0), "PART 1: only the selected blocks' test clocks are enabled (REQ-22, 11.3)");
    DFTSI = 20'hFFFFF; settle();
    check(scc_test_si == 5'h0, "PART 1: scc scan-in 0, not selected (REQ-17)");
    check(hic_test_si == 5'h0, "PART 1: hic scan-in 0, not selected (REQ-17)");
    check(g2muc_test_si == 6'h0, "PART 1: g2muc scan-in 0, not selected (REQ-17)");
    check(l4ga_test_si == 3'h0, "PART 1: l4ga scan-in 0, not selected (REQ-17)");
    check(l4gb_test_si == 3'h0, "PART 1: l4gb scan-in 0, not selected (REQ-17)");
    check(pcia_test_si == (P_PARTITIONED ? 20'hFFFFF : '0), "PART 1: pcia scan-in from DFTSI at pin 0 (REQ-17, 11.3)");
    check(pcib_test_si == 20'h0, "PART 1: pcib scan-in 0, not selected (REQ-17)");
    check(ahb_test_si == 6'h0, "PART 1: ahb scan-in 0, not selected (REQ-17)");
    check(apb_test_si == 4'h0, "PART 1: apb scan-in 0, not selected (REQ-17)");
    check(axis_test_si == 3'h0, "PART 1: axis scan-in 0, not selected (REQ-17)");
    check(axim_test_si == 4'h0, "PART 1: axim scan-in 0, not selected (REQ-17)");
    DFTSI = 20'h00000; settle();
    check(scc_test_si == 5'h0, "PART 1: scc scan-in 0, not selected (REQ-17)");
    check(hic_test_si == 5'h0, "PART 1: hic scan-in 0, not selected (REQ-17)");
    check(g2muc_test_si == 6'h0, "PART 1: g2muc scan-in 0, not selected (REQ-17)");
    check(l4ga_test_si == 3'h0, "PART 1: l4ga scan-in 0, not selected (REQ-17)");
    check(l4gb_test_si == 3'h0, "PART 1: l4gb scan-in 0, not selected (REQ-17)");
    check(pcia_test_si == 20'h0, "PART 1: pcia scan-in from DFTSI at pin 0 (REQ-17)");
    check(pcib_test_si == 20'h0, "PART 1: pcib scan-in 0, not selected (REQ-17)");
    check(ahb_test_si == 6'h0, "PART 1: ahb scan-in 0, not selected (REQ-17)");
    check(apb_test_si == 4'h0, "PART 1: apb scan-in 0, not selected (REQ-17)");
    check(axis_test_si == 3'h0, "PART 1: axis scan-in 0, not selected (REQ-17)");
    check(axim_test_si == 4'h0, "PART 1: axim scan-in 0, not selected (REQ-17)");
    DFTSI = 20'hAAAAA; settle();
    check(scc_test_si == 5'h0, "PART 1: scc scan-in 0, not selected (REQ-17)");
    check(hic_test_si == 5'h0, "PART 1: hic scan-in 0, not selected (REQ-17)");
    check(g2muc_test_si == 6'h0, "PART 1: g2muc scan-in 0, not selected (REQ-17)");
    check(l4ga_test_si == 3'h0, "PART 1: l4ga scan-in 0, not selected (REQ-17)");
    check(l4gb_test_si == 3'h0, "PART 1: l4gb scan-in 0, not selected (REQ-17)");
    check(pcia_test_si == (P_PARTITIONED ? 20'hAAAAA : '0), "PART 1: pcia scan-in from DFTSI at pin 0 (REQ-17, 11.3)");
    check(pcib_test_si == 20'h0, "PART 1: pcib scan-in 0, not selected (REQ-17)");
    check(ahb_test_si == 6'h0, "PART 1: ahb scan-in 0, not selected (REQ-17)");
    check(apb_test_si == 4'h0, "PART 1: apb scan-in 0, not selected (REQ-17)");
    check(axis_test_si == 3'h0, "PART 1: axis scan-in 0, not selected (REQ-17)");
    check(axim_test_si == 4'h0, "PART 1: axim scan-in 0, not selected (REQ-17)");
    DFTSI = 20'h55555; settle();
    check(scc_test_si == 5'h0, "PART 1: scc scan-in 0, not selected (REQ-17)");
    check(hic_test_si == 5'h0, "PART 1: hic scan-in 0, not selected (REQ-17)");
    check(g2muc_test_si == 6'h0, "PART 1: g2muc scan-in 0, not selected (REQ-17)");
    check(l4ga_test_si == 3'h0, "PART 1: l4ga scan-in 0, not selected (REQ-17)");
    check(l4gb_test_si == 3'h0, "PART 1: l4gb scan-in 0, not selected (REQ-17)");
    check(pcia_test_si == (P_PARTITIONED ? 20'h55555 : '0), "PART 1: pcia scan-in from DFTSI at pin 0 (REQ-17, 11.3)");
    check(pcib_test_si == 20'h0, "PART 1: pcib scan-in 0, not selected (REQ-17)");
    check(ahb_test_si == 6'h0, "PART 1: ahb scan-in 0, not selected (REQ-17)");
    check(apb_test_si == 4'h0, "PART 1: apb scan-in 0, not selected (REQ-17)");
    check(axis_test_si == 3'h0, "PART 1: axis scan-in 0, not selected (REQ-17)");
    check(axim_test_si == 4'h0, "PART 1: axim scan-in 0, not selected (REQ-17)");
    DFTSI = 20'h0;
    scc_test_so = 5'h1F;
    hic_test_so = 5'h1F;
    g2muc_test_so = 6'h3F;
    l4ga_test_so = 3'h7;
    l4gb_test_so = 3'h7;
    pcia_test_so = 20'hFFFFF;
    pcib_test_so = 20'hFFFFF;
    ahb_test_so = 6'h3F;
    apb_test_so = 4'hF;
    axis_test_so = 3'h7;
    axim_test_so = 4'hF;
    settle(); check(DFTSO == (P_PARTITIONED ? 20'hFFFFF : '0), "PART 1: each selected channel returns on its own pin, unmapped pins 0 (REQ-17, REQ-20, 11.3)");
    scc_test_so = 5'h0;
    hic_test_so = 5'h0;
    g2muc_test_so = 6'h0;
    l4ga_test_so = 3'h0;
    l4gb_test_so = 3'h0;
    pcia_test_so = 20'h0;
    pcib_test_so = 20'h0;
    ahb_test_so = 6'h0;
    apb_test_so = 4'h0;
    axis_test_so = 3'h0;
    axim_test_so = 4'h0;
    settle(); check(DFTSO == 20'h0, "PART 1: each selected channel returns on its own pin, unmapped pins 0 (REQ-17, REQ-20)");
    scc_test_so = 5'h15;
    hic_test_so = 5'h15;
    g2muc_test_so = 6'h2A;
    l4ga_test_so = 3'h5;
    l4gb_test_so = 3'h5;
    pcia_test_so = 20'hAAAAA;
    pcib_test_so = 20'hAAAAA;
    ahb_test_so = 6'h2A;
    apb_test_so = 4'hA;
    axis_test_so = 3'h5;
    axim_test_so = 4'hA;
    settle(); check(DFTSO == (P_PARTITIONED ? 20'hAAAAA : '0), "PART 1: each selected channel returns on its own pin, unmapped pins 0 (REQ-17, REQ-20, 11.3)");
    scc_test_so = '0;
    hic_test_so = '0;
    g2muc_test_so = '0;
    l4ga_test_so = '0;
    l4gb_test_so = '0;
    pcia_test_so = '0;
    pcib_test_so = '0;
    ahb_test_so = '0;
    apb_test_so = '0;
    axis_test_so = '0;
    axim_test_so = '0;
    DFTTM = 1'b0; settle(); jtlr(); dtr_write(5'b00010, (CFG_TEST & ~32'h0000_000F) | 32'd2);   // INTEST mode 1 on PART 2 (ADM-23)
    DFTTM = 1'b1;
    DFTMAX = DMAX_SCAN; DFTSE = 1'b1; settle();
    check(scc_test_mode == rtm(4'b0100) && !scc_scan_shift_en && !scc_wrap_shift_en, "PART 2: scc parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(hic_test_mode == rtm(4'b0100) && !hic_scan_shift_en && !hic_wrap_shift_en, "PART 2: hic parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(g2muc_test_mode == rtm(4'b0100) && !g2muc_scan_shift_en && !g2muc_wrap_shift_en, "PART 2: g2muc parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(l4ga_test_mode == rtm(4'b0100) && !l4ga_scan_shift_en && !l4ga_wrap_shift_en, "PART 2: l4ga parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(l4gb_test_mode == rtm(4'b0100) && !l4gb_scan_shift_en && !l4gb_wrap_shift_en, "PART 2: l4gb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(pcia_test_mode == rtm(4'b0100) && !pcia_scan_shift_en && !pcia_wrap_shift_en, "PART 2: pcia parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(pcib_test_mode == rtm(4'b0001) && pcib_scan_shift_en == P_PARTITIONED && pcib_wrap_shift_en == P_PARTITIONED && pcib_dfttm && pcib_test_mode_tp, "PART 2: pcib selected, SCAN, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(ahb_test_mode == rtm(4'b0100) && !ahb_scan_shift_en && !ahb_wrap_shift_en, "PART 2: ahb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(apb_test_mode == rtm(4'b0100) && !apb_scan_shift_en && !apb_wrap_shift_en, "PART 2: apb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(axis_test_mode == rtm(4'b0100) && !axis_scan_shift_en && !axis_wrap_shift_en, "PART 2: axis parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(axim_test_mode == rtm(4'b0100) && !axim_scan_shift_en && !axim_wrap_shift_en, "PART 2: axim parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    DFTMAX = DMAX_COMP; DFTSE = 1'b1; settle();
    check(scc_test_mode == rtm(4'b0100) && !scc_scan_shift_en && !scc_wrap_shift_en, "PART 2: scc parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(hic_test_mode == rtm(4'b0100) && !hic_scan_shift_en && !hic_wrap_shift_en, "PART 2: hic parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(g2muc_test_mode == rtm(4'b0100) && !g2muc_scan_shift_en && !g2muc_wrap_shift_en, "PART 2: g2muc parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(l4ga_test_mode == rtm(4'b0100) && !l4ga_scan_shift_en && !l4ga_wrap_shift_en, "PART 2: l4ga parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(l4gb_test_mode == rtm(4'b0100) && !l4gb_scan_shift_en && !l4gb_wrap_shift_en, "PART 2: l4gb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(pcia_test_mode == rtm(4'b0100) && !pcia_scan_shift_en && !pcia_wrap_shift_en, "PART 2: pcia parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(pcib_test_mode == rtm(4'b0010) && pcib_scan_shift_en == P_PARTITIONED && pcib_wrap_shift_en == P_PARTITIONED && pcib_dfttm && pcib_test_mode_tp, "PART 2: pcib selected, COMP, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(ahb_test_mode == rtm(4'b0100) && !ahb_scan_shift_en && !ahb_wrap_shift_en, "PART 2: ahb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(apb_test_mode == rtm(4'b0100) && !apb_scan_shift_en && !apb_wrap_shift_en, "PART 2: apb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(axis_test_mode == rtm(4'b0100) && !axis_scan_shift_en && !axis_wrap_shift_en, "PART 2: axis parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(axim_test_mode == rtm(4'b0100) && !axim_scan_shift_en && !axim_wrap_shift_en, "PART 2: axim parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    DFTSE = 1'b0; DFTMAX = DMAX_SCAN; settle();
    check(dft_crg_blk_clk_en == (P_PARTITIONED ? 13'h40 : '0), "PART 2: only the selected blocks' test clocks are enabled (REQ-22, 11.3)");
    DFTSI = 20'hFFFFF; settle();
    check(scc_test_si == 5'h0, "PART 2: scc scan-in 0, not selected (REQ-17)");
    check(hic_test_si == 5'h0, "PART 2: hic scan-in 0, not selected (REQ-17)");
    check(g2muc_test_si == 6'h0, "PART 2: g2muc scan-in 0, not selected (REQ-17)");
    check(l4ga_test_si == 3'h0, "PART 2: l4ga scan-in 0, not selected (REQ-17)");
    check(l4gb_test_si == 3'h0, "PART 2: l4gb scan-in 0, not selected (REQ-17)");
    check(pcia_test_si == 20'h0, "PART 2: pcia scan-in 0, not selected (REQ-17)");
    check(pcib_test_si == (P_PARTITIONED ? 20'hFFFFF : '0), "PART 2: pcib scan-in from DFTSI at pin 0 (REQ-17, 11.3)");
    check(ahb_test_si == 6'h0, "PART 2: ahb scan-in 0, not selected (REQ-17)");
    check(apb_test_si == 4'h0, "PART 2: apb scan-in 0, not selected (REQ-17)");
    check(axis_test_si == 3'h0, "PART 2: axis scan-in 0, not selected (REQ-17)");
    check(axim_test_si == 4'h0, "PART 2: axim scan-in 0, not selected (REQ-17)");
    DFTSI = 20'h00000; settle();
    check(scc_test_si == 5'h0, "PART 2: scc scan-in 0, not selected (REQ-17)");
    check(hic_test_si == 5'h0, "PART 2: hic scan-in 0, not selected (REQ-17)");
    check(g2muc_test_si == 6'h0, "PART 2: g2muc scan-in 0, not selected (REQ-17)");
    check(l4ga_test_si == 3'h0, "PART 2: l4ga scan-in 0, not selected (REQ-17)");
    check(l4gb_test_si == 3'h0, "PART 2: l4gb scan-in 0, not selected (REQ-17)");
    check(pcia_test_si == 20'h0, "PART 2: pcia scan-in 0, not selected (REQ-17)");
    check(pcib_test_si == 20'h0, "PART 2: pcib scan-in from DFTSI at pin 0 (REQ-17)");
    check(ahb_test_si == 6'h0, "PART 2: ahb scan-in 0, not selected (REQ-17)");
    check(apb_test_si == 4'h0, "PART 2: apb scan-in 0, not selected (REQ-17)");
    check(axis_test_si == 3'h0, "PART 2: axis scan-in 0, not selected (REQ-17)");
    check(axim_test_si == 4'h0, "PART 2: axim scan-in 0, not selected (REQ-17)");
    DFTSI = 20'hAAAAA; settle();
    check(scc_test_si == 5'h0, "PART 2: scc scan-in 0, not selected (REQ-17)");
    check(hic_test_si == 5'h0, "PART 2: hic scan-in 0, not selected (REQ-17)");
    check(g2muc_test_si == 6'h0, "PART 2: g2muc scan-in 0, not selected (REQ-17)");
    check(l4ga_test_si == 3'h0, "PART 2: l4ga scan-in 0, not selected (REQ-17)");
    check(l4gb_test_si == 3'h0, "PART 2: l4gb scan-in 0, not selected (REQ-17)");
    check(pcia_test_si == 20'h0, "PART 2: pcia scan-in 0, not selected (REQ-17)");
    check(pcib_test_si == (P_PARTITIONED ? 20'hAAAAA : '0), "PART 2: pcib scan-in from DFTSI at pin 0 (REQ-17, 11.3)");
    check(ahb_test_si == 6'h0, "PART 2: ahb scan-in 0, not selected (REQ-17)");
    check(apb_test_si == 4'h0, "PART 2: apb scan-in 0, not selected (REQ-17)");
    check(axis_test_si == 3'h0, "PART 2: axis scan-in 0, not selected (REQ-17)");
    check(axim_test_si == 4'h0, "PART 2: axim scan-in 0, not selected (REQ-17)");
    DFTSI = 20'h55555; settle();
    check(scc_test_si == 5'h0, "PART 2: scc scan-in 0, not selected (REQ-17)");
    check(hic_test_si == 5'h0, "PART 2: hic scan-in 0, not selected (REQ-17)");
    check(g2muc_test_si == 6'h0, "PART 2: g2muc scan-in 0, not selected (REQ-17)");
    check(l4ga_test_si == 3'h0, "PART 2: l4ga scan-in 0, not selected (REQ-17)");
    check(l4gb_test_si == 3'h0, "PART 2: l4gb scan-in 0, not selected (REQ-17)");
    check(pcia_test_si == 20'h0, "PART 2: pcia scan-in 0, not selected (REQ-17)");
    check(pcib_test_si == (P_PARTITIONED ? 20'h55555 : '0), "PART 2: pcib scan-in from DFTSI at pin 0 (REQ-17, 11.3)");
    check(ahb_test_si == 6'h0, "PART 2: ahb scan-in 0, not selected (REQ-17)");
    check(apb_test_si == 4'h0, "PART 2: apb scan-in 0, not selected (REQ-17)");
    check(axis_test_si == 3'h0, "PART 2: axis scan-in 0, not selected (REQ-17)");
    check(axim_test_si == 4'h0, "PART 2: axim scan-in 0, not selected (REQ-17)");
    DFTSI = 20'h0;
    scc_test_so = 5'h1F;
    hic_test_so = 5'h1F;
    g2muc_test_so = 6'h3F;
    l4ga_test_so = 3'h7;
    l4gb_test_so = 3'h7;
    pcia_test_so = 20'hFFFFF;
    pcib_test_so = 20'hFFFFF;
    ahb_test_so = 6'h3F;
    apb_test_so = 4'hF;
    axis_test_so = 3'h7;
    axim_test_so = 4'hF;
    settle(); check(DFTSO == (P_PARTITIONED ? 20'hFFFFF : '0), "PART 2: each selected channel returns on its own pin, unmapped pins 0 (REQ-17, REQ-20, 11.3)");
    scc_test_so = 5'h0;
    hic_test_so = 5'h0;
    g2muc_test_so = 6'h0;
    l4ga_test_so = 3'h0;
    l4gb_test_so = 3'h0;
    pcia_test_so = 20'h0;
    pcib_test_so = 20'h0;
    ahb_test_so = 6'h0;
    apb_test_so = 4'h0;
    axis_test_so = 3'h0;
    axim_test_so = 4'h0;
    settle(); check(DFTSO == 20'h0, "PART 2: each selected channel returns on its own pin, unmapped pins 0 (REQ-17, REQ-20)");
    scc_test_so = 5'h15;
    hic_test_so = 5'h15;
    g2muc_test_so = 6'h2A;
    l4ga_test_so = 3'h5;
    l4gb_test_so = 3'h5;
    pcia_test_so = 20'hAAAAA;
    pcib_test_so = 20'hAAAAA;
    ahb_test_so = 6'h2A;
    apb_test_so = 4'hA;
    axis_test_so = 3'h5;
    axim_test_so = 4'hA;
    settle(); check(DFTSO == (P_PARTITIONED ? 20'hAAAAA : '0), "PART 2: each selected channel returns on its own pin, unmapped pins 0 (REQ-17, REQ-20, 11.3)");
    scc_test_so = '0;
    hic_test_so = '0;
    g2muc_test_so = '0;
    l4ga_test_so = '0;
    l4gb_test_so = '0;
    pcia_test_so = '0;
    pcib_test_so = '0;
    ahb_test_so = '0;
    apb_test_so = '0;
    axis_test_so = '0;
    axim_test_so = '0;
    DFTTM = 1'b0; settle(); jtlr(); dtr_write(5'b00010, (CFG_TEST & ~32'h0000_000F) | 32'd3);   // INTEST mode 2 on PART 3 (ADM-23)
    DFTTM = 1'b1;
    DFTMAX = DMAX_SCAN; DFTSE = 1'b1; settle();
    check(scc_test_mode == rtm(4'b0001) && scc_scan_shift_en == P_PARTITIONED && scc_wrap_shift_en == P_PARTITIONED && scc_dfttm && scc_test_mode_tp, "PART 3: scc selected, SCAN, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(hic_test_mode == rtm(4'b0100) && !hic_scan_shift_en && !hic_wrap_shift_en, "PART 3: hic parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(g2muc_test_mode == rtm(4'b0001) && g2muc_scan_shift_en == P_PARTITIONED && g2muc_wrap_shift_en == P_PARTITIONED && g2muc_dfttm && g2muc_test_mode_tp, "PART 3: g2muc selected, SCAN, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(l4ga_test_mode == rtm(4'b0100) && !l4ga_scan_shift_en && !l4ga_wrap_shift_en, "PART 3: l4ga parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(l4gb_test_mode == rtm(4'b0100) && !l4gb_scan_shift_en && !l4gb_wrap_shift_en, "PART 3: l4gb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(pcia_test_mode == rtm(4'b0100) && !pcia_scan_shift_en && !pcia_wrap_shift_en, "PART 3: pcia parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(pcib_test_mode == rtm(4'b0100) && !pcib_scan_shift_en && !pcib_wrap_shift_en, "PART 3: pcib parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(ahb_test_mode == rtm(4'b0001) && ahb_scan_shift_en == P_PARTITIONED && ahb_wrap_shift_en == P_PARTITIONED && ahb_dfttm && ahb_test_mode_tp, "PART 3: ahb selected, SCAN, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(apb_test_mode == rtm(4'b0100) && !apb_scan_shift_en && !apb_wrap_shift_en, "PART 3: apb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(axis_test_mode == rtm(4'b0001) && axis_scan_shift_en == P_PARTITIONED && axis_wrap_shift_en == P_PARTITIONED && axis_dfttm && axis_test_mode_tp, "PART 3: axis selected, SCAN, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(axim_test_mode == rtm(4'b0100) && !axim_scan_shift_en && !axim_wrap_shift_en, "PART 3: axim parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    DFTMAX = DMAX_COMP; DFTSE = 1'b1; settle();
    check(scc_test_mode == rtm(4'b0010) && scc_scan_shift_en == P_PARTITIONED && scc_wrap_shift_en == P_PARTITIONED && scc_dfttm && scc_test_mode_tp, "PART 3: scc selected, COMP, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(hic_test_mode == rtm(4'b0100) && !hic_scan_shift_en && !hic_wrap_shift_en, "PART 3: hic parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(g2muc_test_mode == rtm(4'b0010) && g2muc_scan_shift_en == P_PARTITIONED && g2muc_wrap_shift_en == P_PARTITIONED && g2muc_dfttm && g2muc_test_mode_tp, "PART 3: g2muc selected, COMP, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(l4ga_test_mode == rtm(4'b0100) && !l4ga_scan_shift_en && !l4ga_wrap_shift_en, "PART 3: l4ga parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(l4gb_test_mode == rtm(4'b0100) && !l4gb_scan_shift_en && !l4gb_wrap_shift_en, "PART 3: l4gb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(pcia_test_mode == rtm(4'b0100) && !pcia_scan_shift_en && !pcia_wrap_shift_en, "PART 3: pcia parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(pcib_test_mode == rtm(4'b0100) && !pcib_scan_shift_en && !pcib_wrap_shift_en, "PART 3: pcib parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(ahb_test_mode == rtm(4'b0010) && ahb_scan_shift_en == P_PARTITIONED && ahb_wrap_shift_en == P_PARTITIONED && ahb_dfttm && ahb_test_mode_tp, "PART 3: ahb selected, COMP, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(apb_test_mode == rtm(4'b0100) && !apb_scan_shift_en && !apb_wrap_shift_en, "PART 3: apb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(axis_test_mode == rtm(4'b0010) && axis_scan_shift_en == P_PARTITIONED && axis_wrap_shift_en == P_PARTITIONED && axis_dfttm && axis_test_mode_tp, "PART 3: axis selected, COMP, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(axim_test_mode == rtm(4'b0100) && !axim_scan_shift_en && !axim_wrap_shift_en, "PART 3: axim parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    DFTSE = 1'b0; DFTMAX = DMAX_SCAN; settle();
    check(dft_crg_blk_clk_en == (P_PARTITIONED ? 13'h285 : '0), "PART 3: only the selected blocks' test clocks are enabled (REQ-22, 11.3)");
    DFTSI = 20'hFFFFF; settle();
    check(scc_test_si == (P_PARTITIONED ? 5'h1F : '0), "PART 3: scc scan-in from DFTSI at pin 0 (REQ-17, 11.3)");
    check(hic_test_si == 5'h0, "PART 3: hic scan-in 0, not selected (REQ-17)");
    check(g2muc_test_si == (P_PARTITIONED ? 6'h3F : '0), "PART 3: g2muc scan-in from DFTSI at pin 5 (REQ-17, 11.3)");
    check(l4ga_test_si == 3'h0, "PART 3: l4ga scan-in 0, not selected (REQ-17)");
    check(l4gb_test_si == 3'h0, "PART 3: l4gb scan-in 0, not selected (REQ-17)");
    check(pcia_test_si == 20'h0, "PART 3: pcia scan-in 0, not selected (REQ-17)");
    check(pcib_test_si == 20'h0, "PART 3: pcib scan-in 0, not selected (REQ-17)");
    check(ahb_test_si == (P_PARTITIONED ? 6'h3F : '0), "PART 3: ahb scan-in from DFTSI at pin 11 (REQ-17, 11.3)");
    check(apb_test_si == 4'h0, "PART 3: apb scan-in 0, not selected (REQ-17)");
    check(axis_test_si == (P_PARTITIONED ? 3'h7 : '0), "PART 3: axis scan-in from DFTSI at pin 17 (REQ-17, 11.3)");
    check(axim_test_si == 4'h0, "PART 3: axim scan-in 0, not selected (REQ-17)");
    DFTSI = 20'h00000; settle();
    check(scc_test_si == 5'h0, "PART 3: scc scan-in from DFTSI at pin 0 (REQ-17)");
    check(hic_test_si == 5'h0, "PART 3: hic scan-in 0, not selected (REQ-17)");
    check(g2muc_test_si == 6'h0, "PART 3: g2muc scan-in from DFTSI at pin 5 (REQ-17)");
    check(l4ga_test_si == 3'h0, "PART 3: l4ga scan-in 0, not selected (REQ-17)");
    check(l4gb_test_si == 3'h0, "PART 3: l4gb scan-in 0, not selected (REQ-17)");
    check(pcia_test_si == 20'h0, "PART 3: pcia scan-in 0, not selected (REQ-17)");
    check(pcib_test_si == 20'h0, "PART 3: pcib scan-in 0, not selected (REQ-17)");
    check(ahb_test_si == 6'h0, "PART 3: ahb scan-in from DFTSI at pin 11 (REQ-17)");
    check(apb_test_si == 4'h0, "PART 3: apb scan-in 0, not selected (REQ-17)");
    check(axis_test_si == 3'h0, "PART 3: axis scan-in from DFTSI at pin 17 (REQ-17)");
    check(axim_test_si == 4'h0, "PART 3: axim scan-in 0, not selected (REQ-17)");
    DFTSI = 20'hAAAAA; settle();
    check(scc_test_si == (P_PARTITIONED ? 5'hA : '0), "PART 3: scc scan-in from DFTSI at pin 0 (REQ-17, 11.3)");
    check(hic_test_si == 5'h0, "PART 3: hic scan-in 0, not selected (REQ-17)");
    check(g2muc_test_si == (P_PARTITIONED ? 6'h15 : '0), "PART 3: g2muc scan-in from DFTSI at pin 5 (REQ-17, 11.3)");
    check(l4ga_test_si == 3'h0, "PART 3: l4ga scan-in 0, not selected (REQ-17)");
    check(l4gb_test_si == 3'h0, "PART 3: l4gb scan-in 0, not selected (REQ-17)");
    check(pcia_test_si == 20'h0, "PART 3: pcia scan-in 0, not selected (REQ-17)");
    check(pcib_test_si == 20'h0, "PART 3: pcib scan-in 0, not selected (REQ-17)");
    check(ahb_test_si == (P_PARTITIONED ? 6'h15 : '0), "PART 3: ahb scan-in from DFTSI at pin 11 (REQ-17, 11.3)");
    check(apb_test_si == 4'h0, "PART 3: apb scan-in 0, not selected (REQ-17)");
    check(axis_test_si == (P_PARTITIONED ? 3'h5 : '0), "PART 3: axis scan-in from DFTSI at pin 17 (REQ-17, 11.3)");
    check(axim_test_si == 4'h0, "PART 3: axim scan-in 0, not selected (REQ-17)");
    DFTSI = 20'h55555; settle();
    check(scc_test_si == (P_PARTITIONED ? 5'h15 : '0), "PART 3: scc scan-in from DFTSI at pin 0 (REQ-17, 11.3)");
    check(hic_test_si == 5'h0, "PART 3: hic scan-in 0, not selected (REQ-17)");
    check(g2muc_test_si == (P_PARTITIONED ? 6'h2A : '0), "PART 3: g2muc scan-in from DFTSI at pin 5 (REQ-17, 11.3)");
    check(l4ga_test_si == 3'h0, "PART 3: l4ga scan-in 0, not selected (REQ-17)");
    check(l4gb_test_si == 3'h0, "PART 3: l4gb scan-in 0, not selected (REQ-17)");
    check(pcia_test_si == 20'h0, "PART 3: pcia scan-in 0, not selected (REQ-17)");
    check(pcib_test_si == 20'h0, "PART 3: pcib scan-in 0, not selected (REQ-17)");
    check(ahb_test_si == (P_PARTITIONED ? 6'h2A : '0), "PART 3: ahb scan-in from DFTSI at pin 11 (REQ-17, 11.3)");
    check(apb_test_si == 4'h0, "PART 3: apb scan-in 0, not selected (REQ-17)");
    check(axis_test_si == (P_PARTITIONED ? 3'h2 : '0), "PART 3: axis scan-in from DFTSI at pin 17 (REQ-17, 11.3)");
    check(axim_test_si == 4'h0, "PART 3: axim scan-in 0, not selected (REQ-17)");
    DFTSI = 20'h0;
    scc_test_so = 5'h1F;
    hic_test_so = 5'h1F;
    g2muc_test_so = 6'h3F;
    l4ga_test_so = 3'h7;
    l4gb_test_so = 3'h7;
    pcia_test_so = 20'hFFFFF;
    pcib_test_so = 20'hFFFFF;
    ahb_test_so = 6'h3F;
    apb_test_so = 4'hF;
    axis_test_so = 3'h7;
    axim_test_so = 4'hF;
    settle(); check(DFTSO == (P_PARTITIONED ? 20'hFFFFF : '0), "PART 3: each selected channel returns on its own pin, unmapped pins 0 (REQ-17, REQ-20, 11.3)");
    scc_test_so = 5'h0;
    hic_test_so = 5'h0;
    g2muc_test_so = 6'h0;
    l4ga_test_so = 3'h0;
    l4gb_test_so = 3'h0;
    pcia_test_so = 20'h0;
    pcib_test_so = 20'h0;
    ahb_test_so = 6'h0;
    apb_test_so = 4'h0;
    axis_test_so = 3'h0;
    axim_test_so = 4'h0;
    settle(); check(DFTSO == 20'h0, "PART 3: each selected channel returns on its own pin, unmapped pins 0 (REQ-17, REQ-20)");
    scc_test_so = 5'h15;
    hic_test_so = 5'h15;
    g2muc_test_so = 6'h2A;
    l4ga_test_so = 3'h5;
    l4gb_test_so = 3'h5;
    pcia_test_so = 20'hAAAAA;
    pcib_test_so = 20'hAAAAA;
    ahb_test_so = 6'h2A;
    apb_test_so = 4'hA;
    axis_test_so = 3'h5;
    axim_test_so = 4'hA;
    settle(); check(DFTSO == (P_PARTITIONED ? 20'hB5555 : '0), "PART 3: each selected channel returns on its own pin, unmapped pins 0 (REQ-17, REQ-20, 11.3)");
    scc_test_so = '0;
    hic_test_so = '0;
    g2muc_test_so = '0;
    l4ga_test_so = '0;
    l4gb_test_so = '0;
    pcia_test_so = '0;
    pcib_test_so = '0;
    ahb_test_so = '0;
    apb_test_so = '0;
    axis_test_so = '0;
    axim_test_so = '0;
    DFTTM = 1'b0; settle(); jtlr(); dtr_write(5'b00010, (CFG_TEST & ~32'h0000_000F) | 32'd4);   // INTEST mode 3 on PART 4 (ADM-23)
    DFTTM = 1'b1;
    DFTMAX = DMAX_SCAN; DFTSE = 1'b1; settle();
    check(scc_test_mode == rtm(4'b0100) && !scc_scan_shift_en && !scc_wrap_shift_en, "PART 4: scc parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(hic_test_mode == rtm(4'b0001) && hic_scan_shift_en == P_PARTITIONED && hic_wrap_shift_en == P_PARTITIONED && hic_dfttm && hic_test_mode_tp, "PART 4: hic selected, SCAN, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(g2muc_test_mode == rtm(4'b0100) && !g2muc_scan_shift_en && !g2muc_wrap_shift_en, "PART 4: g2muc parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(l4ga_test_mode == rtm(4'b0001) && l4ga_scan_shift_en == P_PARTITIONED && l4ga_wrap_shift_en == P_PARTITIONED && l4ga_dfttm && l4ga_test_mode_tp, "PART 4: l4ga selected, SCAN, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(l4gb_test_mode == rtm(4'b0001) && l4gb_scan_shift_en == P_PARTITIONED && l4gb_wrap_shift_en == P_PARTITIONED && l4gb_dfttm && l4gb_test_mode_tp, "PART 4: l4gb selected, SCAN, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(pcia_test_mode == rtm(4'b0100) && !pcia_scan_shift_en && !pcia_wrap_shift_en, "PART 4: pcia parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(pcib_test_mode == rtm(4'b0100) && !pcib_scan_shift_en && !pcib_wrap_shift_en, "PART 4: pcib parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(ahb_test_mode == rtm(4'b0100) && !ahb_scan_shift_en && !ahb_wrap_shift_en, "PART 4: ahb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(apb_test_mode == rtm(4'b0001) && apb_scan_shift_en == P_PARTITIONED && apb_wrap_shift_en == P_PARTITIONED && apb_dfttm && apb_test_mode_tp, "PART 4: apb selected, SCAN, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(axis_test_mode == rtm(4'b0100) && !axis_scan_shift_en && !axis_wrap_shift_en, "PART 4: axis parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(axim_test_mode == rtm(4'b0001) && axim_scan_shift_en == P_PARTITIONED && axim_wrap_shift_en == P_PARTITIONED && axim_dfttm && axim_test_mode_tp, "PART 4: axim selected, SCAN, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    DFTMAX = DMAX_COMP; DFTSE = 1'b1; settle();
    check(scc_test_mode == rtm(4'b0100) && !scc_scan_shift_en && !scc_wrap_shift_en, "PART 4: scc parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(hic_test_mode == rtm(4'b0010) && hic_scan_shift_en == P_PARTITIONED && hic_wrap_shift_en == P_PARTITIONED && hic_dfttm && hic_test_mode_tp, "PART 4: hic selected, COMP, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(g2muc_test_mode == rtm(4'b0100) && !g2muc_scan_shift_en && !g2muc_wrap_shift_en, "PART 4: g2muc parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(l4ga_test_mode == rtm(4'b0010) && l4ga_scan_shift_en == P_PARTITIONED && l4ga_wrap_shift_en == P_PARTITIONED && l4ga_dfttm && l4ga_test_mode_tp, "PART 4: l4ga selected, COMP, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(l4gb_test_mode == rtm(4'b0010) && l4gb_scan_shift_en == P_PARTITIONED && l4gb_wrap_shift_en == P_PARTITIONED && l4gb_dfttm && l4gb_test_mode_tp, "PART 4: l4gb selected, COMP, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(pcia_test_mode == rtm(4'b0100) && !pcia_scan_shift_en && !pcia_wrap_shift_en, "PART 4: pcia parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(pcib_test_mode == rtm(4'b0100) && !pcib_scan_shift_en && !pcib_wrap_shift_en, "PART 4: pcib parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(ahb_test_mode == rtm(4'b0100) && !ahb_scan_shift_en && !ahb_wrap_shift_en, "PART 4: ahb parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(apb_test_mode == rtm(4'b0010) && apb_scan_shift_en == P_PARTITIONED && apb_wrap_shift_en == P_PARTITIONED && apb_dfttm && apb_test_mode_tp, "PART 4: apb selected, COMP, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    check(axis_test_mode == rtm(4'b0100) && !axis_scan_shift_en && !axis_wrap_shift_en, "PART 4: axis parked in WRP_IF, shift enables 0 with SE_GATE = 1 (REQ-14, Table 55, 11.3)");
    check(axim_test_mode == rtm(4'b0010) && axim_scan_shift_en == P_PARTITIONED && axim_wrap_shift_en == P_PARTITIONED && axim_dfttm && axim_test_mode_tp, "PART 4: axim selected, COMP, shift enables follow DFTSE (REQ-14, REQ-15, REQ-16, 11.3)");
    DFTSE = 1'b0; DFTMAX = DMAX_SCAN; settle();
    check(dft_crg_blk_clk_en == (P_PARTITIONED ? 13'h51A : '0), "PART 4: only the selected blocks' test clocks are enabled (REQ-22, 11.3)");
    DFTSI = 20'hFFFFF; settle();
    check(scc_test_si == 5'h0, "PART 4: scc scan-in 0, not selected (REQ-17)");
    check(hic_test_si == (P_PARTITIONED ? 5'h1F : '0), "PART 4: hic scan-in from DFTSI at pin 0 (REQ-17, 11.3)");
    check(g2muc_test_si == 6'h0, "PART 4: g2muc scan-in 0, not selected (REQ-17)");
    check(l4ga_test_si == (P_PARTITIONED ? 3'h7 : '0), "PART 4: l4ga scan-in from DFTSI at pin 5 (REQ-17, 11.3)");
    check(l4gb_test_si == (P_PARTITIONED ? 3'h7 : '0), "PART 4: l4gb scan-in from DFTSI at pin 8 (REQ-17, 11.3)");
    check(pcia_test_si == 20'h0, "PART 4: pcia scan-in 0, not selected (REQ-17)");
    check(pcib_test_si == 20'h0, "PART 4: pcib scan-in 0, not selected (REQ-17)");
    check(ahb_test_si == 6'h0, "PART 4: ahb scan-in 0, not selected (REQ-17)");
    check(apb_test_si == (P_PARTITIONED ? 4'hF : '0), "PART 4: apb scan-in from DFTSI at pin 11 (REQ-17, 11.3)");
    check(axis_test_si == 3'h0, "PART 4: axis scan-in 0, not selected (REQ-17)");
    check(axim_test_si == (P_PARTITIONED ? 4'hF : '0), "PART 4: axim scan-in from DFTSI at pin 15 (REQ-17, 11.3)");
    DFTSI = 20'h00000; settle();
    check(scc_test_si == 5'h0, "PART 4: scc scan-in 0, not selected (REQ-17)");
    check(hic_test_si == 5'h0, "PART 4: hic scan-in from DFTSI at pin 0 (REQ-17)");
    check(g2muc_test_si == 6'h0, "PART 4: g2muc scan-in 0, not selected (REQ-17)");
    check(l4ga_test_si == 3'h0, "PART 4: l4ga scan-in from DFTSI at pin 5 (REQ-17)");
    check(l4gb_test_si == 3'h0, "PART 4: l4gb scan-in from DFTSI at pin 8 (REQ-17)");
    check(pcia_test_si == 20'h0, "PART 4: pcia scan-in 0, not selected (REQ-17)");
    check(pcib_test_si == 20'h0, "PART 4: pcib scan-in 0, not selected (REQ-17)");
    check(ahb_test_si == 6'h0, "PART 4: ahb scan-in 0, not selected (REQ-17)");
    check(apb_test_si == 4'h0, "PART 4: apb scan-in from DFTSI at pin 11 (REQ-17)");
    check(axis_test_si == 3'h0, "PART 4: axis scan-in 0, not selected (REQ-17)");
    check(axim_test_si == 4'h0, "PART 4: axim scan-in from DFTSI at pin 15 (REQ-17)");
    DFTSI = 20'hAAAAA; settle();
    check(scc_test_si == 5'h0, "PART 4: scc scan-in 0, not selected (REQ-17)");
    check(hic_test_si == (P_PARTITIONED ? 5'hA : '0), "PART 4: hic scan-in from DFTSI at pin 0 (REQ-17, 11.3)");
    check(g2muc_test_si == 6'h0, "PART 4: g2muc scan-in 0, not selected (REQ-17)");
    check(l4ga_test_si == (P_PARTITIONED ? 3'h5 : '0), "PART 4: l4ga scan-in from DFTSI at pin 5 (REQ-17, 11.3)");
    check(l4gb_test_si == (P_PARTITIONED ? 3'h2 : '0), "PART 4: l4gb scan-in from DFTSI at pin 8 (REQ-17, 11.3)");
    check(pcia_test_si == 20'h0, "PART 4: pcia scan-in 0, not selected (REQ-17)");
    check(pcib_test_si == 20'h0, "PART 4: pcib scan-in 0, not selected (REQ-17)");
    check(ahb_test_si == 6'h0, "PART 4: ahb scan-in 0, not selected (REQ-17)");
    check(apb_test_si == (P_PARTITIONED ? 4'h5 : '0), "PART 4: apb scan-in from DFTSI at pin 11 (REQ-17, 11.3)");
    check(axis_test_si == 3'h0, "PART 4: axis scan-in 0, not selected (REQ-17)");
    check(axim_test_si == (P_PARTITIONED ? 4'h5 : '0), "PART 4: axim scan-in from DFTSI at pin 15 (REQ-17, 11.3)");
    DFTSI = 20'h55555; settle();
    check(scc_test_si == 5'h0, "PART 4: scc scan-in 0, not selected (REQ-17)");
    check(hic_test_si == (P_PARTITIONED ? 5'h15 : '0), "PART 4: hic scan-in from DFTSI at pin 0 (REQ-17, 11.3)");
    check(g2muc_test_si == 6'h0, "PART 4: g2muc scan-in 0, not selected (REQ-17)");
    check(l4ga_test_si == (P_PARTITIONED ? 3'h2 : '0), "PART 4: l4ga scan-in from DFTSI at pin 5 (REQ-17, 11.3)");
    check(l4gb_test_si == (P_PARTITIONED ? 3'h5 : '0), "PART 4: l4gb scan-in from DFTSI at pin 8 (REQ-17, 11.3)");
    check(pcia_test_si == 20'h0, "PART 4: pcia scan-in 0, not selected (REQ-17)");
    check(pcib_test_si == 20'h0, "PART 4: pcib scan-in 0, not selected (REQ-17)");
    check(ahb_test_si == 6'h0, "PART 4: ahb scan-in 0, not selected (REQ-17)");
    check(apb_test_si == (P_PARTITIONED ? 4'hA : '0), "PART 4: apb scan-in from DFTSI at pin 11 (REQ-17, 11.3)");
    check(axis_test_si == 3'h0, "PART 4: axis scan-in 0, not selected (REQ-17)");
    check(axim_test_si == (P_PARTITIONED ? 4'hA : '0), "PART 4: axim scan-in from DFTSI at pin 15 (REQ-17, 11.3)");
    DFTSI = 20'h0;
    scc_test_so = 5'h1F;
    hic_test_so = 5'h1F;
    g2muc_test_so = 6'h3F;
    l4ga_test_so = 3'h7;
    l4gb_test_so = 3'h7;
    pcia_test_so = 20'hFFFFF;
    pcib_test_so = 20'hFFFFF;
    ahb_test_so = 6'h3F;
    apb_test_so = 4'hF;
    axis_test_so = 3'h7;
    axim_test_so = 4'hF;
    settle(); check(DFTSO == (P_PARTITIONED ? 20'h7FFFF : '0), "PART 4: each selected channel returns on its own pin, unmapped pins 0 (REQ-17, REQ-20, 11.3)");
    scc_test_so = 5'h0;
    hic_test_so = 5'h0;
    g2muc_test_so = 6'h0;
    l4ga_test_so = 3'h0;
    l4gb_test_so = 3'h0;
    pcia_test_so = 20'h0;
    pcib_test_so = 20'h0;
    ahb_test_so = 6'h0;
    apb_test_so = 4'h0;
    axis_test_so = 3'h0;
    axim_test_so = 4'h0;
    settle(); check(DFTSO == 20'h0, "PART 4: each selected channel returns on its own pin, unmapped pins 0 (REQ-17, REQ-20)");
    scc_test_so = 5'h15;
    hic_test_so = 5'h15;
    g2muc_test_so = 6'h2A;
    l4ga_test_so = 3'h5;
    l4gb_test_so = 3'h5;
    pcia_test_so = 20'hAAAAA;
    pcib_test_so = 20'hAAAAA;
    ahb_test_so = 6'h2A;
    apb_test_so = 4'hA;
    axis_test_so = 3'h5;
    axim_test_so = 4'hA;
    settle(); check(DFTSO == (P_PARTITIONED ? 20'h555B5 : '0), "PART 4: each selected channel returns on its own pin, unmapped pins 0 (REQ-17, REQ-20, 11.3)");
    scc_test_so = '0;
    hic_test_so = '0;
    g2muc_test_so = '0;
    l4ga_test_so = '0;
    l4gb_test_so = '0;
    pcia_test_so = '0;
    pcib_test_so = '0;
    ahb_test_so = '0;
    apb_test_so = '0;
    axis_test_so = '0;
    axim_test_so = '0;
    // SE_GATE = 0 (DTR_CFG bit 21): in test the unselected blocks shift with DFTSE; in M0 nothing shifts
    DFTTM = 1'b0; settle(); jtlr(); dtr_write(5'b00010, (CFG_TEST & ~32'h0020_000F) | 32'd1);   // PART 1, SE_GATE = 0
    DFTSE = 1'b1; settle();
    check(all_scan_se == 11'h0 && all_wrap_se == 11'h0 && top_scan_shift_en == 1'b0, "M0 with DFTSE = 1, SE_GATE = 0: no scan, wrapper or TOP shift enable (REQ-01, 11.3)");
    DFTTM = 1'b1; settle();
    check(all_scan_se == (P_PARTITIONED ? 11'h7FF : 11'h0) && all_wrap_se == (P_PARTITIONED ? 11'h7FF : 11'h0), "PART 1, SE_GATE = 0, DFTSE = 1: every block's shift enables follow DFTSE; 0 in the partial build (11.3, Table 55)");
    check(top_scan_shift_en == 1'b0, "PART 1 (INTEST): the TOP chains do not shift outside EXTEST (REQ-18, 12.9, 11.3)");
    DFTSE = 1'b0; settle();
    check(all_scan_se == 11'h0 && all_wrap_se == 11'h0 && top_scan_shift_en == 1'b0, "PART 1, SE_GATE = 0: shift enables follow DFTSE low (11.3)");
    DFTTM = 1'b0; settle();
    jtlr(); dtr_write(5'b00010, CFG_RST);
    finish_test();


    start("t_top_glue");
    DFTTM = 1'b0; settle(); jtlr(); dtr_write(5'b00010, (CFG_TEST & ~32'h0000_000F) | 32'd0);   // PART = 0: scan_test_mode_extest
    DFTTM = 1'b1; DFTSE = 1'b1; settle();
    check(top_scan_shift_en == P_PARTITIONED, "EXTEST: top_scan_shift_en = DFTSE (REQ-18, 12.9, 11.3)");
    check(scc_test_mode == rtm(4'b1000) && scc_scan_shift_en == P_PARTITIONED && scc_wrap_shift_en == P_PARTITIONED && scc_test_si == '0, "EXTEST: scc outward-facing WRP_OF, shift enables on, no channel (REQ-14, REQ-18, 11.3)");
    check(hic_test_mode == rtm(4'b1000) && hic_scan_shift_en == P_PARTITIONED && hic_wrap_shift_en == P_PARTITIONED && hic_test_si == '0, "EXTEST: hic outward-facing WRP_OF, shift enables on, no channel (REQ-14, REQ-18, 11.3)");
    check(g2muc_test_mode == rtm(4'b1000) && g2muc_scan_shift_en == P_PARTITIONED && g2muc_wrap_shift_en == P_PARTITIONED && g2muc_test_si == '0, "EXTEST: g2muc outward-facing WRP_OF, shift enables on, no channel (REQ-14, REQ-18, 11.3)");
    check(l4ga_test_mode == rtm(4'b1000) && l4ga_scan_shift_en == P_PARTITIONED && l4ga_wrap_shift_en == P_PARTITIONED && l4ga_test_si == '0, "EXTEST: l4ga outward-facing WRP_OF, shift enables on, no channel (REQ-14, REQ-18, 11.3)");
    check(l4gb_test_mode == rtm(4'b1000) && l4gb_scan_shift_en == P_PARTITIONED && l4gb_wrap_shift_en == P_PARTITIONED && l4gb_test_si == '0, "EXTEST: l4gb outward-facing WRP_OF, shift enables on, no channel (REQ-14, REQ-18, 11.3)");
    check(pcia_test_mode == rtm(4'b1000) && pcia_scan_shift_en == P_PARTITIONED && pcia_wrap_shift_en == P_PARTITIONED && pcia_test_si == '0, "EXTEST: pcia outward-facing WRP_OF, shift enables on, no channel (REQ-14, REQ-18, 11.3)");
    check(pcib_test_mode == rtm(4'b1000) && pcib_scan_shift_en == P_PARTITIONED && pcib_wrap_shift_en == P_PARTITIONED && pcib_test_si == '0, "EXTEST: pcib outward-facing WRP_OF, shift enables on, no channel (REQ-14, REQ-18, 11.3)");
    check(ahb_test_mode == rtm(4'b1000) && ahb_scan_shift_en == P_PARTITIONED && ahb_wrap_shift_en == P_PARTITIONED && ahb_test_si == '0, "EXTEST: ahb outward-facing WRP_OF, shift enables on, no channel (REQ-14, REQ-18, 11.3)");
    check(apb_test_mode == rtm(4'b1000) && apb_scan_shift_en == P_PARTITIONED && apb_wrap_shift_en == P_PARTITIONED && apb_test_si == '0, "EXTEST: apb outward-facing WRP_OF, shift enables on, no channel (REQ-14, REQ-18, 11.3)");
    check(axis_test_mode == rtm(4'b1000) && axis_scan_shift_en == P_PARTITIONED && axis_wrap_shift_en == P_PARTITIONED && axis_test_si == '0, "EXTEST: axis outward-facing WRP_OF, shift enables on, no channel (REQ-14, REQ-18, 11.3)");
    check(axim_test_mode == rtm(4'b1000) && axim_scan_shift_en == P_PARTITIONED && axim_wrap_shift_en == P_PARTITIONED && axim_test_si == '0, "EXTEST: axim outward-facing WRP_OF, shift enables on, no channel (REQ-14, REQ-18, 11.3)");
    DFTSE = 1'b0; settle();
    check(top_scan_shift_en == 1'b0, "EXTEST: top_scan_shift_en follows DFTSE low (REQ-18)");
    DFTSI = 20'd1 << 0; settle();
    check(scc_wrap_si == (P_PARTITIONED ? 2'b01 : '0), "EXTEST: DFTSI[0] drives scc wrapper chain 0 (REQ-18, 11.3)");
    DFTSI = 20'h0; scc_wrap_so = 2'b01; settle();
    check(scc_wrap_si == (P_PARTITIONED ? 2'b10 : '0) && DFTSO == 20'h0, "EXTEST: scc wrapper chains in series (REQ-18, 11.3)");
    scc_wrap_so = 2'b10; settle();
    check(DFTSO == (P_PARTITIONED ? (20'd1 << 0) : '0), "EXTEST: scc wrapper chain 1 returns on DFTSO[0] (REQ-18, 11.3)");
    scc_wrap_so = 2'b00;
    DFTSI = 20'd1 << 1; settle();
    check(hic_wrap_si == (P_PARTITIONED ? 2'b01 : '0), "EXTEST: DFTSI[1] drives hic wrapper chain 0 (REQ-18, 11.3)");
    DFTSI = 20'h0; hic_wrap_so = 2'b01; settle();
    check(hic_wrap_si == (P_PARTITIONED ? 2'b10 : '0) && DFTSO == 20'h0, "EXTEST: hic wrapper chains in series (REQ-18, 11.3)");
    hic_wrap_so = 2'b10; settle();
    check(DFTSO == (P_PARTITIONED ? (20'd1 << 1) : '0), "EXTEST: hic wrapper chain 1 returns on DFTSO[1] (REQ-18, 11.3)");
    hic_wrap_so = 2'b00;
    DFTSI = 20'd1 << 2; settle();
    check(g2muc_wrap_si == (P_PARTITIONED ? 2'b01 : '0), "EXTEST: DFTSI[2] drives g2muc wrapper chain 0 (REQ-18, 11.3)");
    DFTSI = 20'h0; g2muc_wrap_so = 2'b01; settle();
    check(g2muc_wrap_si == (P_PARTITIONED ? 2'b10 : '0) && DFTSO == 20'h0, "EXTEST: g2muc wrapper chains in series (REQ-18, 11.3)");
    g2muc_wrap_so = 2'b10; settle();
    check(DFTSO == (P_PARTITIONED ? (20'd1 << 2) : '0), "EXTEST: g2muc wrapper chain 1 returns on DFTSO[2] (REQ-18, 11.3)");
    g2muc_wrap_so = 2'b00;
    DFTSI = 20'd1 << 3; settle();
    check(l4ga_wrap_si == (P_PARTITIONED ? 2'b01 : '0), "EXTEST: DFTSI[3] drives l4ga wrapper chain 0 (REQ-18, 11.3)");
    DFTSI = 20'h0; l4ga_wrap_so = 2'b01; settle();
    check(l4ga_wrap_si == (P_PARTITIONED ? 2'b10 : '0) && DFTSO == 20'h0, "EXTEST: l4ga wrapper chains in series (REQ-18, 11.3)");
    l4ga_wrap_so = 2'b10; settle();
    check(DFTSO == (P_PARTITIONED ? (20'd1 << 3) : '0), "EXTEST: l4ga wrapper chain 1 returns on DFTSO[3] (REQ-18, 11.3)");
    l4ga_wrap_so = 2'b00;
    DFTSI = 20'd1 << 4; settle();
    check(l4gb_wrap_si == (P_PARTITIONED ? 2'b01 : '0), "EXTEST: DFTSI[4] drives l4gb wrapper chain 0 (REQ-18, 11.3)");
    DFTSI = 20'h0; l4gb_wrap_so = 2'b01; settle();
    check(l4gb_wrap_si == (P_PARTITIONED ? 2'b10 : '0) && DFTSO == 20'h0, "EXTEST: l4gb wrapper chains in series (REQ-18, 11.3)");
    l4gb_wrap_so = 2'b10; settle();
    check(DFTSO == (P_PARTITIONED ? (20'd1 << 4) : '0), "EXTEST: l4gb wrapper chain 1 returns on DFTSO[4] (REQ-18, 11.3)");
    l4gb_wrap_so = 2'b00;
    DFTSI = 20'd1 << 5; settle();
    check(pcia_wrap_si == (P_PARTITIONED ? 2'b01 : '0), "EXTEST: DFTSI[5] drives pcia wrapper chain 0 (REQ-18, 11.3)");
    DFTSI = 20'h0; pcia_wrap_so = 2'b01; settle();
    check(pcia_wrap_si == (P_PARTITIONED ? 2'b10 : '0) && DFTSO == 20'h0, "EXTEST: pcia wrapper chains in series (REQ-18, 11.3)");
    pcia_wrap_so = 2'b10; settle();
    check(DFTSO == (P_PARTITIONED ? (20'd1 << 5) : '0), "EXTEST: pcia wrapper chain 1 returns on DFTSO[5] (REQ-18, 11.3)");
    pcia_wrap_so = 2'b00;
    DFTSI = 20'd1 << 6; settle();
    check(pcib_wrap_si == (P_PARTITIONED ? 2'b01 : '0), "EXTEST: DFTSI[6] drives pcib wrapper chain 0 (REQ-18, 11.3)");
    DFTSI = 20'h0; pcib_wrap_so = 2'b01; settle();
    check(pcib_wrap_si == (P_PARTITIONED ? 2'b10 : '0) && DFTSO == 20'h0, "EXTEST: pcib wrapper chains in series (REQ-18, 11.3)");
    pcib_wrap_so = 2'b10; settle();
    check(DFTSO == (P_PARTITIONED ? (20'd1 << 6) : '0), "EXTEST: pcib wrapper chain 1 returns on DFTSO[6] (REQ-18, 11.3)");
    pcib_wrap_so = 2'b00;
    DFTSI = 20'd1 << 7; settle();
    check(ahb_wrap_si == (P_PARTITIONED ? 2'b01 : '0), "EXTEST: DFTSI[7] drives ahb wrapper chain 0 (REQ-18, 11.3)");
    DFTSI = 20'h0; ahb_wrap_so = 2'b01; settle();
    check(ahb_wrap_si == (P_PARTITIONED ? 2'b10 : '0) && DFTSO == 20'h0, "EXTEST: ahb wrapper chains in series (REQ-18, 11.3)");
    ahb_wrap_so = 2'b10; settle();
    check(DFTSO == (P_PARTITIONED ? (20'd1 << 7) : '0), "EXTEST: ahb wrapper chain 1 returns on DFTSO[7] (REQ-18, 11.3)");
    ahb_wrap_so = 2'b00;
    DFTSI = 20'd1 << 8; settle();
    check(apb_wrap_si == (P_PARTITIONED ? 2'b01 : '0), "EXTEST: DFTSI[8] drives apb wrapper chain 0 (REQ-18, 11.3)");
    DFTSI = 20'h0; apb_wrap_so = 2'b01; settle();
    check(apb_wrap_si == (P_PARTITIONED ? 2'b10 : '0) && DFTSO == 20'h0, "EXTEST: apb wrapper chains in series (REQ-18, 11.3)");
    apb_wrap_so = 2'b10; settle();
    check(DFTSO == (P_PARTITIONED ? (20'd1 << 8) : '0), "EXTEST: apb wrapper chain 1 returns on DFTSO[8] (REQ-18, 11.3)");
    apb_wrap_so = 2'b00;
    DFTSI = 20'd1 << 9; settle();
    check(axis_wrap_si == (P_PARTITIONED ? 2'b01 : '0), "EXTEST: DFTSI[9] drives axis wrapper chain 0 (REQ-18, 11.3)");
    DFTSI = 20'h0; axis_wrap_so = 2'b01; settle();
    check(axis_wrap_si == (P_PARTITIONED ? 2'b10 : '0) && DFTSO == 20'h0, "EXTEST: axis wrapper chains in series (REQ-18, 11.3)");
    axis_wrap_so = 2'b10; settle();
    check(DFTSO == (P_PARTITIONED ? (20'd1 << 9) : '0), "EXTEST: axis wrapper chain 1 returns on DFTSO[9] (REQ-18, 11.3)");
    axis_wrap_so = 2'b00;
    DFTSI = 20'd1 << 10; settle();
    check(axim_wrap_si == (P_PARTITIONED ? 2'b01 : '0), "EXTEST: DFTSI[10] drives axim wrapper chain 0 (REQ-18, 11.3)");
    DFTSI = 20'h0; axim_wrap_so = 2'b01; settle();
    check(axim_wrap_si == (P_PARTITIONED ? 2'b10 : '0) && DFTSO == 20'h0, "EXTEST: axim wrapper chains in series (REQ-18, 11.3)");
    axim_wrap_so = 2'b10; settle();
    check(DFTSO == (P_PARTITIONED ? (20'd1 << 10) : '0), "EXTEST: axim wrapper chain 1 returns on DFTSO[10] (REQ-18, 11.3)");
    axim_wrap_so = 2'b00;
    DFTSI = 20'd1 << 11; settle();
    check(top_test_si == (P_PARTITIONED ? (3'd1 << 0) : '0), "EXTEST: DFTSI[11] drives TOP chain 0 (REQ-18, 11.3)");
    DFTSI = 20'h0; top_test_so = 3'd1 << 0; settle();
    check(DFTSO == (P_PARTITIONED ? (20'd1 << 11) : '0), "EXTEST: TOP chain 0 returns on DFTSO[11] (REQ-18, 11.3)");
    top_test_so = 3'b000;
    DFTSI = 20'd1 << 12; settle();
    check(top_test_si == (P_PARTITIONED ? (3'd1 << 1) : '0), "EXTEST: DFTSI[12] drives TOP chain 1 (REQ-18, 11.3)");
    DFTSI = 20'h0; top_test_so = 3'd1 << 1; settle();
    check(DFTSO == (P_PARTITIONED ? (20'd1 << 12) : '0), "EXTEST: TOP chain 1 returns on DFTSO[12] (REQ-18, 11.3)");
    top_test_so = 3'b000;
    DFTSI = 20'd1 << 13; settle();
    check(top_test_si == (P_PARTITIONED ? (3'd1 << 2) : '0), "EXTEST: DFTSI[13] drives TOP chain 2 (REQ-18, 11.3)");
    DFTSI = 20'h0; top_test_so = 3'd1 << 2; settle();
    check(DFTSO == (P_PARTITIONED ? (20'd1 << 13) : '0), "EXTEST: TOP chain 2 returns on DFTSO[13] (REQ-18, 11.3)");
    top_test_so = 3'b000;
    DFTSI = 20'hFFFFF; settle();
    check(DFTSO[19:14] == 6'h00, "EXTEST: pins 14 to 19 carry no chain and drive 0 (REQ-20)");
    DFTSI = 20'h0; DFTTM = 1'b0; settle();
    jtlr(); dtr_write(5'b00010, CFG_RST);
    finish_test();


    start("t_sms");
    chain_reset();
    // IR length of the chain: Capture-IR loads ...01 into both IRs (9.4); shifting ones in,
    // dft_tap's 5 captured bits leave first, then the SMS TAP stub's P_SMS_IR_LEN bits, then
    // the ones: the first 1 shifted in reappears after exactly 5 + P_SMS_IR_LEN bits (CONF-40)
    ir_scan(IR_CHAIN + 8, {64{1'b1}}, r64);
    check(r64[4:0] == 5'b00001, "dft_tap IR captures 5'b00001 (9.4, REQ-07)");
    check(r64 == ((64'hFF << IR_CHAIN) | (64'd1 << 5) | 64'd1), "SMS TAP stub IR captures ...01 over P_SMS_IR_LEN bits and the ones shifted in return after exactly 5 + P_SMS_IR_LEN bits (CONF-40, 9.4, 14.6)");
    chain_reset();
    shift_dr(64, 64'h0, r64);
    check(r64[31:0] == IDCODE, "first 32 bits out are P_IDCODE of dft_tap (REQ-36, REQ-08)");
    check(r64[63:32] == SMS_IDCODE, "next 32 bits are P_SMS_IDCODE of the SMS TAP (REQ-36)");
    shift_ir(5'b11111);
    shift_dr(4, 64'h5, r64);
    check(r64[3:0] == 4'b0100, "BYPASS on both devices: two-bit delay, captures 0 (REQ-08)");
    shift_ir(5'b01001);
    shift_dr(4, 64'h5, r64);
    check(r64[3:0] == 4'b0100, "a reserved IR code selects BYPASS (REQ-07)");
    check(scc_sms_in == 5'h0 && pcia_sms_in == 10'h0 && lpddr_sms_in == 5'h0, "every sms_in is 0 with the shell's TAP (REQ-25)");
    scc_sms_out = 1'b1; pcia_sms_out = 2'b11; #1;
    check(scc_sms_in == 5'h0, "sms_out does not reach sms_in (REQ-25)");
    scc_sms_out = 1'b0; pcia_sms_out = 2'b00;
    // TDO1 is driven through Shift-IR (9.6)
    ir_scan(IR_CHAIN, {64{1'b1}}, r64);
    check(ir_oe_all, "TDO1_OE = 1 on every Shift-IR bit (9.6, REQ-09)");
    // Test-Logic-Reset reached by TMS alone selects IDCODE again (9.4)
    jtlr();
    shift_dr(64, 64'h0, r64);
    check(r64 == {SMS_IDCODE, IDCODE}, "a non-IDCODE IR (BYPASS) is replaced by IDCODE on both devices in Test-Logic-Reset reached by TMS only (9.4)");
    // Pause-DR / Exit2-DR inside the IDCODE scan (9.3)
    jtlr();
    dr_scan_paused(64, 20, 64'h0, r64);
    check(r64 == {SMS_IDCODE, IDCODE}, "an IDCODE scan paused in Pause-DR returns through Exit2-DR to Shift-DR and reads the same 64 bits (9.3)");
    // Pause-IR / Exit2-IR inside an IR scan (9.3): BYPASS loaded on both devices
    jtlr();
    ir_scan_paused(IR_CHAIN, 3, {64{1'b1}}, r64);
    check(r64 == ((64'd1 << 5) | 64'd1), "an IR scan paused in Pause-IR returns through Exit2-IR and reads the Capture-IR bits (9.3)");
    shift_dr(4, 64'h5, r64);
    check(r64[3:0] == 4'b0100, "the paused IR scan loaded BYPASS on both devices (9.3, REQ-08)");
    // TRSTN1 alone, with no TMS reset, puts the TAP in Test-Logic-Reset (9.2); the other
    // targets' enables are 0, so TDO1_OE is the chain's own enable for either P_OE_GATED
    arc_tdo1_oe = 1'b0; pcia_tdo1_oe = 1'b0; pcib_tdo1_oe = 1'b0;
    shift_ir(5'b00010);
    jstep(1'b1, 1'b0);                                  // Select-DR
    TRSTN1 = 1'b0; @(posedge TCK1); #1; TRSTN1 = 1'b1;
    check(u_dut.tap_state == 4'hF, "dft_tap in Test-Logic-Reset straight after a TRSTN1 pulse (9.2)");
    jstep(1'b1, 1'b0); jstep(1'b0, 1'b0); jstep(1'b0, 1'b0); jstep(1'b0, 1'b0);   // from TLR: TLR, RTI, RTI, RTI
    @(negedge TCK1); #1;
    check(TDO1_OE == 1'b0, "after TRSTN1 the TMS sequence 1, 0, 0, 0 leaves the chain in Run-Test/Idle, not Shift-DR (9.2, 9.3)");
    shift_dr(64, 64'h0, r64);
    check(r64 == {SMS_IDCODE, IDCODE}, "TRSTN1 selects IDCODE on both devices (9.2, 9.4)");
    finish_test();

    start("t_lpddr");
    dtr_write(5'b00011, {14'h0, 1'b1, 3'b101, 7'h55, 1'b1, 2'b00, 1'b1, 1'b1, 1'b1, 1'b1});
    #1;
    check(lpddr_sms_dm == 3'b101 && lpddr_ring_bypass == 7'h55 && lpddr_sfp_dft_mode == 1'b1, "SMS statics follow DTR_LPDDR (REQ-23)");
    check(lpddr_atpg_mode == 1'b1 && lpddr_compression_mode == 1'b1 && lpddr_scan_shift_cg == 1'b1, "DTR_LPDDR overrides take precedence (REQ-23)");
    check(lpddr_atpg_se == 16'h0 && lpddr_scan_ctl == 2'b00, "atpg_se held, scan_ctl tied 00 (REQ-23, CONF-19)");
    dtr_write(5'b00011, {14'h0, 1'b0, 3'b010, 7'h2A, 1'b0, 2'b11, 4'b0000});
    #1;
    check(lpddr_sms_dm == 3'b010 && lpddr_ring_bypass == 7'h2A && lpddr_sfp_dft_mode == 1'b0, "SMS statics follow a second DTR_LPDDR value (REQ-23)");
    dtr_write(5'b00011, 32'h0000_0035);                // ATPG_MODE_OVR = 1 / VAL = 0, COMP_OVR = 1 / VAL = 0, PHY0/1_BURNIN = 1
    #1;
    check(lpddr_atpg_mode == 1'b0 && lpddr_compression_mode == 1'b0, "the ATPG and compression overrides drive their value bit 0 (Table 51, 11.3, REQ-23)");
    // DDR_TDR_EN is DTR_CFG bit 22 (Table 50): bit 21 alone leaves TDRCLK stopped and WRSTN at 0
    dtr_write(5'b00010, CFG_TEST);                     // bit 21 (SE_GATE) = 1, bit 22 = 0
    n_en = tdrclk_n; repeat (4) @(posedge TCK1); #1;
    check(tdrclk_n == n_en && lpddr_wrstn == 1'b0, "DDR_TDR_EN = 0 with bit 21 = 1: TDRCLK stopped, WRSTN held 0 (Table 50, 15.4)");
    dtr_write(5'b00010, (CFG_TEST & ~32'h0020_0000) | 32'h0040_0000);   // bit 21 = 0, bit 22 = 1
    n_en = tdrclk_n; repeat (4) @(posedge TCK1); #1;
    check(tdrclk_n == n_en + 4, "DDR_TDR_EN = 1 (bit 22) with bit 21 = 0: TDRCLK runs with TCK1 (Table 50, 15.4)");
    dtr_write(5'b00010, (CFG_TEST & ~32'h0000_0010) | 32'h0040_0010);  // BURNIN = 1, DDR_TDR_EN = 1
    #1;
    check(lpddr_phy0_burnin == 1'b0, "burn-in needs DFTTM = 1 (REQ-23)");
    repeat (3) @(posedge lpddr_tdrclk);
    #1;
    check(lpddr_wrstn == 1'b1, "WRSTN released through two TDRCLK flops with DDR_TDR_EN = 1 (REQ-24)");
    shift_ir(5'b00101);                     // DDR0_CMD
    n_en = 0; en_edge_seen = 1'b0;
    fork
      shift_dr(8, 64'hA5, r64);
      begin
        repeat (14) begin
          @(posedge lpddr_tdrclk); #1;                   // after the rising edge, race-free for either launch edge
          if (lpddr_cmd_tdr_shift_en[0]) n_en = n_en + 1;
          if (lpddr_cmd_tdr_shift_en[0]) check(lpddr_wsi[0] == u_dut.tap_tdi, "phy0 WSI carries tap_tdi during the DDR0_CMD scan (REQ-24)");
        end
      end
    join
    check(en_edge_seen && en_edge_tck == !P_TDR_EN_EDGE, "TDR enables launched on falling TCK1 with P_TDR_EN_EDGE = 1, rising with 0 (15.4, CONF-25)");
    check(n_en == 8, "phy0 CmdTdrShiftEn high for exactly the 8 shift cycles (REQ-24, Table 78)");
    check(lpddr_cmd_tdr_shift_en[1] == 1'b0 && lpddr_rd_tdr_shift_en == 2'b00, "no other TDR enable during DDR0_CMD (REQ-24)");
    for (int k = 0; k < 4; k++) begin                 // DDR0_CMD, DDR0_RD, DDR1_CMD, DDR1_RD
      logic [4:0] code;
      int nc;
      int ns;
      int nu;
      code = 5'd5 + k[4:0]; nc = 0; ns = 0; nu = 0;
      // only the TDR this instruction selects returns 1
      {lpddr_rd_tdr_tdo[1], lpddr_cmd_tdr_tdo[1], lpddr_rd_tdr_tdo[0], lpddr_cmd_tdr_tdo[0]} = 4'b0001 << k;
      shift_ir(code);
      fork
        shift_dr(4, 64'h6, r64);
        begin
          repeat (10) begin
            @(posedge lpddr_tdrclk); #1;                 // after the rising edge, race-free for either launch edge
            if (k == 0) begin nc = nc + int'(lpddr_cmd_tdr_capture_en[0]); ns = ns + int'(lpddr_cmd_tdr_shift_en[0]); nu = nu + int'(lpddr_cmd_tdr_update_en[0]); end
            if (k == 1) begin nc = nc + int'(lpddr_rd_tdr_capture_en[0]);  ns = ns + int'(lpddr_rd_tdr_shift_en[0]);  nu = nu + int'(lpddr_rd_tdr_update_en[0]);  end
            if (k == 2) begin nc = nc + int'(lpddr_cmd_tdr_capture_en[1]); ns = ns + int'(lpddr_cmd_tdr_shift_en[1]); nu = nu + int'(lpddr_cmd_tdr_update_en[1]); end
            if (k == 3) begin nc = nc + int'(lpddr_rd_tdr_capture_en[1]);  ns = ns + int'(lpddr_rd_tdr_shift_en[1]);  nu = nu + int'(lpddr_rd_tdr_update_en[1]);  end
          end
        end
      join
      check(nc == 1 && ns == 4 && nu == 1, "one capture, four shift and one update enable for each DDRx scan (REQ-24, Table 78)");
      check(r64[3:0] == 4'b1111, "the selected PHY TDR's TDO, and no other, returns through the DR mux (REQ-24, 15.4)");
      lpddr_cmd_tdr_tdo = 2'b00; lpddr_rd_tdr_tdo = 2'b00;
    end
    // WSI is driven only under the DDRx instructions (15.4): a BYPASS scan of ones leaves it 0
    shift_ir(5'b11111);                                 // the old DDRx IR stays in force until Update-IR
    wsi_seen = 1'b0;
    shift_dr(8, 64'hFF, r64);
    check(!wsi_seen, "WSI = 0 through a BYPASS DR scan of ones (15.4)");
    // DFTTM rising while dft_tap is in Capture-DR, then in Update-DR, of DDR0_CMD: no enable pulse (REQ-35, V-24)
    shift_ir(5'b00101);
    ddr_en_seen = 1'b0;
    jstep(1'b1, 1'b0); jstep(1'b0, 1'b0);               // Select-DR, Capture-DR
    DFTTM = 1'b1;
    repeat (4) @(posedge TCK1); #1;
    check(!ddr_en_seen, "DFTTM rising in Capture-DR of DDR0_CMD: no TDR enable pulse (REQ-35, V-24)");
    DFTTM = 1'b0; #1; jtlr();
    shift_ir(5'b00101);
    jstep(1'b1, 1'b0); jstep(1'b0, 1'b0); jstep(1'b1, 1'b0);   // Select-DR, Capture-DR, Exit1-DR
    jstep(1'b1, 1'b0);                                  // Update-DR
    ddr_en_seen = 1'b0;
    DFTTM = 1'b1;
    repeat (4) @(posedge TCK1); #1;
    check(!ddr_en_seen, "DFTTM rising in Update-DR of DDR0_CMD: no TDR enable pulse (REQ-35, V-24)");
    DFTTM = 1'b0; #1; jtlr();
    DFTTM = 1'b1; #1;
    check(lpddr_phy0_burnin == 1'b1 && lpddr_phy1_burnin == 1'b1, "burn-in = tm & BURNIN & PHYx_BURNIN (REQ-23)");
    repeat (6) @(posedge TCK1);
    check(lpddr_cmd_tdr_capture_en == 2'b00 && lpddr_cmd_tdr_shift_en == 2'b00 && lpddr_cmd_tdr_update_en == 2'b00, "no TDR enable while DFTTM = 1 (REQ-35)");
    DFTTM = 1'b0; #1;
    jtlr(); dtr_write(5'b00010, CFG_TEST);             // DDR_TDR_EN = 0
    #1;
    check(lpddr_wrstn == 1'b0, "WRSTN asserted as soon as DDR_TDR_EN returns to 0 (15.4)");
    repeat (3) @(posedge TCK1); #1;
    check(lpddr_wrstn == 1'b0, "WRSTN held 0 while DDR_TDR_EN = 0 (15.4)");
    finish_test();

    start("t_crg");
    power_on();
    chain_reset();
    // DTR_CFG holds P_CFG_RST here (pin-only state, REQ-31): the 13.2 outputs follow its fields
    Rstn = 1'b0; DFTTM = 1'b0; #1;
    check(lpddr_scan_rstn == 1'b1 && dft_crg_rst_n_test == (CFG_RV[6] ? CFG_RV[7] : 1'b0), "M0 with Rstn = 0: lpddr_scan_rstn = 1, Rst_n_test = RST_OVR ? RST_VAL : Rstn (13.2)");
    Rstn = 1'b1; #1;
    crg_sel = exp_sel(CFG_RV[3:0]); crg_act = exp_active(CFG_RV[3:0]);
    Rstn = 1'b1; DFTTM = 1'b1; DFTMAX = 1'b1; #1;
    check(dft_crg_test_clk_sel == 1'b1 && dft_crg_rst_byp == 1'b1 && dft_crg_pll_byp == (CFG_RV[5] ? 3'b111 : 3'b000), "test clock select, reset bypass, and PLL bypass = P_CFG_RST.PLL_BYP with DFTTM = 1 (REQ-22, REQ-31, 13.2)");
    check(dft_crg_blk_clk_en == (CFG_RV[20:8] & crg_act)
          && dft_crg_comp_clk_en == (P_DFTMAX_COMP ? (CFG_RV[20:8] & crg_sel) : 13'h0)
          && dft_crg_lpddr_clk_en == {5{crg_act[11] & CFG_RV[19]}},
          "clock enables of the reset PART P_CFG_RST[3:0] and BLK_CLK_EN, DFTMAX = 1 (REQ-22, REQ-31, 13.2, 11.3)");
    check(dft_crg_rst_n_test == (CFG_RV[6] ? CFG_RV[7] : 1'b1) && lpddr_scan_rstn == dft_crg_rst_n_test, "Rst_n_test = P_CFG_RST.RST_OVR ? RST_VAL : Rstn (REQ-22, 13.2)");
    Rstn = 1'b0; #1;
    check(dft_crg_rst_n_test == (CFG_RV[6] ? CFG_RV[7] : 1'b0) && lpddr_scan_rstn == dft_crg_rst_n_test, "Rst_n_test = P_CFG_RST.RST_OVR ? RST_VAL : Rstn, Rstn low (REQ-22, REQ-32, 13.2)");
    Rstn = 1'b1; DFTTM = 1'b0; DFTMAX = 1'b0; #1;
    dtr_write(5'b00010, (CFG_TEST & ~32'h0000_00A0) | 32'h0000_0040);  // RST_OVR = 1, RST_VAL = 0, PLL_BYP = 0
    DFTTM = 1'b1; #1;
    check(dft_crg_rst_n_test == 1'b0 && dft_crg_pll_byp == 3'b000, "RST_OVR selects RST_VAL; PLL_BYP = 0 clears the bypass (REQ-22)");
    DFTTM = 1'b0; #1;
    check(dft_crg_rst_n_test == 1'b0, "Rst_n_test = RST_VAL also with DFTTM = 0 (13.2)");
    // DFTTM rise in Shift-DR of DTR_CFG: the configuration is kept (REQ-35)
    dtr_read(5'b00010, r32);
    shift_ir(5'b00010);
    jstep(1'b1, 1'b0); jstep(1'b0, 1'b0); jstep(1'b0, 1'b0);
    for (int i = 0; i < 10; i++) jstep(1'b0, 1'b1);
    DFTTM = 1'b1;
    for (int i = 0; i < 6; i++) jstep(i[0], 1'b1);
    check(u_dut.tap_state == 4'hF, "dft_tap in Test-Logic-Reset with DFTTM = 1 (REQ-35)");
    DFTTM = 1'b0; #1;
    jtlr();
    begin
      logic [31:0] after;
      dtr_read(5'b00010, after);
      check(after == r32, "DTR_CFG unchanged by the DFTTM rise in Shift-DR (REQ-35)");
    end
    Rstn = 1'b0; #1; Rstn = 1'b1; DFTMAX = 1'b1; #1; DFTMAX = 1'b0;
    finish_test();

    start("t_connectivity");
    tracking = 1'b0;
    @(posedge TCK1); #1;
    check(P_PARTITIONED ? (live_seen[10:0] == {11{1'b1}}) : (live_seen[10:0] == '0 && live_outs[10:0] == '0), "dft_crg_comp_clk_en[10:0] changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[23:11] == {13{1'b1}}, "dft_crg_blk_clk_en changed from its reset value during the run, every bit");
    check(live_seen[26:24] == {3{1'b1}}, "dft_crg_pll_byp changed from its reset value during the run, every bit");
    check(live_seen[27:27] == {1{1'b1}}, "dft_crg_rst_n_test changed from its reset value during the run, every bit");
    check(live_seen[28:28] == {1{1'b1}}, "dft_crg_rst_byp changed from its reset value during the run, every bit");
    check(live_seen[29:29] == {1{1'b1}}, "dft_crg_test_clk_sel changed from its reset value during the run, every bit");
    check(live_seen[31:30] == {2{1'b1}}, "lpddr_wsi changed from its reset value during the run, every bit");
    check(live_seen[33:32] == {2{1'b1}}, "lpddr_rd_tdr_update_en changed from its reset value during the run, every bit");
    check(live_seen[35:34] == {2{1'b1}}, "lpddr_rd_tdr_shift_en changed from its reset value during the run, every bit");
    check(live_seen[37:36] == {2{1'b1}}, "lpddr_rd_tdr_capture_en changed from its reset value during the run, every bit");
    check(live_seen[39:38] == {2{1'b1}}, "lpddr_cmd_tdr_update_en changed from its reset value during the run, every bit");
    check(live_seen[41:40] == {2{1'b1}}, "lpddr_cmd_tdr_shift_en changed from its reset value during the run, every bit");
    check(live_seen[43:42] == {2{1'b1}}, "lpddr_cmd_tdr_capture_en changed from its reset value during the run, every bit");
    check(live_seen[44:44] == {1{1'b1}}, "lpddr_wrstn changed from its reset value during the run, every bit");
    check(live_seen[45:45] == {1{1'b1}}, "lpddr_sfp_dft_mode changed from its reset value during the run, every bit");
    check(live_seen[52:46] == {7{1'b1}}, "lpddr_ring_bypass changed from its reset value during the run, every bit");
    check(live_seen[55:53] == {3{1'b1}}, "lpddr_sms_dm changed from its reset value during the run, every bit");
    check(live_seen[56:56] == {1{1'b1}}, "lpddr_scan_rstn changed from its reset value during the run, every bit");
    check(live_seen[57:57] == {1{1'b1}}, "lpddr_scan_shift_cg changed from its reset value during the run, every bit");
    check(live_seen[58:58] == {1{1'b1}}, "lpddr_phy1_burnin changed from its reset value during the run, every bit");
    check(live_seen[59:59] == {1{1'b1}}, "lpddr_phy0_burnin changed from its reset value during the run, every bit");
    check(live_seen[60:60] == {1{1'b1}}, "lpddr_compression_mode changed from its reset value during the run, every bit");
    check(live_seen[61:61] == {1{1'b1}}, "lpddr_atpg_mode changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[64:62] == {3{1'b1}}) : (live_seen[64:62] == '0 && live_outs[64:62] == '0), "top_test_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[65:65] == {1{1'b1}}) : (live_seen[65:65] == '0 && live_outs[65:65] == '0), "top_scan_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[67:66] == {2{1'b1}}) : (live_seen[67:66] == '0 && live_outs[67:66] == '0), "axim_wrap_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[71:68] == {4{1'b1}}) : (live_seen[71:68] == '0 && live_outs[71:68] == '0), "axim_test_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[75:72] == {4{1'b1}}) : (live_seen[75:72] == '0 && live_outs[75:72] == '0), "axim_test_mode changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[76:76] == {1{1'b1}}, "axim_test_mode_tp changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[77:77] == {1{1'b1}}) : (live_seen[77:77] == '0 && live_outs[77:77] == '0), "axim_wrap_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[78:78] == {1{1'b1}}) : (live_seen[78:78] == '0 && live_outs[78:78] == '0), "axim_scan_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[79:79] == {1{1'b1}}, "axim_dfttm changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[81:80] == {2{1'b1}}) : (live_seen[81:80] == '0 && live_outs[81:80] == '0), "axis_wrap_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[84:82] == {3{1'b1}}) : (live_seen[84:82] == '0 && live_outs[84:82] == '0), "axis_test_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[88:85] == {4{1'b1}}) : (live_seen[88:85] == '0 && live_outs[88:85] == '0), "axis_test_mode changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[89:89] == {1{1'b1}}, "axis_test_mode_tp changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[90:90] == {1{1'b1}}) : (live_seen[90:90] == '0 && live_outs[90:90] == '0), "axis_wrap_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[91:91] == {1{1'b1}}) : (live_seen[91:91] == '0 && live_outs[91:91] == '0), "axis_scan_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[92:92] == {1{1'b1}}, "axis_dfttm changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[94:93] == {2{1'b1}}) : (live_seen[94:93] == '0 && live_outs[94:93] == '0), "apb_wrap_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[98:95] == {4{1'b1}}) : (live_seen[98:95] == '0 && live_outs[98:95] == '0), "apb_test_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[102:99] == {4{1'b1}}) : (live_seen[102:99] == '0 && live_outs[102:99] == '0), "apb_test_mode changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[103:103] == {1{1'b1}}, "apb_test_mode_tp changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[104:104] == {1{1'b1}}) : (live_seen[104:104] == '0 && live_outs[104:104] == '0), "apb_wrap_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[105:105] == {1{1'b1}}) : (live_seen[105:105] == '0 && live_outs[105:105] == '0), "apb_scan_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[106:106] == {1{1'b1}}, "apb_dfttm changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[108:107] == {2{1'b1}}) : (live_seen[108:107] == '0 && live_outs[108:107] == '0), "ahb_wrap_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[114:109] == {6{1'b1}}) : (live_seen[114:109] == '0 && live_outs[114:109] == '0), "ahb_test_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[118:115] == {4{1'b1}}) : (live_seen[118:115] == '0 && live_outs[118:115] == '0), "ahb_test_mode changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[119:119] == {1{1'b1}}, "ahb_test_mode_tp changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[120:120] == {1{1'b1}}) : (live_seen[120:120] == '0 && live_outs[120:120] == '0), "ahb_wrap_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[121:121] == {1{1'b1}}) : (live_seen[121:121] == '0 && live_outs[121:121] == '0), "ahb_scan_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[122:122] == {1{1'b1}}, "ahb_dfttm changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[124:123] == {2{1'b1}}) : (live_seen[124:123] == '0 && live_outs[124:123] == '0), "pcib_wrap_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[144:125] == {20{1'b1}}) : (live_seen[144:125] == '0 && live_outs[144:125] == '0), "pcib_test_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[148:145] == {4{1'b1}}) : (live_seen[148:145] == '0 && live_outs[148:145] == '0), "pcib_test_mode changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[149:149] == {1{1'b1}}, "pcib_test_mode_tp changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[150:150] == {1{1'b1}}) : (live_seen[150:150] == '0 && live_outs[150:150] == '0), "pcib_wrap_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[151:151] == {1{1'b1}}) : (live_seen[151:151] == '0 && live_outs[151:151] == '0), "pcib_scan_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[152:152] == {1{1'b1}}, "pcib_dfttm changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[154:153] == {2{1'b1}}) : (live_seen[154:153] == '0 && live_outs[154:153] == '0), "pcia_wrap_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[174:155] == {20{1'b1}}) : (live_seen[174:155] == '0 && live_outs[174:155] == '0), "pcia_test_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[178:175] == {4{1'b1}}) : (live_seen[178:175] == '0 && live_outs[178:175] == '0), "pcia_test_mode changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[179:179] == {1{1'b1}}, "pcia_test_mode_tp changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[180:180] == {1{1'b1}}) : (live_seen[180:180] == '0 && live_outs[180:180] == '0), "pcia_wrap_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[181:181] == {1{1'b1}}) : (live_seen[181:181] == '0 && live_outs[181:181] == '0), "pcia_scan_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[182:182] == {1{1'b1}}, "pcia_dfttm changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[184:183] == {2{1'b1}}) : (live_seen[184:183] == '0 && live_outs[184:183] == '0), "l4gb_wrap_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[187:185] == {3{1'b1}}) : (live_seen[187:185] == '0 && live_outs[187:185] == '0), "l4gb_test_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[191:188] == {4{1'b1}}) : (live_seen[191:188] == '0 && live_outs[191:188] == '0), "l4gb_test_mode changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[192:192] == {1{1'b1}}, "l4gb_test_mode_tp changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[193:193] == {1{1'b1}}) : (live_seen[193:193] == '0 && live_outs[193:193] == '0), "l4gb_wrap_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[194:194] == {1{1'b1}}) : (live_seen[194:194] == '0 && live_outs[194:194] == '0), "l4gb_scan_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[195:195] == {1{1'b1}}, "l4gb_dfttm changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[197:196] == {2{1'b1}}) : (live_seen[197:196] == '0 && live_outs[197:196] == '0), "l4ga_wrap_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[200:198] == {3{1'b1}}) : (live_seen[200:198] == '0 && live_outs[200:198] == '0), "l4ga_test_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[204:201] == {4{1'b1}}) : (live_seen[204:201] == '0 && live_outs[204:201] == '0), "l4ga_test_mode changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[205:205] == {1{1'b1}}, "l4ga_test_mode_tp changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[206:206] == {1{1'b1}}) : (live_seen[206:206] == '0 && live_outs[206:206] == '0), "l4ga_wrap_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[207:207] == {1{1'b1}}) : (live_seen[207:207] == '0 && live_outs[207:207] == '0), "l4ga_scan_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[208:208] == {1{1'b1}}, "l4ga_dfttm changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[210:209] == {2{1'b1}}) : (live_seen[210:209] == '0 && live_outs[210:209] == '0), "g2muc_wrap_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[216:211] == {6{1'b1}}) : (live_seen[216:211] == '0 && live_outs[216:211] == '0), "g2muc_test_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[220:217] == {4{1'b1}}) : (live_seen[220:217] == '0 && live_outs[220:217] == '0), "g2muc_test_mode changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[221:221] == {1{1'b1}}, "g2muc_test_mode_tp changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[222:222] == {1{1'b1}}) : (live_seen[222:222] == '0 && live_outs[222:222] == '0), "g2muc_wrap_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[223:223] == {1{1'b1}}) : (live_seen[223:223] == '0 && live_outs[223:223] == '0), "g2muc_scan_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[224:224] == {1{1'b1}}, "g2muc_dfttm changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[226:225] == {2{1'b1}}) : (live_seen[226:225] == '0 && live_outs[226:225] == '0), "hic_wrap_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[231:227] == {5{1'b1}}) : (live_seen[231:227] == '0 && live_outs[231:227] == '0), "hic_test_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[235:232] == {4{1'b1}}) : (live_seen[235:232] == '0 && live_outs[235:232] == '0), "hic_test_mode changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[236:236] == {1{1'b1}}, "hic_test_mode_tp changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[237:237] == {1{1'b1}}) : (live_seen[237:237] == '0 && live_outs[237:237] == '0), "hic_wrap_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[238:238] == {1{1'b1}}) : (live_seen[238:238] == '0 && live_outs[238:238] == '0), "hic_scan_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[239:239] == {1{1'b1}}, "hic_dfttm changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[241:240] == {2{1'b1}}) : (live_seen[241:240] == '0 && live_outs[241:240] == '0), "scc_wrap_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[246:242] == {5{1'b1}}) : (live_seen[246:242] == '0 && live_outs[246:242] == '0), "scc_test_si changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[250:247] == {4{1'b1}}) : (live_seen[250:247] == '0 && live_outs[250:247] == '0), "scc_test_mode changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[251:251] == {1{1'b1}}, "scc_test_mode_tp changed from its reset value during the run, every bit");
    check(P_PARTITIONED ? (live_seen[252:252] == {1{1'b1}}) : (live_seen[252:252] == '0 && live_outs[252:252] == '0), "scc_wrap_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(P_PARTITIONED ? (live_seen[253:253] == {1{1'b1}}) : (live_seen[253:253] == '0 && live_outs[253:253] == '0), "scc_scan_shift_en changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(live_seen[254:254] == {1{1'b1}}, "scc_dfttm changed from its reset value during the run, every bit");
    check(live_seen[255:255] == {1{1'b1}}, "pcib_tms1 changed from its reset value during the run, every bit");
    check(live_seen[256:256] == {1{1'b1}}, "pcia_tms1 changed from its reset value during the run, every bit");
    check(live_seen[257:257] == {1{1'b1}}, "arc_tms1 changed from its reset value during the run, every bit");
    check(live_seen[258:258] == {1{1'b1}}, "TDO1_OE changed from its reset value during the run, every bit");
    check(live_seen[259:259] == {1{1'b1}}, "TDO1 changed from its reset value during the run, every bit");
    check(P_DFTSO_HIZ_M0 ? (live_seen[260:260] == {1{1'b1}}) : (live_seen[260:260] == '0 && DFTSO_OE == 1'b1), "DFTSO_OE changed from its reset value during the run, every bit; with P_DFTSO_HIZ_M0 = 0 held at 1 throughout (7.3)");
    check(P_PARTITIONED ? (live_seen[280:261] == {20{1'b1}}) : (live_seen[280:261] == '0 && live_outs[280:261] == '0), "DFTSO changed from its reset value during the run, every bit; in the partial build held at 0 throughout (11.3)");
    check(tdrclk_seen, "lpddr_tdrclk changed from its reset value during the run");
    check(!held_moved, "every output the design fixes stayed at its value: the SMS stand-in sms_in, scan_ctl = 00, lpddr_atpg_se and dft_crg_lpddr_clk_en and dft_crg_comp_clk_en[12:11] (LPDDR and TOP in no INTEST mode)");
    finish_test();


    $display("CHECKS %0d", checks);
    $display("SDIP_RESULT tests=%0d checks=%0d errors=%0d checker_fails=%0d monitor_fails=%0d", n_tests, checks, errors, sva_fails, mon_fails);
    $display("CHECKER_FAILS %0d", sva_fails);
    $display("MONITOR_FAILS %0d", mon_fails);
    if (errors == 0 && sva_fails == 3'd0 && mon_fails == 0) $display("RESULT PASS");
    else $display("RESULT FAIL");
    $finish;
  end
endmodule
`default_nettype wire
